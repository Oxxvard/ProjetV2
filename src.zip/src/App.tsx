import { useState, useEffect, lazy, Suspense } from "react";
import { Route, Switch } from "wouter";
import { Toaster } from "@/components/ui/toaster";
import { AuthProvider } from "@/context/AuthContext";
import { ThemeProvider } from "@/context/ThemeContext";
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { getAuth, getRedirectResult } from "firebase/auth";

import MainHeader from "@/components/layout/MainHeader";
import Footer from "@/components/layout/Footer";
import Chatbot from "@/components/ui/chatbot";
import SignupPage from "@/pages/signup";
import LoginPage from "./pages/login";
import LoginModal from "./components/auth/LoginModal";
import SignupModal from "@/components/auth/SignupModal"; 

const LazyHome = lazy(() => import("@/pages/Home"));
const LazyContact = lazy(() => import("@/pages/Contact"));

const LoadingFallback = () => (
  <div className="h-screen flex items-center justify-center">
    <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary-600"></div>
  </div>
);

function App() {
  const { toast } = useToast();
  const auth = getAuth();
  const [isLoading, setIsLoading] = useState(true);
  const [isSignupModalOpen, setIsSignupModalOpen] = useState(false);

  useEffect(() => {
    getRedirectResult(auth)
      .then((result) => {
        if (result?.user) {
          toast({
            title: "Connexion réussie",
            description: "Vous êtes maintenant connecté.",
          });
        }
      })
      .catch((error) => {
        if (error.code !== 'auth/credential-already-in-use') {
          toast({
            title: "Erreur de connexion",
            description: error.message,
            variant: "destructive",
          });
        }
      })
      .finally(() => {
        setTimeout(() => setIsLoading(false), 800);
      });
  }, [auth, toast]);

  if (isLoading) {
    return (
      <div className="h-screen flex flex-col items-center justify-center bg-gradient-to-br from-primary-50 to-primary-100 dark:from-gray-900 dark:to-gray-800">
        <div className="w-24 h-24 relative mb-8">
          <div className="absolute top-0 w-full h-full border-4 border-primary-500 border-t-transparent rounded-full animate-spin"></div>
          <div className="absolute top-2 left-2 right-2 bottom-2 border-4 border-primary-300 border-b-transparent rounded-full animate-spin animation-delay-500"></div>
        </div>
        <div className="text-2xl font-medium text-primary-700 dark:text-primary-300">
          Chargement de l'application...
        </div>
      </div>
    );
  }

  const openSignupModal = () => setIsSignupModalOpen(true);
  const closeSignupModal = () => setIsSignupModalOpen(false);

  const handleLoginClick = () => {
    closeSignupModal();
  };

  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider>
        <AuthProvider>
          <div className="flex flex-col min-h-screen bg-white dark:bg-gray-900 text-gray-900 dark:text-gray-100">
            <MainHeader />
            <main className="flex-grow">
              <Suspense fallback={<LoadingFallback />}>
                <Switch>
                  <Route path="/" component={LazyHome} />
                  <Route path="/contact" component={LazyContact} />
                  <Route path="/signup" component={SignupPage} />
                </Switch>
              </Suspense>
            </main>

            <Footer />
            <Chatbot />
            <Toaster />

            <button
              onClick={openSignupModal}
              className="fixed bottom-8 right-8 bg-primary-500 text-white p-3 rounded-full shadow-lg"
            >
              S'inscrire
            </button>

            <SignupModal
              isOpen={isSignupModalOpen}
              onClose={closeSignupModal}
              onLoginClick={handleLoginClick}
            />
          </div>
        </AuthProvider>
      </ThemeProvider>
    </QueryClientProvider>
  );
}

export default App;
