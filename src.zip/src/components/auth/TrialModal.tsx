import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { createUserWithEmailAndPassword, updateProfile } from "firebase/auth";
import { auth } from "@/lib/firebase";
import { apiRequest } from "@/lib/queryClient";
import { useLocation } from "wouter";

interface TrialModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const TrialModal = ({ isOpen, onClose }: TrialModalProps) => {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [company, setCompany] = useState("");
  const [termsAccepted, setTermsAccepted] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (user) {
      // User is already logged in, redirect to subscribe page
      setLocation("/subscribe");
      onClose();
      return;
    }

    if (!name || !email || !company) {
      toast({
        title: "Erreur",
        description: "Veuillez remplir tous les champs.",
        variant: "destructive",
      });
      return;
    }

    if (!termsAccepted) {
      toast({
        title: "Erreur",
        description: "Veuillez accepter les conditions d'utilisation.",
        variant: "destructive",
      });
      return;
    }

    setIsLoading(true);
    
    try {
      // Generate a random password for the user
      const tempPassword = Math.random().toString(36).slice(-8);
      
      // Create the user in Firebase
      const userCredential = await createUserWithEmailAndPassword(auth, email, tempPassword);
      await updateProfile(userCredential.user, { displayName: name });
      
      // Create user in our backend
      await apiRequest("POST", "/api/users", {
        uid: userCredential.user.uid,
        email,
        username: name,
        company,
      });
      
      toast({
        title: "Compte créé",
        description: "Votre compte a été créé avec succès. Vous allez être redirigé vers la page de paiement.",
      });
      
      // Redirect to subscription page
      setLocation("/subscribe");
      onClose();
    } catch (error: any) {
      let message = "Une erreur est survenue lors de la création de votre compte.";
      
      if (error.code === "auth/email-already-in-use") {
        message = "Cette adresse email est déjà utilisée. Veuillez vous connecter.";
      }
      
      toast({
        title: "Erreur",
        description: message,
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="text-xl font-bold">
            Commencer votre essai gratuit de 7 jours
          </DialogTitle>
        </DialogHeader>
        <p className="text-neutral-600 mb-6">
          Démarrez votre période d'essai du plan Pro sans engagement. Une carte bancaire est requise pour la vérification, mais vous ne serez pas débité pendant la période d'essai.
        </p>
        <form onSubmit={handleSubmit}>
          <div className="mb-6">
            <label
              htmlFor="trial-name"
              className="block text-sm font-medium text-neutral-700 mb-2"
            >
              Nom complet
            </label>
            <input
              type="text"
              id="trial-name"
              name="name"
              className="w-full px-4 py-3 border border-neutral-300 rounded-lg focus:ring-primary-500 focus:border-primary-500"
              placeholder="Votre nom"
              value={name}
              onChange={(e) => setName(e.target.value)}
              required
              disabled={!!user}
            />
          </div>
          <div className="mb-6">
            <label
              htmlFor="trial-email"
              className="block text-sm font-medium text-neutral-700 mb-2"
            >
              Email professionnel
            </label>
            <input
              type="email"
              id="trial-email"
              name="email"
              className="w-full px-4 py-3 border border-neutral-300 rounded-lg focus:ring-primary-500 focus:border-primary-500"
              placeholder="votre@email.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              disabled={!!user}
            />
          </div>
          <div className="mb-6">
            <label
              htmlFor="trial-company"
              className="block text-sm font-medium text-neutral-700 mb-2"
            >
              Entreprise
            </label>
            <input
              type="text"
              id="trial-company"
              name="company"
              className="w-full px-4 py-3 border border-neutral-300 rounded-lg focus:ring-primary-500 focus:border-primary-500"
              placeholder="Nom de votre entreprise"
              value={company}
              onChange={(e) => setCompany(e.target.value)}
              required
              disabled={!!user}
            />
          </div>
          
          {!user && (
            <div className="flex items-center mb-6">
              <input
                id="trial-terms"
                name="terms"
                type="checkbox"
                className="h-4 w-4 text-primary-500 focus:ring-primary-500 border-neutral-300 rounded"
                checked={termsAccepted}
                onChange={(e) => setTermsAccepted(e.target.checked)}
                required
              />
              <label htmlFor="trial-terms" className="ml-2 block text-sm text-neutral-700">
                J'accepte que mon abonnement de 499€/mois débute automatiquement après ma période d'essai, sauf si j'annule avant.
              </label>
            </div>
          )}
          
          <button
            type="submit"
            className="w-full py-3 px-4 bg-primary-500 text-white rounded-lg font-medium hover:bg-primary-600 transition duration-150 ease-in-out"
            disabled={isLoading}
          >
            {isLoading ? "Traitement en cours..." : user ? "Continuer vers l'abonnement" : "Commencer mon essai gratuit"}
          </button>
        </form>
        <div className="text-center mt-6">
          <p className="text-sm text-neutral-600">
            Vous pouvez annuler à tout moment durant votre période d'essai.
          </p>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default TrialModal;
