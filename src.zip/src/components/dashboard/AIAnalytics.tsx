import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { 
  LineChart, Line, AreaChart, Area, BarChart, Bar, PieChart, Pie, ResponsiveContainer, 
  XAxis, YAxis, CartesianGrid, Tooltip, Legend, Cell
} from "recharts";
import { 
  TrendingUp, TrendingDown, AlertCircle, CheckCircle, BarChart2, 
  PieChart as PieChartIcon, Activity, RefreshCw
} from "lucide-react";
import { useTheme } from "@/context/ThemeContext";

// Définition des types de données
interface MetricCard {
  title: string;
  value: string | number;
  change: number;
  trend: "up" | "down" | "neutral";
  color: string;
  prefix?: string;
  suffix?: string;
}

interface ChartData {
  name: string;
  value: number;
  [key: string]: any;
}

// Données simulées pour les graphiques
const monthlyData: ChartData[] = [
  { name: "Jan", value: 4000, conversations: 2400, automations: 1600 },
  { name: "Fév", value: 4500, conversations: 2800, automations: 1700 },
  { name: "Mar", value: 5100, conversations: 3200, automations: 1900 },
  { name: "Avr", value: 4800, conversations: 3100, automations: 1700 },
  { name: "Mai", value: 5300, conversations: 3400, automations: 1900 },
  { name: "Juin", value: 5800, conversations: 3700, automations: 2100 },
  { name: "Juil", value: 6300, conversations: 4100, automations: 2200 },
  { name: "Août", value: 6800, conversations: 4500, automations: 2300 },
  { name: "Sep", value: 7400, conversations: 5000, automations: 2400 },
  { name: "Oct", value: 8100, conversations: 5500, automations: 2600 },
  { name: "Nov", value: 8600, conversations: 5800, automations: 2800 },
  { name: "Déc", value: 9200, conversations: 6400, automations: 2800 }
];

const chatbotPerformanceData: ChartData[] = [
  { name: "Lun", resolution: 92, satisfaction: 88 },
  { name: "Mar", resolution: 88, satisfaction: 85 },
  { name: "Mer", resolution: 94, satisfaction: 90 },
  { name: "Jeu", resolution: 91, satisfaction: 87 },
  { name: "Ven", resolution: 89, satisfaction: 86 },
  { name: "Sam", resolution: 95, satisfaction: 92 },
  { name: "Dim", resolution: 97, satisfaction: 94 }
];

const sourcesData: ChartData[] = [
  { name: "WhatsApp", value: 45 },
  { name: "Site Web", value: 25 },
  { name: "Instagram", value: 15 },
  { name: "Facebook", value: 10 },
  { name: "Email", value: 5 }
];

const timeDistributionData: ChartData[] = [
  { name: "00-04h", value: 5 },
  { name: "04-08h", value: 8 },
  { name: "08-12h", value: 30 },
  { name: "12-16h", value: 25 },
  { name: "16-20h", value: 20 },
  { name: "20-24h", value: 12 }
];

// Couleurs pour les différents éléments
const COLORS = ["#0088FE", "#00C49F", "#FFBB28", "#FF8042", "#A569BD"];

const AIAnalytics = () => {
  const [metrics, setMetrics] = useState<MetricCard[]>([]);
  const [timeframe, setTimeframe] = useState<"day" | "week" | "month" | "year">("month");
  const [isLoading, setIsLoading] = useState(true);
  const [chartData, setChartData] = useState(monthlyData);
  const { resolvedTheme } = useTheme();
  
  const isDark = resolvedTheme === "dark";
  
  // Couleurs adaptées au thème
  const textColor = isDark ? "#e2e8f0" : "#1e293b";
  const gridColor = isDark ? "rgba(255, 255, 255, 0.1)" : "rgba(0, 0, 0, 0.1)";
  const backgroundColor = isDark ? "#1f2937" : "#ffffff";
  
  // Simuler le chargement des données
  useEffect(() => {
    const timer = setTimeout(() => {
      // Données de métriques
      setMetrics([
        {
          title: "Messages automatisés",
          value: 24578,
          change: 12.5,
          trend: "up",
          color: "#3b82f6",
          suffix: ""
        },
        {
          title: "Taux de résolution",
          value: 94.2,
          change: 3.8,
          trend: "up",
          color: "#10b981",
          suffix: "%"
        },
        {
          title: "Coût par résolution",
          value: 0.12,
          change: -15.3,
          trend: "down",
          color: "#6366f1",
          prefix: "€"
        },
        {
          title: "Temps économisé",
          value: 342,
          change: 8.7,
          trend: "up",
          color: "#f97316",
          suffix: "h"
        }
      ]);
      
      setIsLoading(false);
    }, 1500);
    
    return () => clearTimeout(timer);
  }, []);
  
  // Fonction pour changer l'intervalle de temps
  const handleTimeframeChange = (newTimeframe: "day" | "week" | "month" | "year") => {
    setIsLoading(true);
    setTimeframe(newTimeframe);
    
    // Simuler le chargement de nouvelles données
    setTimeout(() => {
      // Dans une implémentation réelle, nous chargerions différentes données en fonction de l'intervalle
      const multiplier = newTimeframe === "day" ? 0.01 : 
                         newTimeframe === "week" ? 0.1 : 
                         newTimeframe === "month" ? 1 : 12;
      
      if (newTimeframe === "day") {
        // Données par heure pour un jour
        const hourlyData = Array.from({ length: 24 }, (_, i) => ({
          name: `${i}h`,
          value: Math.floor(monthlyData[0].value * multiplier * (0.5 + Math.random())),
          conversations: Math.floor(monthlyData[0].conversations * multiplier * (0.5 + Math.random())),
          automations: Math.floor(monthlyData[0].automations * multiplier * (0.5 + Math.random()))
        }));
        setChartData(hourlyData);
      } else if (newTimeframe === "week") {
        // Données par jour pour une semaine
        const weeklyData = ["Lun", "Mar", "Mer", "Jeu", "Ven", "Sam", "Dim"].map(day => ({
          name: day,
          value: Math.floor(monthlyData[0].value * multiplier * (0.8 + Math.random() * 0.4)),
          conversations: Math.floor(monthlyData[0].conversations * multiplier * (0.8 + Math.random() * 0.4)),
          automations: Math.floor(monthlyData[0].automations * multiplier * (0.8 + Math.random() * 0.4))
        }));
        setChartData(weeklyData);
      } else if (newTimeframe === "year") {
        // Données annuelles
        const yearlyData = Array.from({ length: 3 }, (_, i) => ({
          name: `202${i + 3}`,
          value: monthlyData.reduce((sum, item) => sum + item.value, 0) * (1 + i * 0.2),
          conversations: monthlyData.reduce((sum, item) => sum + item.conversations, 0) * (1 + i * 0.2),
          automations: monthlyData.reduce((sum, item) => sum + item.automations, 0) * (1 + i * 0.2)
        }));
        setChartData(yearlyData);
      } else {
        // Données mensuelles (par défaut)
        setChartData(monthlyData);
      }
      
      setIsLoading(false);
    }, 800);
  };

  return (
    <div className="space-y-6">
      {/* Titre et contrôles */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center space-y-4 sm:space-y-0">
        <div>
          <h2 className="text-2xl font-bold text-gray-900 dark:text-gray-100">
            Tableau de bord d'analyse
          </h2>
          <p className="text-gray-600 dark:text-gray-400">
            Visualisez les performances de vos automatisations IA
          </p>
        </div>
        
        <div className="flex items-center space-x-2 bg-gray-100 dark:bg-gray-800 rounded-lg p-1">
          {(["day", "week", "month", "year"] as const).map((t) => (
            <button
              key={t}
              onClick={() => handleTimeframeChange(t)}
              className={`px-3 py-1.5 text-sm rounded-md transition-colors ${
                timeframe === t
                  ? "bg-white dark:bg-gray-700 text-primary dark:text-primary-300 shadow-sm"
                  : "text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-200"
              }`}
            >
              {t === "day" ? "Jour" : t === "week" ? "Semaine" : t === "month" ? "Mois" : "Année"}
            </button>
          ))}
        </div>
      </div>
      
      {/* Indicateurs clés */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {isLoading
          ? Array.from({ length: 4 }).map((_, index) => (
              <div
                key={index}
                className="bg-gray-100 dark:bg-gray-800 rounded-lg p-6 animate-pulse h-32"
              ></div>
            ))
          : metrics.map((metric, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, delay: index * 0.1 }}
                className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow-sm border border-gray-100 dark:border-gray-700"
              >
                <div className="flex justify-between items-start">
                  <div>
                    <p className="text-sm font-medium text-gray-500 dark:text-gray-400">
                      {metric.title}
                    </p>
                    <h3 className="text-2xl font-bold mt-1 text-gray-900 dark:text-gray-100">
                      {metric.prefix && <span>{metric.prefix}</span>}
                      {typeof metric.value === "number" 
                        ? new Intl.NumberFormat("fr-FR").format(metric.value) 
                        : metric.value}
                      {metric.suffix && <span>{metric.suffix}</span>}
                    </h3>
                  </div>
                  <div
                    className={`p-2 rounded-full ${
                      metric.trend === "up"
                        ? "bg-green-100 dark:bg-green-900/30 text-green-600 dark:text-green-400"
                        : metric.trend === "down" && metric.change > 0
                        ? "bg-red-100 dark:bg-red-900/30 text-red-600 dark:text-red-400"
                        : metric.trend === "down" && metric.change < 0
                        ? "bg-green-100 dark:bg-green-900/30 text-green-600 dark:text-green-400"
                        : "bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-400"
                    }`}
                  >
                    {metric.trend === "up" ? (
                      <TrendingUp className="h-5 w-5" />
                    ) : metric.trend === "down" ? (
                      <TrendingDown className="h-5 w-5" />
                    ) : (
                      <Activity className="h-5 w-5" />
                    )}
                  </div>
                </div>
                <div className="mt-2 flex items-center">
                  <span
                    className={`text-sm font-medium ${
                      (metric.trend === "up" && metric.change > 0) ||
                      (metric.trend === "down" && metric.change < 0)
                        ? "text-green-600 dark:text-green-400"
                        : (metric.trend === "down" && metric.change > 0) ||
                          (metric.trend === "up" && metric.change < 0)
                        ? "text-red-600 dark:text-red-400"
                        : "text-gray-600 dark:text-gray-400"
                    }`}
                  >
                    {metric.change > 0 ? "+" : ""}
                    {metric.change}%
                  </span>
                  <span className="text-gray-600 dark:text-gray-400 text-sm ml-1">
                    vs. période précédente
                  </span>
                </div>
              </motion.div>
            ))}
      </div>
      
      {/* Section des graphiques */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Graphique principal - Messages traités */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
          className="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6 border border-gray-100 dark:border-gray-700"
        >
          <div className="flex justify-between items-center mb-4">
            <div>
              <h3 className="font-medium text-gray-900 dark:text-gray-100">Messages traités</h3>
              <p className="text-sm text-gray-500 dark:text-gray-400">
                Automatisés vs. conversations manuelles
              </p>
            </div>
            <button className="p-2 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 rounded-full">
              <RefreshCw className="h-4 w-4" />
            </button>
          </div>
          
          {isLoading ? (
            <div className="h-72 w-full bg-gray-100 dark:bg-gray-700 rounded animate-pulse"></div>
          ) : (
            <ResponsiveContainer width="100%" height={300}>
              <AreaChart data={chartData} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
                <defs>
                  <linearGradient id="colorValue" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#0088FE" stopOpacity={0.8} />
                    <stop offset="95%" stopColor="#0088FE" stopOpacity={0.1} />
                  </linearGradient>
                  <linearGradient id="colorConv" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#00C49F" stopOpacity={0.8} />
                    <stop offset="95%" stopColor="#00C49F" stopOpacity={0.1} />
                  </linearGradient>
                  <linearGradient id="colorAuto" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#FFBB28" stopOpacity={0.8} />
                    <stop offset="95%" stopColor="#FFBB28" stopOpacity={0.1} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke={gridColor} />
                <XAxis dataKey="name" tick={{ fill: textColor }} />
                <YAxis tick={{ fill: textColor }} />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor, 
                    borderColor: gridColor,
                    color: textColor
                  }} 
                  labelStyle={{ color: textColor }}
                />
                <Legend 
                  formatter={(value) => {
                    return <span style={{ color: textColor }}>{value}</span>;
                  }}
                />
                <Area
                  type="monotone"
                  dataKey="value"
                  name="Total"
                  stroke="#0088FE"
                  fillOpacity={1}
                  fill="url(#colorValue)"
                />
                <Area
                  type="monotone"
                  dataKey="conversations"
                  name="Conversations"
                  stroke="#00C49F"
                  fillOpacity={1}
                  fill="url(#colorConv)"
                />
                <Area
                  type="monotone"
                  dataKey="automations"
                  name="Automatisés"
                  stroke="#FFBB28"
                  fillOpacity={1}
                  fill="url(#colorAuto)"
                />
              </AreaChart>
            </ResponsiveContainer>
          )}
          
          <div className="grid grid-cols-3 gap-4 mt-4">
            {["Total", "Conversations", "Automatisés"].map((label, index) => (
              <div key={index} className="text-center">
                <p className="text-sm font-medium text-gray-500 dark:text-gray-400">{label}</p>
                <p className="text-lg font-semibold text-gray-900 dark:text-gray-100">
                  {isLoading ? (
                    <span className="inline-block w-16 h-6 bg-gray-200 dark:bg-gray-700 rounded animate-pulse"></span>
                  ) : (
                    new Intl.NumberFormat("fr-FR").format(
                      chartData.reduce((sum, item) => {
                        const key = label === "Total" 
                          ? "value" 
                          : label === "Conversations" 
                          ? "conversations" 
                          : "automations";
                        return sum + (item[key] || 0);
                      }, 0)
                    )
                  )}
                </p>
              </div>
            ))}
          </div>
        </motion.div>
        
        {/* Performance des chatbots */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, delay: 0.1 }}
          className="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6 border border-gray-100 dark:border-gray-700"
        >
          <div className="flex justify-between items-center mb-4">
            <div>
              <h3 className="font-medium text-gray-900 dark:text-gray-100">
                Performance des chatbots
              </h3>
              <p className="text-sm text-gray-500 dark:text-gray-400">
                Taux de résolution et satisfaction client
              </p>
            </div>
            <div className="flex items-center gap-2">
              <div className="flex items-center gap-1">
                <span className="w-3 h-3 inline-block bg-primary rounded-full"></span>
                <span className="text-xs text-gray-500 dark:text-gray-400">Résolution</span>
              </div>
              <div className="flex items-center gap-1">
                <span className="w-3 h-3 inline-block bg-green-500 rounded-full"></span>
                <span className="text-xs text-gray-500 dark:text-gray-400">Satisfaction</span>
              </div>
            </div>
          </div>
          
          {isLoading ? (
            <div className="h-72 w-full bg-gray-100 dark:bg-gray-700 rounded animate-pulse"></div>
          ) : (
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={chatbotPerformanceData} margin={{ top: 10, right: 10, left: 10, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke={gridColor} />
                <XAxis dataKey="name" tick={{ fill: textColor }} />
                <YAxis
                  domain={[75, 100]}
                  tick={{ fill: textColor }}
                  tickFormatter={(value) => `${value}%`}
                />
                <Tooltip 
                  formatter={(value) => [`${value}%`, ""]}
                  contentStyle={{ 
                    backgroundColor, 
                    borderColor: gridColor,
                    color: textColor
                  }}
                />
                <Line
                  type="monotone"
                  dataKey="resolution"
                  name="Taux de résolution"
                  stroke="#3b82f6"
                  strokeWidth={2}
                  dot={{ r: 4 }}
                  activeDot={{ r: 6 }}
                />
                <Line
                  type="monotone"
                  dataKey="satisfaction"
                  name="Taux de satisfaction"
                  stroke="#10b981"
                  strokeWidth={2}
                  dot={{ r: 4 }}
                  activeDot={{ r: 6 }}
                />
              </LineChart>
            </ResponsiveContainer>
          )}
          
          <div className="grid grid-cols-2 gap-4 mt-4">
            {[
              { label: "Taux de résolution", key: "resolution", icon: <CheckCircle className="h-5 w-5 text-primary" /> },
              { label: "Taux de satisfaction", key: "satisfaction", icon: <CheckCircle className="h-5 w-5 text-green-500" /> }
            ].map((item, index) => (
              <div key={index} className="flex items-center gap-3">
                {item.icon}
                <div>
                  <p className="text-sm font-medium text-gray-500 dark:text-gray-400">{item.label}</p>
                  <p className="text-lg font-semibold text-gray-900 dark:text-gray-100">
                    {isLoading ? (
                      <span className="inline-block w-16 h-6 bg-gray-200 dark:bg-gray-700 rounded animate-pulse"></span>
                    ) : (
                      `${Math.round(
                        chatbotPerformanceData.reduce((sum, data) => sum + data[item.key], 0) / 
                        chatbotPerformanceData.length
                      )}%`
                    )}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </motion.div>
        
        {/* Distribution par source */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, delay: 0.2 }}
          className="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6 border border-gray-100 dark:border-gray-700"
        >
          <div className="flex justify-between items-center mb-4">
            <div>
              <h3 className="font-medium text-gray-900 dark:text-gray-100">
                Distribution par source
              </h3>
              <p className="text-sm text-gray-500 dark:text-gray-400">
                Provenance des messages automatisés
              </p>
            </div>
            <PieChartIcon className="h-5 w-5 text-gray-400" />
          </div>
          
          {isLoading ? (
            <div className="h-72 w-full bg-gray-100 dark:bg-gray-700 rounded animate-pulse"></div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <ResponsiveContainer width="100%" height={200}>
                <PieChart>
                  <Pie
                    data={sourcesData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {sourcesData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip 
                    formatter={(value) => [`${value}%`, "Pourcentage"]}
                    contentStyle={{ 
                      backgroundColor, 
                      borderColor: gridColor,
                      color: textColor
                    }} 
                  />
                </PieChart>
              </ResponsiveContainer>
              
              <div className="flex flex-col justify-center">
                {sourcesData.map((source, index) => (
                  <div key={index} className="flex items-center mb-2">
                    <div
                      className="w-4 h-4 rounded-full mr-2"
                      style={{ backgroundColor: COLORS[index % COLORS.length] }}
                    ></div>
                    <span className="text-sm text-gray-700 dark:text-gray-300 mr-2">{source.name}</span>
                    <span className="text-sm font-medium text-gray-900 dark:text-gray-100">{source.value}%</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </motion.div>
        
        {/* Distribution horaire */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, delay: 0.3 }}
          className="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6 border border-gray-100 dark:border-gray-700"
        >
          <div className="flex justify-between items-center mb-4">
            <div>
              <h3 className="font-medium text-gray-900 dark:text-gray-100">
                Distribution horaire
              </h3>
              <p className="text-sm text-gray-500 dark:text-gray-400">
                Activité par tranches horaires
              </p>
            </div>
            <BarChart2 className="h-5 w-5 text-gray-400" />
          </div>
          
          {isLoading ? (
            <div className="h-72 w-full bg-gray-100 dark:bg-gray-700 rounded animate-pulse"></div>
          ) : (
            <ResponsiveContainer width="100%" height={250}>
              <BarChart
                data={timeDistributionData}
                margin={{ top: 5, right: 10, left: 10, bottom: 5 }}
              >
                <CartesianGrid strokeDasharray="3 3" stroke={gridColor} />
                <XAxis dataKey="name" tick={{ fill: textColor }} />
                <YAxis tick={{ fill: textColor }} />
                <Tooltip 
                  formatter={(value) => [`${value}%`, "Pourcentage"]}
                  contentStyle={{ 
                    backgroundColor, 
                    borderColor: gridColor,
                    color: textColor
                  }} 
                />
                <Bar dataKey="value" name="Pourcentage" fill="#6366f1">
                  {timeDistributionData.map((entry, index) => (
                    <Cell
                      key={`cell-${index}`}
                      fill={entry.value > 20 ? "#6366f1" : "#94a3b8"}
                    />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          )}
          
          <div className="mt-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <div className="w-3 h-3 bg-indigo-500 rounded-full mr-2"></div>
                <span className="text-sm text-gray-600 dark:text-gray-400">Heures de pointe</span>
              </div>
              <span className="text-sm font-medium text-gray-900 dark:text-gray-100">
                {isLoading ? (
                  <span className="inline-block w-20 h-5 bg-gray-200 dark:bg-gray-700 rounded animate-pulse"></span>
                ) : (
                  "08-16h"
                )}
              </span>
            </div>
          </div>
        </motion.div>
      </div>
      
      {/* Insights IA */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3, delay: 0.4 }}
        className="bg-gradient-to-br from-primary-50 to-indigo-50 dark:from-gray-800 dark:to-indigo-900/30 rounded-lg p-6 shadow-sm border border-primary-100 dark:border-indigo-800/20"
      >
        <div className="flex items-start gap-4">
          <div className="p-3 bg-primary-100 dark:bg-indigo-900/40 rounded-full text-primary-600 dark:text-indigo-300">
            <AlertCircle className="h-6 w-6" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-50 mb-2">
              Insights IA - Recommandations d'optimisation
            </h3>
            <p className="text-gray-700 dark:text-gray-300 mb-4">
              Basé sur l'analyse de vos données, voici des recommandations pour améliorer les performances de vos automatisations.
            </p>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {isLoading ? (
                Array.from({ length: 4 }).map((_, index) => (
                  <div
                    key={index}
                    className="h-20 bg-white/50 dark:bg-gray-700/50 rounded animate-pulse"
                  ></div>
                ))
              ) : (
                <>
                  <div className="flex items-start gap-3 bg-white/70 dark:bg-gray-800/50 p-4 rounded-lg">
                    <CheckCircle className="h-5 w-5 text-green-500 mt-0.5" />
                    <div>
                      <h4 className="font-medium text-gray-900 dark:text-gray-50">Pic d'activité identifié</h4>
                      <p className="text-sm text-gray-600 dark:text-gray-400">
                        Augmentez la capacité de traitement entre 10h et 14h pour réduire les temps d'attente.
                      </p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3 bg-white/70 dark:bg-gray-800/50 p-4 rounded-lg">
                    <CheckCircle className="h-5 w-5 text-green-500 mt-0.5" />
                    <div>
                      <h4 className="font-medium text-gray-900 dark:text-gray-50">Optimisation sémantique</h4>
                      <p className="text-sm text-gray-600 dark:text-gray-400">
                        Améliorez les réponses liées à "prix" et "livraison" qui ont un taux de résolution inférieur.
                      </p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3 bg-white/70 dark:bg-gray-800/50 p-4 rounded-lg">
                    <CheckCircle className="h-5 w-5 text-green-500 mt-0.5" />
                    <div>
                      <h4 className="font-medium text-gray-900 dark:text-gray-50">Canal à développer</h4>
                      <p className="text-sm text-gray-600 dark:text-gray-400">
                        Le canal Instagram montre une forte croissance (+27%) mais un faible taux d'automatisation.
                      </p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3 bg-white/70 dark:bg-gray-800/50 p-4 rounded-lg">
                    <CheckCircle className="h-5 w-5 text-green-500 mt-0.5" />
                    <div>
                      <h4 className="font-medium text-gray-900 dark:text-gray-50">Économie potentielle</h4>
                      <p className="text-sm text-gray-600 dark:text-gray-400">
                        L'augmentation de 15% du taux d'automatisation pourrait économiser 45h supplémentaires par semaine.
                      </p>
                    </div>
                  </div>
                </>
              )}
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
};

export default AIAnalytics;