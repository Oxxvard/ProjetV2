import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { 
  Eye, EyeOff, Copy, Check, Plus, Trash2, RefreshCw, 
  Shield, Lock, Key, AlertCircle, Clock
} from "lucide-react";
import { useTheme } from "@/context/ThemeContext";
import { useToast } from "@/hooks/use-toast";

interface ApiKey {
  id: string;
  name: string;
  key: string;
  service: string;
  createdAt: Date;
  expiresAt: Date | null;
  lastUsed: Date | null;
  permissions: string[];
}

const ApiKeyManager = () => {
  const [apiKeys, setApiKeys] = useState<ApiKey[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isAddingKey, setIsAddingKey] = useState(false);
  const [visibleKeys, setVisibleKeys] = useState<Record<string, boolean>>({});
  const [copiedKeyId, setCopiedKeyId] = useState<string | null>(null);
  const [confirmDelete, setConfirmDelete] = useState<string | null>(null);
  
  // Form state for new key
  const [newKeyName, setNewKeyName] = useState("");
  const [newKeyService, setNewKeyService] = useState("stripe");
  const [newKeyPermissions, setNewKeyPermissions] = useState<string[]>(["read"]);
  const [newKeyExpiry, setNewKeyExpiry] = useState<number | null>(30); // days
  
  const { resolvedTheme } = useTheme();
  const { toast } = useToast();
  
  const isDark = resolvedTheme === "dark";
  
  // Simuler le chargement des clés API
  useEffect(() => {
    const loadApiKeys = async () => {
      setIsLoading(true);
      
      // Delay pour simuler le chargement
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Données de test
      const mockApiKeys: ApiKey[] = [
        {
          id: "key_1",
          name: "Stripe Production",
          key: "sk_live_51NzT6LJHbRn9QEfJwkZIpQkNnT9qE4JMYF0lBo42YoM1i3zEcPLjzStAWgL",
          service: "stripe",
          createdAt: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000),
          expiresAt: null,
          lastUsed: new Date(Date.now() - 2 * 60 * 60 * 1000),
          permissions: ["read", "write"]
        },
        {
          id: "key_2",
          name: "OpenAI GPT-5",
          key: "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",
          service: "openai",
          createdAt: new Date(Date.now() - 15 * 24 * 60 * 60 * 1000),
          expiresAt: new Date(Date.now() + 75 * 24 * 60 * 60 * 1000),
          lastUsed: new Date(Date.now() - 12 * 60 * 60 * 1000),
          permissions: ["read"]
        },
        {
          id: "key_3",
          name: "WhatsApp Business API",
          key: "wba_qgY5F7u0gkPLnMxRtSjQwZdVcB3JfH2sXeA9D8rEbN4mCp",
          service: "whatsapp",
          createdAt: new Date(Date.now() - 60 * 24 * 60 * 60 * 1000),
          expiresAt: new Date(Date.now() + 120 * 24 * 60 * 60 * 1000),
          lastUsed: new Date(Date.now() - 18 * 60 * 60 * 1000),
          permissions: ["read", "write", "admin"]
        }
      ];
      
      setApiKeys(mockApiKeys);
      setIsLoading(false);
    };
    
    loadApiKeys();
  }, []);
  
  // Formatter une date en temps relatif
  const formatRelativeTime = (date: Date | null): string => {
    if (!date) return "Jamais";
    
    const now = new Date();
    const diffInSeconds = Math.floor((now.getTime() - date.getTime()) / 1000);
    
    if (diffInSeconds < 60) {
      return "Il y a quelques secondes";
    } else if (diffInSeconds < 3600) {
      const minutes = Math.floor(diffInSeconds / 60);
      return `Il y a ${minutes} minute${minutes > 1 ? 's' : ''}`;
    } else if (diffInSeconds < 86400) {
      const hours = Math.floor(diffInSeconds / 3600);
      return `Il y a ${hours} heure${hours > 1 ? 's' : ''}`;
    } else {
      const days = Math.floor(diffInSeconds / 86400);
      return `Il y a ${days} jour${days > 1 ? 's' : ''}`;
    }
  };
  
  // Formatter une date en temps restant
  const formatTimeRemaining = (date: Date | null): { text: string; isExpiringSoon: boolean } => {
    if (!date) return { text: "Jamais", isExpiringSoon: false };
    
    const now = new Date();
    const diffInSeconds = Math.floor((date.getTime() - now.getTime()) / 1000);
    
    if (diffInSeconds < 0) {
      return { text: "Expirée", isExpiringSoon: false };
    } else if (diffInSeconds < 86400) {
      const hours = Math.ceil(diffInSeconds / 3600);
      return { 
        text: `Expire dans ${hours} heure${hours > 1 ? 's' : ''}`, 
        isExpiringSoon: true 
      };
    } else {
      const days = Math.floor(diffInSeconds / 86400);
      return { 
        text: `Expire dans ${days} jour${days > 1 ? 's' : ''}`, 
        isExpiringSoon: days < 7 
      };
    }
  };
  
  // Masquer une clé API
  const maskApiKey = (key: string): string => {
    if (key.length <= 8) return "*".repeat(key.length);
    return `${key.substring(0, 4)}${"*".repeat(key.length - 8)}${key.substring(key.length - 4)}`;
  };
  
  // Copier une clé dans le presse-papier
  const copyToClipboard = (id: string, key: string) => {
    navigator.clipboard.writeText(key);
    setCopiedKeyId(id);
    
    setTimeout(() => {
      setCopiedKeyId(null);
    }, 2000);
  };
  
  // Supprimer une clé API
  const deleteApiKey = (id: string) => {
    setApiKeys(apiKeys.filter(key => key.id !== id));
    setConfirmDelete(null);
    
    toast({
      title: "Clé API supprimée",
      description: "La clé a été supprimée avec succès.",
      variant: "default",
    });
  };
  
  // Générer une nouvelle clé API
  const generateApiKey = () => {
    if (!newKeyName.trim()) {
      toast({
        title: "Nom requis",
        description: "Veuillez donner un nom à votre clé API.",
        variant: "destructive",
      });
      return;
    }
    
    // Générer une clé aléatoire selon le service
    const generateRandomKey = (service: string): string => {
      const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
      let prefix = "";
      let length = 32;
      
      switch (service) {
        case "stripe":
          prefix = "sk_live_";
          length = 40;
          break;
        case "openai":
          prefix = "sk-";
          length = 48;
          break;
        case "whatsapp":
          prefix = "wba_";
          length = 32;
          break;
        default:
          prefix = "key_";
          length = 32;
      }
      
      let result = prefix;
      for (let i = 0; i < length; i++) {
        result += chars.charAt(Math.floor(Math.random() * chars.length));
      }
      
      return result;
    };
    
    // Calculer la date d'expiration si nécessaire
    const calculateExpiryDate = (): Date | null => {
      if (!newKeyExpiry) return null;
      
      const expiryDate = new Date();
      expiryDate.setDate(expiryDate.getDate() + newKeyExpiry);
      return expiryDate;
    };
    
    const newKey: ApiKey = {
      id: `key_${Date.now()}`,
      name: newKeyName,
      key: generateRandomKey(newKeyService),
      service: newKeyService,
      createdAt: new Date(),
      expiresAt: calculateExpiryDate(),
      lastUsed: null,
      permissions: newKeyPermissions
    };
    
    setApiKeys([newKey, ...apiKeys]);
    setIsAddingKey(false);
    
    // Réinitialiser le formulaire
    setNewKeyName("");
    setNewKeyService("stripe");
    setNewKeyPermissions(["read"]);
    setNewKeyExpiry(30);
    
    toast({
      title: "Clé API créée",
      description: "Votre nouvelle clé API a été générée avec succès.",
      variant: "default",
    });
    
    // Afficher la clé nouvellement générée
    setVisibleKeys({...visibleKeys, [newKey.id]: true});
  };
  
  // Renouveler une clé API
  const renewApiKey = (id: string) => {
    setApiKeys(apiKeys.map(key => {
      if (key.id === id) {
        // Générer une nouvelle clé mais conserver les autres paramètres
        const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
        let prefix = key.key.split('_')[0] + '_';
        let length = key.key.length - prefix.length;
        
        let newKeyString = prefix;
        for (let i = 0; i < length; i++) {
          newKeyString += chars.charAt(Math.floor(Math.random() * chars.length));
        }
        
        return {
          ...key,
          key: newKeyString,
          createdAt: new Date(),
          expiresAt: key.expiresAt ? new Date(Date.now() + 90 * 24 * 60 * 60 * 1000) : null,
          lastUsed: null
        };
      }
      return key;
    }));
    
    toast({
      title: "Clé API renouvelée",
      description: "Votre clé API a été renouvelée avec succès.",
      variant: "default",
    });
  };
  
  // Gérer le changement de permissions
  const handlePermissionChange = (permission: string) => {
    if (newKeyPermissions.includes(permission)) {
      setNewKeyPermissions(newKeyPermissions.filter(p => p !== permission));
    } else {
      setNewKeyPermissions([...newKeyPermissions, permission]);
    }
  };
  
  // Obtenir la couleur du service
  const getServiceColor = (service: string): string => {
    switch (service) {
      case "stripe":
        return "text-purple-500 bg-purple-100 dark:bg-purple-900/30 dark:text-purple-300";
      case "openai":
        return "text-green-500 bg-green-100 dark:bg-green-900/30 dark:text-green-300";
      case "whatsapp":
        return "text-emerald-500 bg-emerald-100 dark:bg-emerald-900/30 dark:text-emerald-300";
      default:
        return "text-blue-500 bg-blue-100 dark:bg-blue-900/30 dark:text-blue-300";
    }
  };

  return (
    <div className="space-y-6">
      {/* En-tête */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-gray-900 dark:text-gray-100">
            Gestionnaire de clés API
          </h2>
          <p className="text-gray-600 dark:text-gray-400">
            Gérez les clés API pour les services externes
          </p>
        </div>
        <button
          onClick={() => setIsAddingKey(!isAddingKey)}
          className={`px-4 py-2 rounded-lg flex items-center ${
            isAddingKey 
              ? 'bg-gray-200 dark:bg-gray-700 text-gray-800 dark:text-gray-200' 
              : 'bg-primary text-white'
          }`}
        >
          {isAddingKey ? (
            <>
              <span>Annuler</span>
            </>
          ) : (
            <>
              <Plus className="mr-1.5 h-4 w-4" />
              <span>Nouvelle clé</span>
            </>
          )}
        </button>
      </div>
      
      {/* Formulaire d'ajout de clé */}
      {isAddingKey && (
        <motion.div
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: "auto" }}
          exit={{ opacity: 0, height: 0 }}
          className={`rounded-lg border p-6 mb-6 ${
            isDark ? 'bg-gray-800 border-gray-700' : 'bg-white border-gray-200'
          }`}
        >
          <h3 className="text-lg font-medium text-gray-900 dark:text-gray-100 mb-4">
            Générer une nouvelle clé API
          </h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                Nom de la clé
              </label>
              <input
                type="text"
                value={newKeyName}
                onChange={(e) => setNewKeyName(e.target.value)}
                placeholder="Ex: Stripe Production"
                className={`w-full px-3 py-2 rounded-md border focus:ring-2 focus:ring-primary/50 ${
                  isDark 
                    ? 'bg-gray-700 border-gray-600 text-white' 
                    : 'bg-white border-gray-300 text-gray-900'
                }`}
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                Service
              </label>
              <select
                value={newKeyService}
                onChange={(e) => setNewKeyService(e.target.value)}
                className={`w-full px-3 py-2 rounded-md border focus:ring-2 focus:ring-primary/50 ${
                  isDark 
                    ? 'bg-gray-700 border-gray-600 text-white' 
                    : 'bg-white border-gray-300 text-gray-900'
                }`}
              >
                <option value="stripe">Stripe</option>
                <option value="openai">OpenAI</option>
                <option value="whatsapp">WhatsApp Business API</option>
                <option value="other">Autre</option>
              </select>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                Permissions
              </label>
              <div className="flex flex-wrap gap-2">
                {["read", "write", "admin"].map((permission) => (
                  <button
                    key={permission}
                    type="button"
                    onClick={() => handlePermissionChange(permission)}
                    className={`px-3 py-1.5 text-sm rounded-md ${
                      newKeyPermissions.includes(permission)
                        ? 'bg-primary-100 dark:bg-primary-900/30 text-primary-700 dark:text-primary-300 border border-primary-300 dark:border-primary-800'
                        : isDark
                        ? 'bg-gray-700 text-gray-300 border border-gray-600'
                        : 'bg-gray-100 text-gray-700 border border-gray-300'
                    }`}
                  >
                    {permission.charAt(0).toUpperCase() + permission.slice(1)}
                  </button>
                ))}
              </div>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                Expiration
              </label>
              <select
                value={newKeyExpiry?.toString() || "null"}
                onChange={(e) => setNewKeyExpiry(e.target.value === "null" ? null : parseInt(e.target.value))}
                className={`w-full px-3 py-2 rounded-md border focus:ring-2 focus:ring-primary/50 ${
                  isDark 
                    ? 'bg-gray-700 border-gray-600 text-white' 
                    : 'bg-white border-gray-300 text-gray-900'
                }`}
              >
                <option value="null">Pas d'expiration</option>
                <option value="7">7 jours</option>
                <option value="30">30 jours</option>
                <option value="90">90 jours</option>
                <option value="365">1 an</option>
              </select>
            </div>
          </div>
          
          <div className="mt-6 flex justify-end">
            <button
              onClick={generateApiKey}
              className="px-4 py-2 bg-primary text-white rounded-lg flex items-center"
            >
              <Key className="mr-1.5 h-4 w-4" />
              <span>Générer la clé API</span>
            </button>
          </div>
        </motion.div>
      )}
      
      {/* Avertissement de sécurité */}
      <div className={`p-4 rounded-lg flex items-start gap-3 ${
        isDark ? 'bg-yellow-900/20 text-yellow-200' : 'bg-yellow-50 text-yellow-800'
      }`}>
        <AlertCircle className="h-5 w-5 mt-0.5" />
        <div>
          <h3 className="font-medium mb-1">Consignes de sécurité importantes</h3>
          <p className="text-sm">
            Vos clés API sont des informations sensibles qui accordent l'accès à vos ressources. 
            Ne les partagez jamais, utilisez des permissions restreintes, et renouvelez-les régulièrement.
          </p>
        </div>
      </div>
      
      {/* Liste des clés API */}
      <div className={`rounded-lg border overflow-hidden ${
        isDark ? 'border-gray-700' : 'border-gray-200'
      }`}>
        <div className={`px-4 py-3 ${
          isDark ? 'bg-gray-800' : 'bg-gray-50'
        }`}>
          <div className="flex justify-between items-center">
            <h3 className="font-medium text-gray-900 dark:text-gray-100">
              Clés API actives
            </h3>
            <div className="text-sm text-gray-500 dark:text-gray-400">
              {apiKeys.length} clé{apiKeys.length !== 1 ? 's' : ''} active{apiKeys.length !== 1 ? 's' : ''}
            </div>
          </div>
        </div>
        
        {isLoading ? (
          <div className="p-6 space-y-4">
            {[1, 2, 3].map((_, index) => (
              <div 
                key={index}
                className={`h-24 rounded-lg animate-pulse ${
                  isDark ? 'bg-gray-700' : 'bg-gray-100'
                }`} 
              />
            ))}
          </div>
        ) : apiKeys.length === 0 ? (
          <div className="p-12 text-center">
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-gray-100 dark:bg-gray-800 mb-4">
              <Key className="h-8 w-8 text-gray-400" />
            </div>
            <h3 className="text-lg font-medium text-gray-900 dark:text-gray-100 mb-2">
              Aucune clé API
            </h3>
            <p className="text-gray-500 dark:text-gray-400 mb-6 max-w-md mx-auto">
              Vous n'avez pas encore créé de clés API. Générez une nouvelle clé pour commencer à utiliser les services externes.
            </p>
            <button
              onClick={() => setIsAddingKey(true)}
              className="px-4 py-2 bg-primary text-white rounded-lg inline-flex items-center"
            >
              <Plus className="mr-1.5 h-4 w-4" />
              <span>Nouvelle clé API</span>
            </button>
          </div>
        ) : (
          <div className="divide-y dark:divide-gray-700">
            {apiKeys.map((apiKey) => {
              const expiryInfo = formatTimeRemaining(apiKey.expiresAt);
              
              return (
                <div 
                  key={apiKey.id}
                  className={`p-4 ${
                    isDark ? 'hover:bg-gray-800' : 'hover:bg-gray-50'
                  }`}
                >
                  <div className="flex justify-between flex-wrap gap-4">
                    <div className="space-y-1">
                      <div className="flex items-center">
                        <h4 className="font-medium text-gray-900 dark:text-gray-100">
                          {apiKey.name}
                        </h4>
                        <span className={`ml-2 text-xs px-2 py-0.5 rounded-full ${getServiceColor(apiKey.service)}`}>
                          {apiKey.service}
                        </span>
                      </div>
                      
                      <div className="flex items-center space-x-6 text-xs text-gray-500 dark:text-gray-400">
                        <div className="flex items-center">
                          <Shield className="h-3 w-3 mr-1" />
                          <span>
                            {apiKey.permissions.map(p => p.charAt(0).toUpperCase() + p.slice(1)).join(", ")}
                          </span>
                        </div>
                        <div className="flex items-center">
                          <Clock className="h-3 w-3 mr-1" />
                          <span>
                            Créée {formatRelativeTime(apiKey.createdAt)}
                          </span>
                        </div>
                        {apiKey.lastUsed && (
                          <div className="flex items-center">
                            <RefreshCw className="h-3 w-3 mr-1" />
                            <span>
                              Utilisée {formatRelativeTime(apiKey.lastUsed)}
                            </span>
                          </div>
                        )}
                      </div>
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      {expiryInfo.isExpiringSoon && (
                        <span className="text-xs px-2 py-0.5 bg-red-100 dark:bg-red-900/30 text-red-800 dark:text-red-300 rounded-full">
                          {expiryInfo.text}
                        </span>
                      )}
                      <button
                        onClick={() => renewApiKey(apiKey.id)}
                        className={`p-1.5 rounded-md text-sm ${
                          isDark
                            ? 'hover:bg-gray-700 text-gray-400 hover:text-gray-300'
                            : 'hover:bg-gray-200 text-gray-500 hover:text-gray-700'
                        }`}
                        title="Renouveler la clé"
                      >
                        <RefreshCw className="h-4 w-4" />
                      </button>
                      <button
                        onClick={() => setConfirmDelete(apiKey.id === confirmDelete ? null : apiKey.id)}
                        className={`p-1.5 rounded-md text-sm ${
                          apiKey.id === confirmDelete
                            ? 'bg-red-100 dark:bg-red-900/30 text-red-600 dark:text-red-400'
                            : isDark
                            ? 'hover:bg-gray-700 text-gray-400 hover:text-gray-300'
                            : 'hover:bg-gray-200 text-gray-500 hover:text-gray-700'
                        }`}
                        title="Supprimer la clé"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                  </div>
                  
                  <div className="mt-3 flex items-center">
                    <div className={`flex-1 font-mono text-sm py-1.5 px-3 rounded ${
                      isDark ? 'bg-gray-800' : 'bg-gray-100'
                    }`}>
                      {visibleKeys[apiKey.id] ? apiKey.key : maskApiKey(apiKey.key)}
                    </div>
                    <div className="ml-3 flex space-x-2">
                      <button
                        onClick={() => {
                          const newVisibleKeys = {...visibleKeys};
                          newVisibleKeys[apiKey.id] = !newVisibleKeys[apiKey.id];
                          setVisibleKeys(newVisibleKeys);
                        }}
                        className={`p-1.5 rounded-md ${
                          isDark
                            ? 'hover:bg-gray-700 text-gray-400 hover:text-gray-300'
                            : 'hover:bg-gray-200 text-gray-500 hover:text-gray-700'
                        }`}
                      >
                        {visibleKeys[apiKey.id] ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                      </button>
                      <button
                        onClick={() => copyToClipboard(apiKey.id, apiKey.key)}
                        className={`p-1.5 rounded-md ${
                          isDark
                            ? 'hover:bg-gray-700 text-gray-400 hover:text-gray-300'
                            : 'hover:bg-gray-200 text-gray-500 hover:text-gray-700'
                        }`}
                      >
                        {copiedKeyId === apiKey.id ? <Check className="h-4 w-4 text-green-500" /> : <Copy className="h-4 w-4" />}
                      </button>
                    </div>
                  </div>
                  
                  {apiKey.id === confirmDelete && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: "auto" }}
                      className="mt-3"
                    >
                      <div className={`p-3 rounded-lg border ${
                        isDark
                          ? 'border-red-800 bg-red-900/20 text-red-200'
                          : 'border-red-200 bg-red-50 text-red-800'
                      }`}>
                        <p className="text-sm mb-2">
                          Êtes-vous sûr de vouloir supprimer cette clé API ? Cette action est irréversible.
                        </p>
                        <div className="flex space-x-3">
                          <button
                            onClick={() => setConfirmDelete(null)}
                            className={`px-3 py-1 text-sm rounded-md ${
                              isDark
                                ? 'bg-gray-700 text-gray-300 hover:bg-gray-600'
                                : 'bg-white text-gray-700 border border-gray-300 hover:bg-gray-50'
                            }`}
                          >
                            Annuler
                          </button>
                          <button
                            onClick={() => deleteApiKey(apiKey.id)}
                            className="px-3 py-1 text-sm bg-red-600 hover:bg-red-700 text-white rounded-md"
                          >
                            Supprimer définitivement
                          </button>
                        </div>
                      </div>
                    </motion.div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};

export default ApiKeyManager;