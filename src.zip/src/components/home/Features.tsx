import { motion } from "framer-motion";
import { Link } from "wouter";

interface FeatureCardProps {
  icon: string;
  title: string;
  description: string;
  emoji: string;
  link: string;
  index: number;
}

const FeatureCard = ({ icon, title, description, emoji, link, index }: FeatureCardProps) => {
  return (
    <motion.div 
      className="feature-card relative bg-white rounded-2xl shadow-lg overflow-hidden border border-neutral-100 hover:border-primary-200 transition-all duration-300 hover:shadow-xl group"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3, delay: 0.1 * index }}
      whileHover={{ y: -8 }}
    >
      {/* Gradient background effect */}
      <div className="absolute inset-0 bg-gradient-to-br from-primary-50 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
      
      <div className="p-8 relative z-10">
        {/* Top accent line */}
        <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-transparent via-primary-500 to-transparent transform translate-y-0 opacity-0 group-hover:opacity-100 transition-all duration-300"></div>
        
        <div className="w-16 h-16 bg-primary-100 rounded-2xl flex items-center justify-center mb-6 group-hover:bg-primary-200 transition-colors duration-300">
          <i className={`${icon} text-2xl text-primary-600`}></i>
        </div>
        
        <h3 className="text-2xl font-bold text-neutral-900 mb-3 flex items-center">
          {title} <span className="ml-2 text-2xl transform group-hover:scale-125 transition-transform duration-300">{emoji}</span>
        </h3>
        
        <p className="text-neutral-600 mb-6 text-lg">{description}</p>
        
        <Link href={link}>
          <a className="text-primary-600 font-semibold inline-flex items-center relative overflow-hidden group-hover:text-primary-700 transition-colors duration-300">
            <span>En savoir plus</span>
            <motion.div
              className="ml-2"
              initial={{ x: 0 }}
              whileHover={{ x: 5 }}
              transition={{ duration: 0.2 }}
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7m0 0l-7 7m7-7H3" />
              </svg>
            </motion.div>
          </a>
        </Link>
        
        {/* Custom decoration */}
        <div className="absolute -bottom-4 -right-4 w-16 h-16 rounded-full bg-primary-100 opacity-0 group-hover:opacity-70 transition-opacity duration-300"></div>
      </div>
    </motion.div>
  );
};

const Features = () => {
  const features = [
    {
      icon: "fas fa-robot",
      title: "Chatbots IA",
      emoji: "🤖",
      description:
        "Répondez instantanément 24/7 aux questions de vos clients sur WhatsApp, Instagram et votre site web sans aucune intervention humaine.",
      link: "#chatbot-details",
    },
    {
      icon: "fas fa-star",
      title: "Avis Google Auto",
      emoji: "⭐",
      description:
        "Collectez automatiquement des avis 5 étoiles et répondez aux commentaires de vos clients pour améliorer votre réputation en ligne.",
      link: "#reviews-details",
    },
    {
      icon: "fas fa-envelope",
      title: "Emails Intelligents",
      emoji: "📧",
      description:
        "Personnalisez et automatisez vos séquences d'emails pour convertir plus de prospects et fidéliser vos clients existants.",
      link: "#email-details",
    },
    {
      icon: "fas fa-funnel-dollar",
      title: "Tunnels de Vente",
      emoji: "💰",
      description:
        "Créez des tunnels de conversion optimisés sans coder qui transforment les visiteurs en clients fidèles et augmentent vos revenus.",
      link: "#funnel-details",
    },
    {
      icon: "fas fa-comment-dots",
      title: "SMS Marketing",
      emoji: "📱",
      description:
        "Envoyez des campagnes SMS personnalisées et automatisées avec des taux d'ouverture de 98% et des conversions immédiates.",
      link: "#sms-details",
    },
    {
      icon: "fas fa-calendar-check",
      title: "Prise de RDV",
      emoji: "🗓️",
      description:
        "Automatisez la prise de rendez-vous, les rappels et les confirmations pour éliminer les no-shows et optimiser votre agenda.",
      link: "#calendar-details",
    },
    {
      icon: "fas fa-chart-line",
      title: "Analytics",
      emoji: "📊",
      description:
        "Visualisez l'impact de vos automatisations avec des tableaux de bord en temps réel et des rapports détaillés sur vos performances.",
      link: "#analytics-details",
    },
    {
      icon: "fas fa-bolt",
      title: "Intégrations API",
      emoji: "⚡",
      description:
        "Connectez toutes vos applications et outils favoris pour créer un écosystème d'automatisation fluide et sans friction.",
      link: "#integration-details",
    },
  ];

  return (
    <section id="solutions" className="py-24 bg-white relative overflow-hidden">
      {/* Background elements */}
      <div className="absolute top-0 right-0 w-1/3 h-1/3 bg-primary-50 opacity-70 rounded-full blur-3xl -translate-y-1/2 translate-x-1/3"></div>
      <div className="absolute bottom-0 left-0 w-1/4 h-1/4 bg-blue-50 opacity-70 rounded-full blur-3xl translate-y-1/3 -translate-x-1/3"></div>
      
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <div className="inline-block px-6 py-2 bg-primary-100 text-primary-800 rounded-full mb-6 font-medium">
            Solutions intelligentes
          </div>
          <h2 className="text-4xl sm:text-5xl font-bold text-neutral-900 mb-6">
            Automatisez votre business <span className="text-primary-600">sans limite</span> 🚀
          </h2>
          <p className="max-w-3xl mx-auto text-xl text-neutral-700">
            Nos outils No-Code propulsés par l'IA éliminent les tâches répétitives, réduisent vos coûts et augmentent votre chiffre d'affaires.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => (
            <FeatureCard
              key={index}
              icon={feature.icon}
              title={feature.title}
              emoji={feature.emoji}
              description={feature.description}
              link={feature.link}
              index={index}
            />
          ))}
        </div>
        
        <motion.div 
          className="mt-20 text-center"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.8, duration: 0.5 }}
        >
          <Link href="#pricing">
            <a className="inline-flex items-center justify-center px-8 py-4 bg-primary-600 text-white font-medium rounded-xl shadow-lg hover:bg-primary-700 transition-all duration-300 hover:shadow-xl transform hover:-translate-y-1">
              Découvrir tous nos services
              <svg className="ml-2 w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8l4 4m0 0l-4 4m4-4H3" />
              </svg>
            </a>
          </Link>
        </motion.div>
      </div>
    </section>
  );
};

export default Features;
