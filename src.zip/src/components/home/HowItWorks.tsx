import { motion } from "framer-motion";
import { useState } from "react";

const HowItWorks = () => {
  const [hoveredStep, setHoveredStep] = useState<number | null>(null);

  return (
    <section className="py-24 bg-gradient-to-b from-white to-neutral-50 relative overflow-hidden">
      {/* Background decorative elements */}
      <div className="absolute top-0 left-1/4 w-64 h-64 bg-primary-50 rounded-full mix-blend-multiply filter blur-3xl opacity-70 animate-blob"></div>
      <div className="absolute top-1/3 right-1/4 w-72 h-72 bg-blue-50 rounded-full mix-blend-multiply filter blur-3xl opacity-70 animate-blob animation-delay-2000"></div>
      <div className="absolute bottom-1/4 left-1/3 w-80 h-80 bg-purple-50 rounded-full mix-blend-multiply filter blur-3xl opacity-70 animate-blob animation-delay-4000"></div>
      
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <motion.div 
          className="text-center mb-20"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <div className="inline-block px-6 py-2 bg-primary-100 text-primary-800 rounded-full mb-6 font-medium">
            Approche simplifiée
          </div>
          <h2 className="text-4xl sm:text-5xl font-bold text-neutral-900 mb-6">
            Comment nous <span className="text-primary-600">transformons</span> votre business 🚀
          </h2>
          <p className="max-w-3xl mx-auto text-xl text-neutral-700">
            Notre processus clé en main vous permet d'automatiser vos tâches sans expertise technique,
            en seulement quelques jours.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          <div className="relative">
            <motion.div 
              className="relative z-10 bg-white rounded-2xl shadow-xl overflow-hidden border border-neutral-100"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              {/* Browser mockup frame */}
              <div className="h-12 bg-neutral-100 flex items-center px-4 border-b border-neutral-200">
                <div className="flex space-x-2">
                  <div className="w-3 h-3 rounded-full bg-red-400"></div>
                  <div className="w-3 h-3 rounded-full bg-yellow-400"></div>
                  <div className="w-3 h-3 rounded-full bg-green-400"></div>
                </div>
                <div className="mx-auto px-4 py-1 rounded-full bg-white text-xs text-neutral-500 flex items-center">
                  <svg className="w-3 h-3 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"></path>
                  </svg>
                  automationhub.app/dashboard
                </div>
              </div>
              
              <img 
                src="https://images.unsplash.com/photo-1522542550221-31fd19575a2d?ixlib=rb-1.2.1&auto=format&fit=crop&w=1200&q=80" 
                alt="Plateforme d'automatisation" 
                className="w-full h-auto" 
              />
            </motion.div>
            
            {/* Decorative elements */}
            <div className="absolute top-1/2 left-0 transform -translate-x-1/2 -translate-y-1/2 w-32 h-32 bg-primary-100 rounded-full opacity-80 blur-xl z-0"></div>
            <div className="absolute bottom-10 right-10 w-24 h-24 bg-blue-100 rounded-full opacity-80 blur-xl z-0"></div>
            
            {/* Floating badges */}
            <motion.div 
              className="absolute -bottom-6 -right-6 bg-white p-4 rounded-xl shadow-lg flex items-center max-w-xs"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.6, duration: 0.3 }}
            >
              <div className="w-10 h-10 rounded-full bg-green-100 flex items-center justify-center mr-3 flex-shrink-0">
                <svg className="w-5 h-5 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                </svg>
              </div>
              <p className="text-sm font-medium text-neutral-800">Mise en place en moins de 72h pour la plupart des solutions</p>
            </motion.div>
          </div>
          
          <div>
            <div className="relative pl-8 before:content-[''] before:absolute before:left-4 before:top-0 before:bottom-0 before:w-0.5 before:bg-gradient-to-b before:from-primary-500 before:via-blue-500 before:to-indigo-500">
              {[
                {
                  number: 1,
                  title: "Audit et stratégie",
                  emoji: "🔍",
                  description: "Nous analysons vos processus actuels et identifions les opportunités d'automatisation avec le meilleur retour sur investissement.",
                  icon: (
                    <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01"></path>
                    </svg>
                  )
                },
                {
                  number: 2,
                  title: "Configuration sur mesure",
                  emoji: "⚙️",
                  description: "Nos experts configurent les solutions d'automatisation adaptées à vos besoins spécifiques, sans que vous ayez à écrire une seule ligne de code.",
                  icon: (
                    <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"></path>
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"></path>
                    </svg>
                  )
                },
                {
                  number: 3,
                  title: "Formation & déploiement",
                  emoji: "🚀",
                  description: "Nous déployons vos solutions d'automatisation et formons votre équipe à les utiliser efficacement pour une transition en douceur.",
                  icon: (
                    <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z"></path>
                    </svg>
                  )
                },
                {
                  number: 4,
                  title: "Optimisation continue",
                  emoji: "📈",
                  description: "Nous analysons les performances de vos automatisations et les optimisons en continu pour maximiser votre ROI et votre productivité.",
                  icon: (
                    <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 8v8m-4-5v5m-4-2v2m-2 4h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"></path>
                    </svg>
                  )
                }
              ].map((step, index) => (
                <Step 
                  key={index}
                  step={step}
                  isHovered={hoveredStep === step.number}
                  onHover={() => setHoveredStep(step.number)}
                  onLeave={() => setHoveredStep(null)}
                  isLast={index === 3}
                />
              ))}
            </div>
            
            <motion.div 
              className="mt-12 pl-8"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.8, duration: 0.5 }}
            >
              <div className="p-6 bg-primary-50 rounded-xl border border-primary-100">
                <div className="flex items-start mb-4">
                  <div className="bg-primary-100 p-3 rounded-lg mr-4">
                    <svg className="w-6 h-6 text-primary-600" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                    </svg>
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-neutral-900">Un accompagnement complet</h3>
                    <p className="text-neutral-700">Notre abonnement mensuel inclut le support illimité, la maintenance et des améliorations régulières de vos automatisations.</p>
                  </div>
                </div>
                <ul className="space-y-2 pl-4">
                  <li className="flex items-center">
                    <svg className="w-5 h-5 text-green-500 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                    </svg>
                    <span className="text-neutral-700">Support prioritaire par chat et email</span>
                  </li>
                  <li className="flex items-center">
                    <svg className="w-5 h-5 text-green-500 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                    </svg>
                    <span className="text-neutral-700">Mises à jour régulières des automatisations</span>
                  </li>
                  <li className="flex items-center">
                    <svg className="w-5 h-5 text-green-500 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                    </svg>
                    <span className="text-neutral-700">Dashboards et rapports de performance mensuels</span>
                  </li>
                </ul>
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </section>
  );
};

interface StepProps {
  step: {
    number: number;
    title: string;
    emoji: string;
    description: string;
    icon: React.ReactNode;
  };
  isHovered: boolean;
  onHover: () => void;
  onLeave: () => void;
  isLast: boolean;
}

const Step = ({ step, isHovered, onHover, onLeave, isLast }: StepProps) => {
  return (
    <motion.div 
      className={`relative mb-14 ${isLast ? 'mb-0' : ''}`}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3, delay: 0.1 * step.number }}
      onMouseEnter={onHover}
      onMouseLeave={onLeave}
    >
      {/* Timeline node */}
      <motion.div 
        className={`absolute -left-8 w-9 h-9 rounded-full flex items-center justify-center z-10 border-2 transition-all duration-300 ${
          isHovered 
            ? "bg-primary-500 border-white text-white scale-125" 
            : "bg-white border-primary-300 text-primary-600"
        }`}
        animate={{ 
          scale: isHovered ? 1.2 : 1
        }}
        style={{
          backgroundColor: isHovered ? "#6366F1" : "white",
          color: isHovered ? "white" : "#4F46E5"
        }}
      >
        {step.icon}
      </motion.div>
      
      {/* Step content */}
      <div className={`bg-white rounded-xl p-6 shadow-md border transition-all duration-300 ${
        isHovered 
          ? "border-primary-300 -translate-y-1 shadow-lg" 
          : "border-neutral-200"
      }`}>
        <div className="flex justify-between items-center mb-3">
          <h3 className="text-xl font-bold text-neutral-900 flex items-center">
            <span className="text-primary-600 mr-2">{step.number}.</span>
            {step.title}
            <span className="ml-2 text-2xl">{step.emoji}</span>
          </h3>
          <span className={`px-3 py-1 rounded-full text-xs font-medium ${
            step.number === 1 ? "bg-blue-100 text-blue-700" :
            step.number === 2 ? "bg-green-100 text-green-700" :
            step.number === 3 ? "bg-yellow-100 text-yellow-700" :
            "bg-purple-100 text-purple-700"
          }`}>
            {step.number === 1 ? "Jour 1" :
             step.number === 2 ? "Jour 2-3" :
             step.number === 3 ? "Jour 4-5" :
             "Continu"}
          </span>
        </div>
        <p className="text-neutral-700">{step.description}</p>
      </div>
    </motion.div>
  );
};

export default HowItWorks;
