import { useState } from "react";
import { motion } from "framer-motion";
import TrialModal from "@/components/auth/TrialModal";
import { useAuth } from "@/hooks/useAuth";
import { Link } from "wouter";

interface PlanFeature {
  text: string;
  included: boolean;
}

interface PricingPlanProps {
  name: string;
  price: string;
  period: string;
  description: string;
  features: PlanFeature[];
  buttonText: string;
  buttonLink: string;
  isPopular?: boolean;
  onButtonClick?: () => void;
  icon: string;
  color: string;
  users: string;
  index: number;
}

const PricingPlan = ({
  name,
  price,
  period,
  description,
  features,
  buttonText,
  buttonLink,
  isPopular = false,
  onButtonClick,
  icon,
  color,
  users,
  index
}: PricingPlanProps) => {
  return (
    <motion.div
      className={`relative rounded-2xl shadow-lg overflow-hidden transition-all duration-300 h-full ${
        isPopular
          ? "border-2 border-primary-500 z-10"
          : "border border-neutral-200 hover:border-primary-300 hover:shadow-xl"
      }`}
      initial={{ opacity: 0, y: 30 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, delay: 0.1 * index }}
      whileHover={isPopular ? {} : { y: -10 }}
      style={{ 
        backgroundColor: isPopular ? `${color}10` : "white",
      }}
    >
      {/* Top corner decoration */}
      <div 
        className="absolute top-0 right-0 w-20 h-20" 
        style={{ 
          backgroundColor: `${color}10`,
          clipPath: 'polygon(100% 0, 0 0, 100% 100%)'
        }}
      ></div>
      
      {isPopular && (
        <div className="absolute top-0 right-0 mt-6 -mr-12 rotate-45 w-36 bg-primary-600 py-1.5 text-center z-20">
          <span className="text-white font-medium text-xs uppercase tracking-wider">Recommandé</span>
        </div>
      )}
      
      <div className="p-8">
        {/* Plan icon & name */}
        <div className="flex items-center mb-4">
          <div 
            className="w-12 h-12 rounded-lg flex items-center justify-center mr-4"
            style={{ backgroundColor: `${color}20` }}
          >
            <i className={`${icon} text-xl`} style={{ color: color }}></i>
          </div>
          <div>
            <h3 className="text-xl font-bold text-neutral-900">{name}</h3>
            <p className="text-sm text-neutral-500">{users}</p>
          </div>
        </div>
        
        {/* Price */}
        <div className="mb-6">
          <div className="flex items-baseline">
            <span className="text-4xl font-bold text-neutral-900">{price}</span>
            {period && <span className="text-neutral-500 ml-2">/{period}</span>}
          </div>
          {isPopular && (
            <div className="mt-1 text-primary-700 text-sm font-medium">
              Essai gratuit de 7 jours
            </div>
          )}
        </div>
        
        <p className="text-neutral-600 mb-6 min-h-[60px]">{description}</p>
        
        {/* Features */}
        <div className="space-y-4 mb-8">
          {features.map((feature, i) => (
            <div key={i} className="flex items-start">
              <span className={`flex-shrink-0 w-5 h-5 rounded-full ${feature.included ? 'bg-green-100' : 'bg-neutral-100'} flex items-center justify-center mr-3 mt-0.5`}>
                {feature.included ? (
                  <svg className="w-3 h-3 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7"></path>
                  </svg>
                ) : (
                  <svg className="w-3 h-3 text-neutral-400" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M6 18L18 6M6 6l12 12"></path>
                  </svg>
                )}
              </span>
              <span className={`text-sm ${feature.included ? 'text-neutral-700' : 'text-neutral-400'}`}>{feature.text}</span>
            </div>
          ))}
        </div>
        
        {/* Button */}
        {buttonLink ? (
          <Link href={buttonLink}>
            <motion.div
              className={`block w-full py-3.5 px-4 rounded-xl font-medium text-center transition duration-200 ease-in-out cursor-pointer ${
                isPopular
                  ? "bg-primary-600 text-white hover:bg-primary-700 shadow-md"
                  : "bg-white text-neutral-700 border border-neutral-300 hover:border-primary-300 hover:text-primary-600"
              }`}
              whileHover={{ y: -3 }}
              whileTap={{ y: 0 }}
            >
              {buttonText}
            </motion.div>
          </Link>
        ) : (
          <motion.button
            onClick={onButtonClick}
            className={`block w-full py-3.5 px-4 rounded-xl font-medium text-center transition duration-200 ease-in-out ${
              isPopular
                ? "bg-primary-600 text-white hover:bg-primary-700 shadow-md"
                : "bg-white text-neutral-700 border border-neutral-300 hover:border-primary-300 hover:text-primary-600"
            }`}
            whileHover={{ y: -3 }}
            whileTap={{ y: 0 }}
          >
            {buttonText}
          </motion.button>
        )}
      </div>
    </motion.div>
  );
};

const Pricing = () => {
  const [isTrialModalOpen, setIsTrialModalOpen] = useState(false);
  const [pricingPeriod, setPricingPeriod] = useState<'monthly' | 'annual'>('monthly');
  const { user } = useAuth();
  
  const discount = 20; // 20% discount for annual billing
  
  const plans = [
    {
      name: "Starter",
      icon: "fas fa-rocket",
      color: "#6366F1", // Indigo
      users: "Pour freelances & TPE",
      monthlyPrice: "0",
      annualPrice: "0",
      description: "Essayez gratuitement les fonctionnalités de base pour automatiser votre présence en ligne.",
      features: [
        { text: "1 chatbot simple (mode FAQ)", included: true },
        { text: "100 messages/mois", included: true },
        { text: "1 canal (site web uniquement)", included: true },
        { text: "Support par email", included: true },
        { text: "Intégration avec Google Analytics", included: true },
        { text: "Automatisation des avis Google", included: false },
        { text: "Formation & onboarding", included: false },
        { text: "Multi-canaux (WhatsApp, Instagram)", included: false },
        { text: "Intégrations avancées", included: false },
        { text: "Gestionnaire de compte dédié", included: false },
      ],
      buttonText: "Commencer gratuitement",
      buttonLink: user ? "/dashboard" : "#",
      onButtonClick: user ? undefined : () => setIsTrialModalOpen(true),
    },
    {
      name: "Pro",
      icon: "fas fa-fire",
      color: "#8B5CF6", // Violet
      users: "Idéal pour PME & commerçants",
      monthlyPrice: "499",
      annualPrice: Math.round(499 * 12 * (1 - discount / 100) / 12).toString(),
      description: "Automatisez vos tâches répétitives et boostez votre croissance avec l'IA.",
      features: [
        { text: "3 chatbots IA avancés", included: true },
        { text: "Messages illimités", included: true },
        { text: "Multi-canaux (Web, WhatsApp, Insta)", included: true },
        { text: "Automatisation des avis Google", included: true },
        { text: "1 tunnel de vente personnalisé", included: true },
        { text: "Support prioritaire", included: true },
        { text: "Formation & onboarding inclus", included: true },
        { text: "Intégrations CRM & ERP", included: true },
        { text: "Rapports mensuels de performance", included: true },
        { text: "Gestionnaire de compte dédié", included: false },
      ],
      buttonText: "Essai gratuit 7 jours",
      buttonLink: "",
      onButtonClick: () => setIsTrialModalOpen(true),
      isPopular: true,
    },
    {
      name: "Entreprise",
      icon: "fas fa-building",
      color: "#EC4899", // Pink
      users: "Pour entreprises & franchises",
      monthlyPrice: "Sur mesure",
      annualPrice: "Sur mesure",
      description: "Solutions personnalisées pour automatiser vos processus à grande échelle.",
      features: [
        { text: "Chatbots IA illimités", included: true },
        { text: "Volume illimité", included: true },
        { text: "Tous les canaux disponibles", included: true },
        { text: "Intégrations sur mesure", included: true },
        { text: "Tunnels de vente illimités", included: true },
        { text: "Support VIP 24/7", included: true },
        { text: "Formation équipe complète", included: true },
        { text: "API & webhooks personnalisés", included: true },
        { text: "Tableau de bord avancé", included: true },
        { text: "Gestionnaire de compte dédié", included: true },
      ],
      buttonText: "Contactez-nous",
      buttonLink: "/contact",
    }
  ];

  return (
    <section id="pricing" className="py-24 bg-gradient-to-b from-white to-neutral-50 relative overflow-hidden">
      {/* Background decorative elements */}
      <div className="absolute top-40 right-0 w-96 h-96 bg-primary-50 rounded-full mix-blend-multiply filter blur-3xl opacity-40"></div>
      <div className="absolute bottom-20 left-10 w-72 h-72 bg-purple-50 rounded-full mix-blend-multiply filter blur-3xl opacity-40"></div>
      
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <motion.div 
          className="text-center mb-14"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <div className="inline-block px-6 py-2 bg-primary-100 text-primary-800 rounded-full mb-6 font-medium">
            Tarification transparente
          </div>
          <h2 className="text-4xl sm:text-5xl font-bold text-neutral-900 mb-6">
            Des plans adaptés à vos besoins 💎
          </h2>
          <p className="max-w-3xl mx-auto text-xl text-neutral-700">
            Choisissez l'offre qui correspond le mieux à votre entreprise, avec une période d'essai et sans engagement.
          </p>
        </motion.div>
        
        {/* Billing toggle */}
        <div className="flex justify-center mb-12">
          <div className="bg-neutral-100 p-1 rounded-lg inline-flex items-center">
            <button
              onClick={() => setPricingPeriod('monthly')}
              className={`${
                pricingPeriod === 'monthly' 
                  ? 'bg-white shadow-sm text-neutral-900' 
                  : 'bg-transparent text-neutral-500'
              } py-2 px-4 rounded-md transition-all duration-200 font-medium text-sm`}
            >
              Mensuel
            </button>
            <button
              onClick={() => setPricingPeriod('annual')}
              className={`${
                pricingPeriod === 'annual' 
                  ? 'bg-white shadow-sm text-neutral-900' 
                  : 'bg-transparent text-neutral-500'
              } py-2 px-4 rounded-md transition-all duration-200 relative font-medium text-sm`}
            >
              <span>Annuel</span>
              {pricingPeriod === 'annual' && (
                <span className="absolute -top-2 -right-2 bg-green-500 text-white text-xs px-1.5 py-0.5 rounded-full">
                  -{discount}%
                </span>
              )}
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {plans.map((plan, index) => (
            <PricingPlan
              key={index}
              index={index}
              name={plan.name}
              icon={plan.icon}
              color={plan.color}
              users={plan.users}
              price={pricingPeriod === 'monthly' ? plan.monthlyPrice : plan.annualPrice}
              period={plan.monthlyPrice === "0" || plan.monthlyPrice === "Sur mesure" ? "" : pricingPeriod === 'monthly' ? "mois" : "mois"}
              description={plan.description}
              features={plan.features}
              buttonText={plan.buttonText}
              buttonLink={plan.buttonLink}
              isPopular={plan.isPopular}
              onButtonClick={plan.onButtonClick}
            />
          ))}
        </div>
        
        {/* FAQ Section */}
        <motion.div 
          className="mt-24 max-w-3xl mx-auto"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5, duration: 0.5 }}
        >
          <h3 className="text-2xl font-bold text-center mb-8">Questions fréquentes</h3>
          
          <div className="space-y-6">
            <div className="bg-white rounded-xl shadow-sm p-6 border border-neutral-100">
              <h4 className="font-bold text-lg mb-2">Existe-t-il un engagement ?</h4>
              <p className="text-neutral-700">Non, tous nos forfaits sont sans engagement. Vous pouvez annuler à tout moment sans frais supplémentaires.</p>
            </div>
            
            <div className="bg-white rounded-xl shadow-sm p-6 border border-neutral-100">
              <h4 className="font-bold text-lg mb-2">Comment fonctionne l'essai gratuit ?</h4>
              <p className="text-neutral-700">Notre essai gratuit de 7 jours vous donne accès à toutes les fonctionnalités du plan Pro. Une carte bancaire est requise mais aucun prélèvement n'est effectué pendant la période d'essai.</p>
            </div>
            
            <div className="bg-white rounded-xl shadow-sm p-6 border border-neutral-100">
              <h4 className="font-bold text-lg mb-2">Puis-je changer de forfait ?</h4>
              <p className="text-neutral-700">Oui, vous pouvez passer à un forfait supérieur à tout moment. Le changement prend effet immédiatement et la différence est calculée au prorata.</p>
            </div>
          </div>
          
          <div className="mt-10 text-center">
            <p className="text-neutral-600 mb-4">Vous avez d'autres questions ?</p>
            <Link href="/contact">
              <motion.div 
                className="inline-flex items-center justify-center text-primary-600 font-medium hover:text-primary-700 transition-colors cursor-pointer"
                whileHover={{ x: 5 }}
              >
                Contactez notre équipe
                <svg className="w-5 h-5 ml-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7m0 0l-7 7m7-7H3" />
                </svg>
              </motion.div>
            </Link>
          </div>
        </motion.div>
      </div>

      <TrialModal
        isOpen={isTrialModalOpen}
        onClose={() => setIsTrialModalOpen(false)}
      />
    </section>
  );
};

export default Pricing;
