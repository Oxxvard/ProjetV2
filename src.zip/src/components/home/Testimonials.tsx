import { motion } from "framer-motion";
import { useState } from "react";

interface Testimonial {
  name: string;
  company: string;
  content: string;
  rating: number;
  avatar: string;
  result: string;
  role?: string;
  featured?: boolean;
}

const TestimonialCard = ({ testimonial }: { testimonial: Testimonial }) => {
  const { name, company, content, rating, avatar, result, role, featured } = testimonial;
  const [isHovered, setIsHovered] = useState(false);
  
  return (
    <motion.div 
      className={`relative bg-white rounded-xl shadow-md p-8 border transition-all duration-300 hover-card-shadow h-full flex flex-col ${featured ? "border-primary-200 bg-primary-50/30" : "border-neutral-100"}`}
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      viewport={{ once: true, margin: "-50px" }}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {featured && (
        <div className="absolute -top-3 -right-3">
          <span className="bg-primary-500 text-white text-xs font-medium px-3 py-1 rounded-full">★ Témoignage vedette</span>
        </div>
      )}
      
      <div className="mb-6">
        <div className="text-primary-500 text-xl mb-3">
          <i className="fas fa-quote-left"></i>
        </div>
        <p className="text-neutral-700 text-lg mb-4 italic font-light">{content}</p>
        <div className="mb-6 flex">
          {[...Array(5)].map((_, i) => (
            <i
              key={i}
              className={`fas fa-star ${
                i < Math.floor(rating) 
                  ? "text-yellow-400" 
                  : i < rating 
                    ? "text-yellow-400 opacity-50" 
                    : "text-gray-200"
              } mr-1 text-sm`}
            ></i>
          ))}
        </div>
        
        <p className="text-primary-700 font-semibold mt-2">
          ✓ <span className="text-black font-normal">Résultat: </span> 
          {result}
        </p>
      </div>
      
      <div className="mt-auto pt-6 border-t border-neutral-100 flex items-center">
        <div className="h-14 w-14 rounded-full bg-neutral-300 flex items-center justify-center overflow-hidden border-2 border-white shadow-md">
          <img src={avatar} alt={name} className="h-full w-full object-cover" />
        </div>
        <div className="ml-4">
          <h4 className="text-lg font-semibold text-neutral-900">{name}</h4>
          <p className="text-neutral-500 text-sm">
            {role && <span className="text-primary-600">{role}, </span>}
            {company}
          </p>
        </div>
      </div>
      
      {/* Bottom design element */}
      <motion.div 
        className="absolute bottom-0 left-0 right-0 h-1.5 bg-gradient-to-r from-primary-500 to-blue-500 rounded-b-lg opacity-0"
        animate={{ opacity: isHovered ? 1 : 0 }}
        transition={{ duration: 0.3 }}
      />
    </motion.div>
  );
};

const Testimonials = () => {
  const [activeTag, setActiveTag] = useState<string>("all");
  
  const testimonials: Testimonial[] = [
    {
      name: "Thomas Martin",
      role: "Propriétaire",
      company: "Restaurant Le Bistrot Parisien",
      content:
        "Grâce au chatbot WhatsApp, nous gérons les réservations et les commandes à emporter de manière automatisée. Les clients peuvent même changer ou annuler leurs réservations sans aucune intervention humaine. C'est une révolution pour notre établissement.",
      rating: 5,
      result: "+30% de réservations en ligne et 15h économisées par semaine",
      avatar:
        "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2.25&w=256&h=256&q=80",
      featured: true,
    },
    {
      name: "Sophie Dupont",
      role: "CEO",
      company: "Wellness Coaching",
      content:
        "Le tunnel de vente automatisé a complètement transformé mon business. Je vends mes programmes en pilote automatique, même pendant que je dors ! La séquence de messages personnalisés a considérablement augmenté mes taux de conversion.",
      rating: 5,
      result: "Chiffre d'affaires doublé en 3 mois",
      avatar:
        "https://images.unsplash.com/photo-1573497019940-1c28c88b4f3e?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2.25&w=256&h=256&q=80",
    },
    {
      name: "Julien Moreau",
      role: "Directeur commercial",
      company: "Agence immobilière Prestige",
      content:
        "Leur système de qualification des prospects par chatbot IA nous a permis de gagner un temps fou. Nos agents se concentrent uniquement sur les clients vraiment intéressés, et le chatbot collecte toutes les informations nécessaires avant la première interaction humaine.",
      rating: 4.5,
      result: "Taux de conversion augmenté de 45%",
      avatar:
        "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2.25&w=256&h=256&q=80",
    },
    {
      name: "Marie Lambert",
      role: "Directrice marketing",
      company: "Boutique Mode Élégance",
      content:
        "L'automatisation des campagnes marketing sur Instagram et des relances par email nous a permis d'être beaucoup plus constants et pertinents dans notre communication. Nous avons vu une amélioration significative de notre engagement et de nos ventes en ligne.",
      rating: 5,
      result: "Taux d'engagement sur Instagram multiplié par 3",
      avatar:
        "https://images.unsplash.com/photo-1587614382346-4ec70e388b28?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2.25&w=256&h=256&q=80",
    },
  ];
  
  const tags = [
    { id: "all", label: "Tous les témoignages" },
    { id: "restaurant", label: "Restauration" },
    { id: "coaching", label: "Coaching" },
    { id: "realestate", label: "Immobilier" },
    { id: "retail", label: "Commerce" },
  ];
  
  const filteredTestimonials = activeTag === "all" 
    ? testimonials
    : testimonials.filter(t => {
        if (activeTag === "restaurant" && t.company.toLowerCase().includes("restaurant")) return true;
        if (activeTag === "coaching" && t.company.toLowerCase().includes("coach")) return true;
        if (activeTag === "realestate" && t.company.toLowerCase().includes("immobilière")) return true;
        if (activeTag === "retail" && t.company.toLowerCase().includes("boutique")) return true;
        return false;
      });

  return (
    <section id="testimonials" className="py-24 bg-gradient-to-b from-neutral-50 to-white relative overflow-hidden">
      {/* Background decorative elements */}
      <div className="absolute top-0 right-1/3 w-64 h-64 bg-primary-50 rounded-full mix-blend-multiply filter blur-3xl opacity-70 animate-blob"></div>
      <div className="absolute bottom-1/4 left-1/4 w-72 h-72 bg-blue-50 rounded-full mix-blend-multiply filter blur-3xl opacity-70 animate-blob animation-delay-2000"></div>
      
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          viewport={{ once: true }}
        >
          <div className="inline-block px-6 py-2 bg-primary-100 text-primary-800 rounded-full mb-6 font-medium">
            Histoires de réussite
          </div>
          <h2 className="text-4xl sm:text-5xl font-bold text-neutral-900 mb-6">
            Ce que nos clients disent de nous
          </h2>
          <p className="max-w-3xl mx-auto text-xl text-neutral-700">
            Découvrez comment notre plateforme d'automatisation transforme les entreprises
            de toutes tailles dans différents secteurs.
          </p>
        </motion.div>
        
        {/* Filter tags */}
        <div className="flex flex-wrap justify-center gap-2 mb-12">
          {tags.map(tag => (
            <button
              key={tag.id}
              onClick={() => setActiveTag(tag.id)}
              className={`px-4 py-2 rounded-full text-sm font-medium transition-all duration-200 ${
                activeTag === tag.id 
                  ? "bg-primary-500 text-white" 
                  : "bg-white border border-neutral-200 text-neutral-600 hover:border-primary-300"
              }`}
            >
              {tag.label}
            </button>
          ))}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-8">
          {filteredTestimonials.map((testimonial, index) => (
            <TestimonialCard key={index} testimonial={testimonial} />
          ))}
        </div>
        
        {/* Stats section */}
        <motion.div 
          className="mt-20 bg-white rounded-2xl shadow-lg border border-neutral-100 p-10"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
          viewport={{ once: true }}
        >
          <div className="text-center mb-10">
            <h3 className="text-2xl font-bold mb-2">Résultats mesurables pour nos clients</h3>
            <p className="text-neutral-600">Notre impact en chiffres</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="text-center">
              <div className="text-4xl font-bold text-primary-600 mb-2">+42%</div>
              <p className="text-neutral-700">Augmentation moyenne<br />du taux de conversion</p>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold text-primary-600 mb-2">19h</div>
              <p className="text-neutral-700">Économisées par semaine<br />en moyenne</p>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold text-primary-600 mb-2">+62%</div>
              <p className="text-neutral-700">D'engagement client<br />sur les canaux digitaux</p>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold text-primary-600 mb-2">94%</div>
              <p className="text-neutral-700">De clients satisfaits<br />recommandent nos services</p>
            </div>
          </div>
        </motion.div>
        
        {/* CTA section */}
        <motion.div 
          className="mt-16 text-center"
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          transition={{ duration: 0.5, delay: 0.4 }}
          viewport={{ once: true }}
        >
          <p className="text-neutral-700 mb-6">Rejoignez plus de 200 entreprises qui ont déjà transformé leur business</p>
          <motion.button
            className="px-8 py-3 bg-primary-600 text-white rounded-xl font-medium inline-flex items-center shadow-md hover:bg-primary-700 transition-colors"
            whileHover={{ y: -3 }}
            whileTap={{ y: 0 }}
            onClick={() => window.location.href = "#pricing"}
          >
            Commencer votre essai gratuit
            <svg className="w-5 h-5 ml-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" />
            </svg>
          </motion.button>
        </motion.div>
      </div>
    </section>
  );
};

export default Testimonials;
