import { Link } from "wouter";

const Footer = () => {
  return (
    <footer className="bg-neutral-800 text-neutral-300 pt-16 pb-8">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8 mb-12">
          <div className="lg:col-span-2">
            <div className="text-white text-2xl font-bold mb-4">
              Automate<span className="text-secondary-500">IA</span>
            </div>
            <p className="mb-6">
              Solutions d'automatisation professionnelles pour les entreprises qui
              veulent gagner du temps et augmenter leur chiffre d'affaires.
            </p>
            <div className="flex space-x-4">
              <a
                href="https://linkedin.com"
                target="_blank"
                rel="noopener noreferrer"
                className="text-neutral-400 hover:text-white transition duration-150 ease-in-out"
              >
                <i className="fab fa-linkedin text-xl"></i>
              </a>
              <a
                href="https://twitter.com"
                target="_blank"
                rel="noopener noreferrer"
                className="text-neutral-400 hover:text-white transition duration-150 ease-in-out"
              >
                <i className="fab fa-twitter text-xl"></i>
              </a>
              <a
                href="https://instagram.com"
                target="_blank"
                rel="noopener noreferrer"
                className="text-neutral-400 hover:text-white transition duration-150 ease-in-out"
              >
                <i className="fab fa-instagram text-xl"></i>
              </a>
              <a
                href="https://facebook.com"
                target="_blank"
                rel="noopener noreferrer"
                className="text-neutral-400 hover:text-white transition duration-150 ease-in-out"
              >
                <i className="fab fa-facebook text-xl"></i>
              </a>
            </div>
          </div>

          <div>
            <h3 className="text-white text-lg font-semibold mb-4">Solutions</h3>
            <ul className="space-y-3">
              <li>
                <Link
                  href="/#chatbots"
                  className="hover:text-white transition duration-150 ease-in-out"
                >
                  Chatbots IA
                </Link>
              </li>
              <li>
                <Link
                  href="/#google-reviews"
                  className="hover:text-white transition duration-150 ease-in-out"
                >
                  Avis Google Auto
                </Link>
              </li>
              <li>
                <Link
                  href="/#emails"
                  className="hover:text-white transition duration-150 ease-in-out"
                >
                  Emails Automatisés
                </Link>
              </li>
              <li>
                <Link
                  href="/#funnels"
                  className="hover:text-white transition duration-150 ease-in-out"
                >
                  Tunnels de Vente
                </Link>
              </li>
              <li>
                <Link
                  href="/#integrations"
                  className="hover:text-white transition duration-150 ease-in-out"
                >
                  Intégrations
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-white text-lg font-semibold mb-4">Entreprise</h3>
            <ul className="space-y-3">
              <li>
                <Link
                  href="/about"
                  className="hover:text-white transition duration-150 ease-in-out"
                >
                  À propos
                </Link>
              </li>
              <li>
                <Link
                  href="/blog"
                  className="hover:text-white transition duration-150 ease-in-out"
                >
                  Blog
                </Link>
              </li>
              <li>
                <Link
                  href="/careers"
                  className="hover:text-white transition duration-150 ease-in-out"
                >
                  Carrières
                </Link>
              </li>
              <li>
                <Link
                  href="/contact"
                  className="hover:text-white transition duration-150 ease-in-out"
                >
                  Contact
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-white text-lg font-semibold mb-4">Légal</h3>
            <ul className="space-y-3">
              <li>
                <Link
                  href="/privacy"
                  className="hover:text-white transition duration-150 ease-in-out"
                >
                  Politique de confidentialité
                </Link>
              </li>
              <li>
                <Link
                  href="/terms"
                  className="hover:text-white transition duration-150 ease-in-out"
                >
                  Conditions d'utilisation
                </Link>
              </li>
              <li>
                <Link
                  href="/gdpr"
                  className="hover:text-white transition duration-150 ease-in-out"
                >
                  RGPD
                </Link>
              </li>
              <li>
                <Link
                  href="/cookies"
                  className="hover:text-white transition duration-150 ease-in-out"
                >
                  Cookies
                </Link>
              </li>
            </ul>
          </div>
        </div>

        <div className="pt-8 mt-8 border-t border-neutral-700 flex flex-col md:flex-row justify-between items-center">
          <p className="text-sm mb-4 md:mb-0">
            © {new Date().getFullYear()} AutomateIA. Tous droits réservés.
          </p>
          <div className="flex space-x-6">
            <Link
              href="/privacy"
              className="text-sm hover:text-white transition duration-150 ease-in-out"
            >
              Confidentialité
            </Link>
            <Link
              href="/terms"
              className="text-sm hover:text-white transition duration-150 ease-in-out"
            >
              Conditions
            </Link>
            <Link
              href="/cookies"
              className="text-sm hover:text-white transition duration-150 ease-in-out"
            >
              Cookies
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
