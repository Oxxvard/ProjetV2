import { useState } from "react";
import { Link, useLocation } from "wouter";
import LoginModal from "@/components/auth/LoginModal";
import SignupModal from "@/components/auth/SignupModal";
import { useAuth } from "@/hooks/useAuth";

const Header = () => {
  const [location] = useLocation();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isLoginModalOpen, setIsLoginModalOpen] = useState(false);
  const [isSignupModalOpen, setIsSignupModalOpen] = useState(false);
  const { user, logout } = useAuth();

  const toggleMobileMenu = () => setIsMobileMenuOpen(!isMobileMenuOpen);
  const closeMobileMenu = () => setIsMobileMenuOpen(false);

  return (
    <header className="bg-white shadow-sm sticky top-0 z-50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex items-center">
            <Link href="/" className="flex-shrink-0 flex items-center">
              <span className="text-primary-500 text-2xl font-bold">
                Automate<span className="text-secondary-500">IA</span>
              </span>
            </Link>
            <nav className="hidden md:ml-8 md:flex md:space-x-6">
              <Link href="/#solutions" 
                className={`text-neutral-600 hover:text-primary-500 px-3 py-2 text-sm font-medium transition duration-150 ease-in-out ${location === '/#solutions' ? 'text-primary-500' : ''}`}>
                Solutions
              </Link>
              <Link href="/#pricing" 
                className={`text-neutral-600 hover:text-primary-500 px-3 py-2 text-sm font-medium transition duration-150 ease-in-out ${location === '/#pricing' ? 'text-primary-500' : ''}`}>
                Tarifs
              </Link>
              <Link href="/#testimonials" 
                className={`text-neutral-600 hover:text-primary-500 px-3 py-2 text-sm font-medium transition duration-150 ease-in-out ${location === '/#testimonials' ? 'text-primary-500' : ''}`}>
                Témoignages
              </Link>
              <Link href="/blog" 
                className={`text-neutral-600 hover:text-primary-500 px-3 py-2 text-sm font-medium transition duration-150 ease-in-out ${location === '/blog' ? 'text-primary-500' : ''}`}>
                Blog
              </Link>
              <Link href="/contact" 
                className={`text-neutral-600 hover:text-primary-500 px-3 py-2 text-sm font-medium transition duration-150 ease-in-out ${location === '/contact' ? 'text-primary-500' : ''}`}>
                Contact
              </Link>
            </nav>
          </div>
          <div className="flex items-center">
            <div className="hidden md:flex items-center md:ml-6 space-x-4">
              {user ? (
                <>
                  <Link href="/dashboard" className="text-neutral-600 hover:text-primary-500 px-3 py-2 text-sm font-medium">
                    Tableau de bord
                  </Link>
                  <button
                    onClick={logout}
                    className="text-neutral-600 hover:text-primary-500 px-3 py-2 text-sm font-medium"
                  >
                    Déconnexion
                  </button>
                </>
              ) : (
                <>
                  <button
                    onClick={() => setIsLoginModalOpen(true)}
                    className="text-neutral-600 hover:text-primary-500 px-3 py-2 text-sm font-medium"
                  >
                    Se connecter
                  </button>
                  <button
                    onClick={() => setIsSignupModalOpen(true)}
                    className="bg-primary-500 hover:bg-primary-600 text-white px-4 py-2 rounded-lg text-sm font-medium transition duration-150 ease-in-out"
                  >
                    S'inscrire
                  </button>
                </>
              )}
            </div>
            <div className="md:hidden flex items-center">
              <button
                id="mobile-menu-button"
                className="text-neutral-600 hover:text-primary-500 p-2"
                onClick={toggleMobileMenu}
              >
                <i className="fas fa-bars text-xl"></i>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Mobile menu */}
      {isMobileMenuOpen && (
        <div className="md:hidden bg-white border-t border-neutral-200">
          <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
            <Link href="/#solutions" className="block px-3 py-2 text-base font-medium text-neutral-600 hover:text-primary-500" onClick={closeMobileMenu}>
              Solutions
            </Link>
            <Link href="/#pricing" className="block px-3 py-2 text-base font-medium text-neutral-600 hover:text-primary-500" onClick={closeMobileMenu}>
              Tarifs
            </Link>
            <Link href="/#testimonials" className="block px-3 py-2 text-base font-medium text-neutral-600 hover:text-primary-500" onClick={closeMobileMenu}>
              Témoignages
            </Link>
            <Link href="/blog" className="block px-3 py-2 text-base font-medium text-neutral-600 hover:text-primary-500" onClick={closeMobileMenu}>
              Blog
            </Link>
            <Link href="/contact" className="block px-3 py-2 text-base font-medium text-neutral-600 hover:text-primary-500" onClick={closeMobileMenu}>
              Contact
            </Link>
            <div className="pt-4 pb-3 border-t border-neutral-200">
              {user ? (
                <>
                  <Link href="/dashboard" className="block px-3 py-2 text-base font-medium text-neutral-600 hover:text-primary-500" onClick={closeMobileMenu}>
                    Tableau de bord
                  </Link>
                  <button
                    onClick={() => {
                      logout();
                      closeMobileMenu();
                    }}
                    className="block px-3 py-2 text-base font-medium text-neutral-600 hover:text-primary-500 w-full text-left"
                  >
                    Déconnexion
                  </button>
                </>
              ) : (
                <>
                  <button
                    onClick={() => {
                      setIsLoginModalOpen(true);
                      closeMobileMenu();
                    }}
                    className="block px-3 py-2 text-base font-medium text-neutral-600 hover:text-primary-500 w-full text-left"
                  >
                    Se connecter
                  </button>
                  <button
                    onClick={() => {
                      setIsSignupModalOpen(true);
                      closeMobileMenu();
                    }}
                    className="block mt-2 px-3 py-2 text-base font-medium text-white bg-primary-500 hover:bg-primary-600 rounded-lg w-full text-left"
                  >
                    S'inscrire
                  </button>
                </>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Modals */}
      <LoginModal
        isOpen={isLoginModalOpen}
        onClose={() => setIsLoginModalOpen(false)}
        onSignupClick={() => {
          setIsLoginModalOpen(false);
          setIsSignupModalOpen(true);
        }}
      />
      <SignupModal
        isOpen={isSignupModalOpen}
        onClose={() => setIsSignupModalOpen(false)}
        onLoginClick={() => {
          setIsSignupModalOpen(false);
          setIsLoginModalOpen(true);
        }}
      />
    </header>
  );
};

export default Header;
