import { useState, useEffect } from "react";
import { Link } from "wouter";
import { motion, AnimatePresence } from "framer-motion";
import { Menu, X, Sun, Moon, User } from "lucide-react";
import { useTheme } from "@/context/ThemeContext";
import { useAuth } from "@/hooks/useAuth";
import { ThemeSwitcher } from "@/components/ui/theme-switcher";

const MainHeader = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const [isLoginModalOpen, setIsLoginModalOpen] = useState(false);
  const [isSignupModalOpen, setIsSignupModalOpen] = useState(false);
  const { user, logout } = useAuth();
  const { theme, setTheme, resolvedTheme } = useTheme();
  
  const isDark = resolvedTheme === "dark";
  
  // Détecter le défilement pour changer le style du header
  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };
    
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);
  
  const navLinks = [
    { href: "/", label: "Accueil" },
    { href: "#features", label: "Fonctionnalités" },
    { href: "#how-it-works", label: "Comment ça marche" },
    { href: "#pricing", label: "Tarifs" },
    { href: "/blog", label: "Blog" },
    { href: "/contact", label: "Contact" }
  ];
  
  return (
    <header className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
      isScrolled
        ? isDark
          ? "bg-gray-900/90 backdrop-blur-md border-b border-gray-800"
          : "bg-white/90 backdrop-blur-md shadow-sm"
        : "bg-transparent"
    }`}>
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 md:h-20">
          {/* Logo */}
          <div className="flex items-center">
            <Link href="/">
              <div className="flex items-center space-x-2 cursor-pointer">
                <div className="flex items-center justify-center w-8 h-8 bg-primary-600 text-white rounded-lg">
                  <span className="font-bold text-lg">A</span>
                </div>
                <span className={`font-bold text-xl ${
                  isDark ? "text-white" : "text-gray-900"
                }`}>
                  AutomationHub
                </span>
              </div>
            </Link>
          </div>
          
          {/* Navigation desktop */}
          <nav className="hidden md:flex items-center space-x-8">
            {navLinks.map((link) => (
              <Link key={link.label} href={link.href}>
                <span className={`text-sm font-medium transition-colors cursor-pointer ${
                  isDark
                    ? "text-gray-300 hover:text-white"
                    : "text-gray-700 hover:text-primary-600"
                }`}>
                  {link.label}
                </span>
              </Link>
            ))}
          </nav>
          
          {/* Actions */}
          <div className="flex items-center space-x-2 md:space-x-4">
            {/* Theme switcher */}
            <div className="flex items-center">
              <ThemeSwitcher className="mr-2" />
            </div>
            
            {/* Login/Dashboard buttons */}
            <div className="hidden md:flex items-center space-x-3">
              {user ? (
                <div className="relative group">
                  <button className="h-9 w-9 rounded-full bg-primary-500 text-white flex items-center justify-center font-medium">
                    {user.displayName ? user.displayName.charAt(0).toUpperCase() : <User className="h-5 w-5" />}
                  </button>
                  <div className="absolute right-0 mt-2 w-48 bg-white dark:bg-gray-800 rounded-md shadow-lg border border-gray-200 dark:border-gray-700 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-150 transform group-hover:translate-y-0 translate-y-1 z-50">
                    <div className="p-3 border-b border-gray-200 dark:border-gray-700">
                      <div className="text-sm font-semibold">{user.displayName}</div>
                      <div className="text-xs text-gray-400">{user.email}</div>
                    </div>
                    <div className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 cursor-pointer text-sm" onClick={logout}>
                      Se déconnecter
                    </div>
                  </div>
                </div>
              ) : (
                <Link href="/login">
                  <button className={`px-4 py-2 rounded-md 
                    ${isDark ? "bg-primary-600 text-white hover:bg-primary-500" : "bg-primary-600 text-white hover:bg-primary-500"} 
                    transition-all duration-200`}>
                    Se connecter
                  </button>
                </Link>
              )}
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};

export default MainHeader;
