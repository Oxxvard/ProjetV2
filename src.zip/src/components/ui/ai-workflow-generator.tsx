import { useState, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { 
  Cpu, Code, Sparkles, XCircle, SendHorizontal, 
  Loader2, Copy, Check, Lightbulb, Wand2, Bot, 
  Database, Workflow, ArrowRight, RotateCw
} from "lucide-react";
import { useTheme } from "@/context/ThemeContext";

interface GeneratedWorkflow {
  id: string;
  name: string;
  description: string;
  steps: {
    type: "trigger" | "action" | "condition" | "loop";
    name: string;
    description: string;
    config?: Record<string, any>;
  }[];
  aiComments: string[];
  createdAt: Date;
}

interface AIWizardProps {
  onClose?: () => void;
  onWorkflowGenerated?: (workflow: GeneratedWorkflow) => void;
}

const AI_SUGGESTIONS = [
  "Créer un chatbot pour répondre aux questions fréquentes des clients sur WhatsApp",
  "Automatiser la génération et l'envoi de factures aux clients en retard de paiement",
  "Mettre en place un système de suivi et de relance des prospects qui n'ont pas répondu",
  "Créer un système qui détecte les avis négatifs et alerte l'équipe en temps réel",
  "Automatiser la publication de contenu sur les réseaux sociaux à partir d'un calendrier"
];

const AIWorkflowGenerator = ({ onClose, onWorkflowGenerated }: AIWizardProps) => {
  const [prompt, setPrompt] = useState("");
  const [isGenerating, setIsGenerating] = useState(false);
  const [generationStep, setGenerationStep] = useState(0);
  const [generatedWorkflow, setGeneratedWorkflow] = useState<GeneratedWorkflow | null>(null);
  const [copySuccess, setCopySuccess] = useState(false);
  const [isSuggestionVisible, setIsSuggestionVisible] = useState(true);
  const promptInputRef = useRef<HTMLTextAreaElement>(null);
  const { resolvedTheme } = useTheme();
  
  const isDark = resolvedTheme === "dark";

  // Simule les étapes de génération
  const generateWorkflow = async () => {
    if (!prompt.trim()) return;
    
    setIsGenerating(true);
    setGenerationStep(0);
    setGeneratedWorkflow(null);
    setIsSuggestionVisible(false);
    
    // Simuler les étapes du processus
    const steps = [
      "Analyse des besoins du workflow...",
      "Identification des déclencheurs et actions...",
      "Configuration des paramètres d'intégration...",
      "Optimisation pour la performance...",
      "Génération du workflow final...",
    ];
    
    for (let i = 0; i < steps.length; i++) {
      setGenerationStep(i);
      // Pause pour simuler le traitement
      await new Promise(resolve => setTimeout(resolve, 1200));
    }
    
    // Exemple de workflow généré - dans une implémentation réelle, ceci viendrait d'une API
    const result: GeneratedWorkflow = {
      id: `wf-${Date.now()}`,
      name: prompt.length > 30 ? `${prompt.substring(0, 27)}...` : prompt,
      description: `Workflow automatisé généré pour: ${prompt}`,
      steps: [
        {
          type: "trigger",
          name: "Événement de déclenchement",
          description: "Le workflow démarre lorsqu'un nouveau message client est reçu sur WhatsApp"
        },
        {
          type: "condition",
          name: "Vérification du contenu",
          description: "Analyse le contenu du message pour déterminer l'intention du client"
        },
        {
          type: "action",
          name: "Classification par IA",
          description: "Catégorise la demande en utilisant le modèle GPT-5"
        },
        {
          type: "condition",
          name: "Décision de routage",
          description: "Si la demande peut être traitée automatiquement, continue le workflow, sinon transfère à un agent"
        },
        {
          type: "action",
          name: "Génération de réponse",
          description: "Crée une réponse personnalisée basée sur la base de connaissances"
        },
        {
          type: "action",
          name: "Envoi de la réponse",
          description: "Envoie la réponse générée au client via l'API WhatsApp"
        }
      ],
      aiComments: [
        "Ce workflow utilise l'authentification OAuth2 pour sécuriser les connexions API",
        "Une vérification de sentiment est intégrée pour détecter les clients frustrés",
        "Le système inclut une boucle de feedback pour améliorer les réponses futures"
      ],
      createdAt: new Date()
    };
    
    setGeneratedWorkflow(result);
    setIsGenerating(false);
    
    if (onWorkflowGenerated) {
      onWorkflowGenerated(result);
    }
  };

  const handleCopyToClipboard = () => {
    if (!generatedWorkflow) return;
    
    const workflowText = `
# ${generatedWorkflow.name}
${generatedWorkflow.description}

## Étapes du workflow
${generatedWorkflow.steps.map((step, index) => `${index + 1}. [${step.type.toUpperCase()}] ${step.name}: ${step.description}`).join('\n')}

## Notes de l'IA
${generatedWorkflow.aiComments.map(comment => `• ${comment}`).join('\n')}

Généré le ${generatedWorkflow.createdAt.toLocaleString()}
    `.trim();
    
    navigator.clipboard.writeText(workflowText);
    setCopySuccess(true);
    
    setTimeout(() => {
      setCopySuccess(false);
    }, 2000);
  };

  const handleSuggestionClick = (suggestion: string) => {
    setPrompt(suggestion);
    if (promptInputRef.current) {
      promptInputRef.current.focus();
    }
  };

  // Focus l'input au chargement
  useEffect(() => {
    if (promptInputRef.current) {
      promptInputRef.current.focus();
    }
  }, []);

  return (
    <div className={`fixed inset-0 z-50 flex items-center justify-center p-4 ${isDark ? 'bg-gray-900/80' : 'bg-black/50'}`}>
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.9 }}
        className={`relative w-full max-w-4xl rounded-xl shadow-2xl overflow-hidden ${
          isDark ? 'bg-gray-900 border border-gray-700' : 'bg-white'
        }`}
      >
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b dark:border-gray-700">
          <div className="flex items-center space-x-2">
            <div className="p-2 bg-primary-100 dark:bg-primary-900/30 rounded-lg">
              <Sparkles className="h-5 w-5 text-primary-600 dark:text-primary-400" />
            </div>
            <div>
              <h2 className="text-lg font-semibold text-gray-900 dark:text-gray-100">
                Générateur de Workflow IA
              </h2>
              <p className="text-sm text-gray-500 dark:text-gray-400">
                Décrivez ce que vous souhaitez automatiser
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-200 rounded-full"
          >
            <XCircle className="h-6 w-6" />
          </button>
        </div>
        
        {/* Content */}
        <div className="p-6">
          {/* Input area */}
          <div className={`rounded-lg border ${isDark ? 'border-gray-700 bg-gray-800/50' : 'border-gray-200 bg-gray-50'} p-3 mb-6`}>
            <div className="relative">
              <textarea
                ref={promptInputRef}
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    generateWorkflow();
                  }
                }}
                placeholder="Décrivez le flux de travail que vous souhaitez automatiser..."
                className={`w-full min-h-[100px] p-3 outline-none resize-none ${
                  isDark ? 'bg-gray-800/50 text-white placeholder:text-gray-400' : 'bg-gray-50 text-gray-900 placeholder:text-gray-500'
                }`}
                disabled={isGenerating}
              />
              <button
                onClick={generateWorkflow}
                disabled={isGenerating || !prompt.trim()}
                className={`absolute right-3 bottom-3 p-2 rounded-lg ${
                  isGenerating || !prompt.trim()
                    ? 'bg-gray-300 dark:bg-gray-700 text-gray-500 dark:text-gray-400 cursor-not-allowed'
                    : 'bg-primary hover:bg-primary-600 text-white'
                } transition-colors`}
              >
                {isGenerating ? (
                  <Loader2 className="h-5 w-5 animate-spin" />
                ) : (
                  <SendHorizontal className="h-5 w-5" />
                )}
              </button>
            </div>
          </div>
          
          {/* Suggestions */}
          {isSuggestionVisible && !generatedWorkflow && (
            <div className="mb-6">
              <div className="flex items-center mb-2">
                <Lightbulb className="h-4 w-4 text-amber-500 mr-2" />
                <h3 className="text-sm font-medium text-gray-700 dark:text-gray-300">
                  Suggestions rapides
                </h3>
              </div>
              <div className="flex flex-wrap gap-2">
                {AI_SUGGESTIONS.map((suggestion, index) => (
                  <button
                    key={index}
                    onClick={() => handleSuggestionClick(suggestion)}
                    className={`text-xs py-2 px-3 rounded-full border transition-colors ${
                      isDark
                        ? 'border-gray-700 hover:bg-gray-800 text-gray-300'
                        : 'border-gray-200 hover:bg-gray-100 text-gray-700'
                    }`}
                  >
                    {suggestion}
                  </button>
                ))}
              </div>
            </div>
          )}
          
          {/* Generation process */}
          <AnimatePresence>
            {isGenerating && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className={`rounded-lg p-6 ${
                  isDark ? 'bg-gray-800/50 border border-gray-700' : 'bg-gray-50 border border-gray-200'
                }`}
              >
                <div className="flex items-center justify-center mb-4">
                  <div className="relative w-24 h-24">
                    <div className="absolute inset-0 rounded-full border-4 border-primary border-opacity-20 animate-ping"></div>
                    <div className="absolute inset-0 flex items-center justify-center">
                      <motion.div
                        animate={{ rotate: 360 }}
                        transition={{ duration: 3, repeat: Infinity, ease: "linear" }}
                      >
                        <svg
                          className="w-16 h-16 text-primary-500"
                          viewBox="0 0 24 24"
                          fill="none"
                          xmlns="http://www.w3.org/2000/svg"
                        >
                          <path
                            d="M12 2C6.48 2 2 6.48 2 12C2 17.52 6.48 22 12 22C17.52 22 22 17.52 22 12"
                            stroke="currentColor"
                            strokeWidth="2"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                          />
                          <path
                            d="M22 2L17 7L12 2"
                            stroke="currentColor"
                            strokeWidth="2"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                          />
                        </svg>
                      </motion.div>
                    </div>
                  </div>
                </div>
                
                <h3 className="text-lg font-medium text-gray-900 dark:text-gray-100 text-center mb-6">
                  IA en action : Génération de votre workflow personnalisé
                </h3>
                
                <div className="space-y-4 max-w-lg mx-auto">
                  {["Analyse des besoins du workflow...", 
                    "Identification des déclencheurs et actions...", 
                    "Configuration des paramètres d'intégration...", 
                    "Optimisation pour la performance...", 
                    "Génération du workflow final..."
                  ].map((step, index) => (
                    <div
                      key={index}
                      className={`flex items-center ${
                        index <= generationStep
                          ? 'text-gray-900 dark:text-gray-100'
                          : 'text-gray-400 dark:text-gray-600'
                      }`}
                    >
                      {index < generationStep ? (
                        <div className="w-6 h-6 mr-3 flex-shrink-0 rounded-full bg-green-500 flex items-center justify-center">
                          <Check className="h-4 w-4 text-white" />
                        </div>
                      ) : index === generationStep ? (
                        <motion.div
                          animate={{ rotate: 360 }}
                          transition={{ duration: 1.5, repeat: Infinity, ease: "linear" }}
                          className="w-6 h-6 mr-3 flex-shrink-0 rounded-full border-2 border-primary border-t-transparent"
                        />
                      ) : (
                        <div className="w-6 h-6 mr-3 flex-shrink-0 rounded-full border-2 border-gray-300 dark:border-gray-700" />
                      )}
                      <span>{step}</span>
                    </div>
                  ))}
                </div>
              </motion.div>
            )}
            
            {/* Generated workflow result */}
            {generatedWorkflow && !isGenerating && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className={`rounded-lg border ${
                  isDark ? 'border-gray-700' : 'border-gray-200'
                } overflow-hidden`}
              >
                <div className={`p-4 ${
                  isDark ? 'bg-gray-800/50' : 'bg-gray-50'
                }`}>
                  <div className="flex justify-between items-center">
                    <div className="flex items-center">
                      <Workflow className="w-5 h-5 text-primary-600 dark:text-primary-400 mr-2" />
                      <h3 className="font-medium text-gray-900 dark:text-gray-100">
                        {generatedWorkflow.name}
                      </h3>
                    </div>
                    <button
                      onClick={handleCopyToClipboard}
                      className={`p-1.5 rounded-md ${
                        isDark
                          ? 'hover:bg-gray-700 text-gray-400 hover:text-gray-300'
                          : 'hover:bg-gray-200 text-gray-500 hover:text-gray-700'
                      }`}
                    >
                      {copySuccess ? (
                        <Check className="h-4 w-4 text-green-500" />
                      ) : (
                        <Copy className="h-4 w-4" />
                      )}
                    </button>
                  </div>
                </div>
                
                <div className="p-6">
                  <div className="mb-6">
                    <p className="text-sm text-gray-600 dark:text-gray-400 mb-4">
                      {generatedWorkflow.description}
                    </p>
                  </div>
                  
                  <div className="mb-6">
                    <h4 className="text-sm font-medium text-gray-900 dark:text-gray-100 mb-3">
                      Étapes du workflow
                    </h4>
                    <div className="space-y-4">
                      {generatedWorkflow.steps.map((step, index) => (
                        <div
                          key={index}
                          className={`flex p-3 rounded-lg ${
                            isDark ? 'bg-gray-800' : 'bg-gray-50'
                          }`}
                        >
                          <div className="mr-3 mt-0.5">
                            {step.type === "trigger" ? (
                              <div className="w-8 h-8 rounded-full bg-blue-100 dark:bg-blue-900/30 flex items-center justify-center">
                                <Bot className="h-4 w-4 text-blue-600 dark:text-blue-400" />
                              </div>
                            ) : step.type === "action" ? (
                              <div className="w-8 h-8 rounded-full bg-green-100 dark:bg-green-900/30 flex items-center justify-center">
                                <Wand2 className="h-4 w-4 text-green-600 dark:text-green-400" />
                              </div>
                            ) : step.type === "condition" ? (
                              <div className="w-8 h-8 rounded-full bg-amber-100 dark:bg-amber-900/30 flex items-center justify-center">
                                <Code className="h-4 w-4 text-amber-600 dark:text-amber-400" />
                              </div>
                            ) : (
                              <div className="w-8 h-8 rounded-full bg-purple-100 dark:bg-purple-900/30 flex items-center justify-center">
                                <RotateCw className="h-4 w-4 text-purple-600 dark:text-purple-400" />
                              </div>
                            )}
                          </div>
                          <div>
                            <div className="flex items-center mb-1">
                              <h5 className="text-sm font-medium text-gray-900 dark:text-gray-100">
                                {step.name}
                              </h5>
                              <span className={`ml-2 text-xs px-2 py-0.5 rounded-full ${
                                step.type === "trigger"
                                  ? "bg-blue-100 dark:bg-blue-900/30 text-blue-800 dark:text-blue-300"
                                  : step.type === "action"
                                  ? "bg-green-100 dark:bg-green-900/30 text-green-800 dark:text-green-300"
                                  : step.type === "condition"
                                  ? "bg-amber-100 dark:bg-amber-900/30 text-amber-800 dark:text-amber-300"
                                  : "bg-purple-100 dark:bg-purple-900/30 text-purple-800 dark:text-purple-300"
                              }`}>
                                {step.type}
                              </span>
                            </div>
                            <p className="text-sm text-gray-600 dark:text-gray-400">
                              {step.description}
                            </p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                  
                  <div className="mb-6">
                    <h4 className="text-sm font-medium text-gray-900 dark:text-gray-100 mb-3">
                      Notes de l'IA
                    </h4>
                    <div className={`p-4 rounded-lg ${
                      isDark ? 'bg-gray-800/70' : 'bg-gray-50'
                    }`}>
                      <ul className="space-y-2">
                        {generatedWorkflow.aiComments.map((comment, index) => (
                          <li key={index} className="flex items-start">
                            <Cpu className="h-4 w-4 text-primary-600 dark:text-primary-400 mr-2 mt-0.5" />
                            <span className="text-sm text-gray-600 dark:text-gray-400">
                              {comment}
                            </span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                </div>
                
                <div className={`p-4 border-t ${
                  isDark ? 'border-gray-700 bg-gray-800/50' : 'border-gray-200 bg-gray-50'
                }`}>
                  <div className="flex justify-between">
                    <button
                      onClick={() => {
                        setGeneratedWorkflow(null);
                        setIsSuggestionVisible(true);
                        setPrompt("");
                      }}
                      className={`py-2 px-4 rounded-lg text-sm ${
                        isDark
                          ? 'bg-gray-700 hover:bg-gray-600 text-gray-200'
                          : 'bg-gray-100 hover:bg-gray-200 text-gray-700'
                      }`}
                    >
                      Générer un autre workflow
                    </button>
                    
                    <button
                      className="py-2 px-4 bg-primary hover:bg-primary-600 text-white rounded-lg text-sm flex items-center"
                    >
                      <span>Déployer ce workflow</span>
                      <ArrowRight className="ml-2 h-4 w-4" />
                    </button>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
        
        {/* Footer */}
        <div className={`p-4 text-center text-xs text-gray-500 dark:text-gray-400 border-t ${
          isDark ? 'border-gray-800' : 'border-gray-200'
        }`}>
          Propulsé par AIrion GPT-5 Ultra • Modèle optimisé pour l'automatisation business
        </div>
      </motion.div>
    </div>
  );
};

export default AIWorkflowGenerator;