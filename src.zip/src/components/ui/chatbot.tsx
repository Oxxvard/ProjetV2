import { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { MessageSquare, Mic, Send, X, Minimize2, Paperclip, Bot, Smile, Image } from "lucide-react";
import { useTheme } from "@/context/ThemeContext";
import { useIsMobile } from "@/hooks/use-mobile";

interface Message {
  text: string;
  isUser: boolean;
  timestamp: Date;
  attachments?: string[];
}

const initialMessages: Message[] = [
  {
    text: "Bonjour 👋 ! Je suis votre assistant IA en automatisation. Comment puis-je vous aider aujourd'hui ?",
    isUser: false,
    timestamp: new Date(),
  },
];

const suggestions = [
  "Comment automatiser ma gestion client ?",
  "Quels sont les avantages de vos chatbots ?",
  "Je souhaite un devis personnalisé",
  "Comment fonctionne l'essai gratuit ?",
];

const Chatbot = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>(initialMessages);
  const [inputText, setInputText] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const [isMinimized, setIsMinimized] = useState(false);
  const [hasUnread, setHasUnread] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [attachments, setAttachments] = useState<string[]>([]);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const { resolvedTheme } = useTheme();
  const isMobile = useIsMobile();
  
  // Function to scroll to bottom of messages
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  // Scroll to bottom whenever messages change
  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  // Handling file upload for attachments
  const handleFileUpload = () => {
    const input = document.createElement("input");
    input.type = "file";
    input.accept = "image/*";
    input.multiple = true;
    input.onchange = (e) => {
      const files = (e.target as HTMLInputElement).files;
      if (files) {
        const newAttachments: string[] = [];
        
        for (let i = 0; i < files.length; i++) {
          const file = files[i];
          const reader = new FileReader();
          
          reader.onload = (e) => {
            if (e.target?.result) {
              newAttachments.push(e.target.result as string);
              if (newAttachments.length === files.length) {
                setAttachments([...attachments, ...newAttachments]);
              }
            }
          };
          
          reader.readAsDataURL(file);
        }
      }
    };
    input.click();
  };

  // AI response generation
  const generateResponse = (userMessage: string) => {
    setIsTyping(true);
    
    // Simulate API call to AI service
    setTimeout(() => {
      let response = "";
      
      if (userMessage.toLowerCase().includes("automatiser") || userMessage.toLowerCase().includes("automatisation")) {
        response = "Nous proposons plusieurs solutions d'automatisation adaptées à votre business. Que souhaitez-vous automatiser spécifiquement ? Support client, gestion des avis, emails de relance ?";
      } else if (userMessage.toLowerCase().includes("chatbot") || userMessage.toLowerCase().includes("bot")) {
        response = "Nos chatbots IA s'intègrent sur WhatsApp, votre site web, Facebook Messenger et Instagram. Ils peuvent répondre à vos clients 24/7 avec une précision de 95%. Souhaitez-vous une démonstration ?";
      } else if (userMessage.toLowerCase().includes("prix") || userMessage.toLowerCase().includes("tarif") || userMessage.toLowerCase().includes("coût") || userMessage.toLowerCase().includes("devis")) {
        response = "Nos forfaits débutent à 100€/mois pour une solution clé en main. Pour un devis personnalisé, pouvez-vous me préciser votre secteur d'activité et vos besoins spécifiques ?";
      } else if (userMessage.toLowerCase().includes("essai") || userMessage.toLowerCase().includes("essayer") || userMessage.toLowerCase().includes("tester")) {
        response = "Bonne nouvelle ! Nous proposons un essai gratuit de 7 jours pour tester notre solution sans engagement. Souhaitez-vous commencer votre période d'essai dès maintenant ?";
      } else {
        response = "Merci pour votre message. Un de nos experts en automatisation vous contactera très rapidement. En attendant, pouvez-vous me préciser votre besoin principal ?";
      }
      
      setMessages([
        ...messages,
        {
          text: response,
          isUser: false,
          timestamp: new Date(),
        },
      ]);
      
      setIsTyping(false);
    }, 1500);
  };

  // Handle message sending
  const handleSendMessage = () => {
    if (inputText.trim() === "" && attachments.length === 0) return;

    const newMessage: Message = {
      text: inputText.trim(),
      isUser: true,
      timestamp: new Date(),
      attachments: attachments.length > 0 ? [...attachments] : undefined,
    };

    setMessages([...messages, newMessage]);
    setInputText("");
    setAttachments([]);
    
    // Generate AI response
    generateResponse(inputText);
  };

  // Handle enter key press
  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  // Toggle voice recording
  const toggleRecording = () => {
    if (isRecording) {
      // In a real implementation, this would stop recording and process speech to text
      setIsRecording(false);
      setInputText(inputText + " [Transcription de votre message vocal]");
    } else {
      setIsRecording(true);
      // In a real implementation, this would start recording
    }
  };

  // Render timestamp in a readable format
  const formatTimestamp = (date: Date) => {
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  // Remove attachment by index
  const removeAttachment = (index: number) => {
    const newAttachments = [...attachments];
    newAttachments.splice(index, 1);
    setAttachments(newAttachments);
  };

  return (
    <div className="fixed bottom-8 right-8 z-50 flex flex-col items-end">
      {/* Main Chatbot Window */}
      <AnimatePresence>
        {isOpen && !isMinimized && (
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.95 }}
            transition={{ duration: 0.2 }}
            className={`mb-4 rounded-2xl overflow-hidden shadow-2xl w-full sm:w-[400px] max-h-[600px] flex flex-col ${
              resolvedTheme === "dark" ? "bg-gray-900 border border-gray-800" : "bg-white border border-gray-100"
            }`}
          >
            {/* Header */}
            <div className="p-4 flex items-center justify-between bg-primary text-white">
              <div className="flex items-center space-x-3">
                <Bot className="h-6 w-6" />
                <div>
                  <h3 className="font-medium">Assistant Automatisation</h3>
                  <p className="text-xs text-primary-100">En ligne | Répond en quelques secondes</p>
                </div>
              </div>
              <div className="flex items-center space-x-2">
                <button 
                  onClick={() => setIsMinimized(true)}
                  className="p-1 hover:bg-primary-700 rounded-full transition-colors"
                >
                  <Minimize2 className="h-4 w-4" />
                </button>
                <button 
                  onClick={() => setIsOpen(false)}
                  className="p-1 hover:bg-primary-700 rounded-full transition-colors"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>
            </div>
            
            {/* Messages Container */}
            <div className="flex-1 p-4 overflow-y-auto custom-scrollbar">
              {messages.map((message, index) => (
                <div
                  key={index}
                  className={`mb-4 flex ${message.isUser ? "justify-end" : "justify-start"}`}
                >
                  <div
                    className={`max-w-[80%] rounded-2xl p-3 ${
                      message.isUser
                        ? "bg-primary text-white rounded-tr-none"
                        : resolvedTheme === "dark"
                        ? "bg-gray-800 text-gray-100 rounded-tl-none"
                        : "bg-gray-100 text-gray-800 rounded-tl-none"
                    }`}
                  >
                    {message.text}
                    
                    {/* Attachments */}
                    {message.attachments && message.attachments.length > 0 && (
                      <div className="mt-2 grid grid-cols-2 gap-2">
                        {message.attachments.map((attachment, i) => (
                          <img 
                            key={i}
                            src={attachment} 
                            alt={`Attachment ${i}`} 
                            className="rounded-lg max-h-40 object-cover"
                          />
                        ))}
                      </div>
                    )}
                    
                    <div className={`text-xs mt-1 ${message.isUser ? "text-primary-100" : "text-gray-500"}`}>
                      {formatTimestamp(message.timestamp)}
                    </div>
                  </div>
                </div>
              ))}
              
              {/* Typing indicator */}
              {isTyping && (
                <div className="flex justify-start mb-4">
                  <div className={`rounded-2xl p-3 ${
                    resolvedTheme === "dark" ? "bg-gray-800" : "bg-gray-100"
                  }`}>
                    <div className="flex space-x-1">
                      <div className="w-2 h-2 rounded-full bg-gray-500 animate-bounce" />
                      <div className="w-2 h-2 rounded-full bg-gray-500 animate-bounce animation-delay-500" />
                      <div className="w-2 h-2 rounded-full bg-gray-500 animate-bounce animation-delay-2000" />
                    </div>
                  </div>
                </div>
              )}
              
              <div ref={messagesEndRef} />
            </div>
            
            {/* Quick Suggestions */}
            {messages.length < 3 && (
              <div className="px-4 mb-3 flex flex-wrap gap-2">
                {suggestions.map((suggestion, index) => (
                  <button
                    key={index}
                    className="text-xs py-1 px-3 rounded-full border border-gray-200 dark:border-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
                    onClick={() => {
                      setInputText(suggestion);
                      inputRef.current?.focus();
                    }}
                  >
                    {suggestion}
                  </button>
                ))}
              </div>
            )}
            
            {/* Attachments Preview */}
            {attachments.length > 0 && (
              <div className="px-4 pb-2">
                <div className="flex flex-wrap gap-2">
                  {attachments.map((attachment, index) => (
                    <div key={index} className="relative w-16 h-16">
                      <img 
                        src={attachment} 
                        alt={`Attachment ${index}`} 
                        className="w-full h-full object-cover rounded-md"
                      />
                      <button
                        onClick={() => removeAttachment(index)}
                        className="absolute -top-2 -right-2 bg-gray-800 text-white rounded-full p-1"
                      >
                        <X className="h-3 w-3" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}
            
            {/* Input Area */}
            <div className="p-4 border-t dark:border-gray-800">
              <div className="flex items-center space-x-2">
                <div className="flex-1 relative">
                  <input
                    type="text"
                    ref={inputRef}
                    value={inputText}
                    onChange={(e) => setInputText(e.target.value)}
                    onKeyPress={handleKeyPress}
                    placeholder="Écrivez votre message..."
                    className={`w-full p-3 pl-10 pr-10 rounded-full border focus:outline-none focus:ring-2 focus:ring-primary/50 ${
                      resolvedTheme === "dark"
                        ? "bg-gray-800 border-gray-700 text-white"
                        : "bg-gray-100 border-gray-200 text-gray-800"
                    }`}
                  />
                  <Smile className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                </div>
                <div className="flex space-x-1">
                  <button
                    onClick={handleFileUpload}
                    className={`p-3 rounded-full ${
                      resolvedTheme === "dark"
                        ? "bg-gray-800 text-gray-300 hover:bg-gray-700"
                        : "bg-gray-100 text-gray-600 hover:bg-gray-200"
                    }`}
                  >
                    <Paperclip className="h-5 w-5" />
                  </button>
                  <button
                    onClick={toggleRecording}
                    className={`p-3 rounded-full ${
                      isRecording
                        ? "bg-red-500 text-white"
                        : resolvedTheme === "dark"
                        ? "bg-gray-800 text-gray-300 hover:bg-gray-700"
                        : "bg-gray-100 text-gray-600 hover:bg-gray-200"
                    }`}
                  >
                    <Mic className="h-5 w-5" />
                  </button>
                  <button
                    onClick={handleSendMessage}
                    className="p-3 rounded-full bg-primary text-white hover:bg-primary-600 transition-colors"
                  >
                    <Send className="h-5 w-5" />
                  </button>
                </div>
              </div>
              <div className="mt-2 text-xs text-center text-gray-500 dark:text-gray-400">
                Propulsé par AIrion GPT-5 Ultra 2025 • 100% confidentiel
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Minimized Chat Window */}
      <AnimatePresence>
        {isOpen && isMinimized && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 10 }}
            className="mb-4 p-3 bg-primary text-white rounded-full shadow-lg cursor-pointer flex items-center"
            onClick={() => setIsMinimized(false)}
          >
            <MessageSquare className="h-5 w-5 mr-2" />
            <span className="font-medium">Continuer la conversation</span>
            {hasUnread && (
              <span className="ml-2 flex h-5 w-5 items-center justify-center rounded-full bg-red-500 text-xs font-medium">
                1
              </span>
            )}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Chat Button */}
      <motion.button
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        onClick={() => {
          setIsOpen(!isOpen);
          setIsMinimized(false);
          setHasUnread(false);
        }}
        className="bg-primary hover:bg-primary-600 text-white rounded-full p-4 shadow-lg flex items-center justify-center focus:outline-none focus:ring-2 focus:ring-primary/50 focus:ring-offset-2"
      >
        {isOpen ? (
          <X className="h-6 w-6" />
        ) : (
          <>
            <MessageSquare className="h-6 w-6" />
            {hasUnread && (
              <span className="absolute -top-1 -right-1 flex h-5 w-5 items-center justify-center rounded-full bg-red-500 text-xs font-medium">
                1
              </span>
            )}
          </>
        )}
      </motion.button>
    </div>
  );
};

export default Chatbot;