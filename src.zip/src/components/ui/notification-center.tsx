import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Bell, X, CheckCircle, AlertCircle, Info, Mail, Calendar, ShoppingCart, Clock } from 'lucide-react';
import { useTheme } from '@/context/ThemeContext';

type NotificationType = 'info' | 'success' | 'warning' | 'error' | 'message' | 'event' | 'payment' | 'reminder';

interface Notification {
  id: string;
  type: NotificationType;
  title: string;
  message: string;
  time: Date;
  read: boolean;
  actionUrl?: string;
  actionLabel?: string;
}

const getIconForType = (type: NotificationType, className = 'h-5 w-5') => {
  switch (type) {
    case 'success':
      return <CheckCircle className={`${className} text-green-500`} />;
    case 'warning':
      return <AlertCircle className={`${className} text-amber-500`} />;
    case 'error':
      return <AlertCircle className={`${className} text-red-500`} />;
    case 'message':
      return <Mail className={`${className} text-blue-500`} />;
    case 'event':
      return <Calendar className={`${className} text-purple-500`} />;
    case 'payment':
      return <ShoppingCart className={`${className} text-emerald-500`} />;
    case 'reminder':
      return <Clock className={`${className} text-pink-500`} />;
    default:
      return <Info className={`${className} text-blue-500`} />;
  }
};

// Demo notifications
const demoNotifications: Notification[] = [
  {
    id: '1',
    type: 'success',
    title: 'Chatbot déployé!',
    message: 'Votre chatbot WhatsApp a été configuré avec succès et est maintenant en ligne.',
    time: new Date(Date.now() - 1000 * 60 * 5), // 5 minutes ago
    read: false,
    actionUrl: '/dashboard',
    actionLabel: 'Voir les statistiques'
  },
  {
    id: '2',
    type: 'info',
    title: 'Mise à jour disponible',
    message: 'Une nouvelle version de notre plateforme est disponible avec des fonctionnalités IA améliorées.',
    time: new Date(Date.now() - 1000 * 60 * 60), // 1 hour ago
    read: true
  },
  {
    id: '3',
    type: 'message',
    title: 'Nouveau message',
    message: 'Vous avez reçu un message de l\'équipe support concernant votre demande récente.',
    time: new Date(Date.now() - 1000 * 60 * 60 * 3), // 3 hours ago
    read: false,
    actionUrl: '/messages',
    actionLabel: 'Lire le message'
  },
  {
    id: '4',
    type: 'event',
    title: 'Webinaire à venir',
    message: 'Rappel: Webinaire "Automatisation des processus business" demain à 14h00.',
    time: new Date(Date.now() - 1000 * 60 * 60 * 24), // 1 day ago
    read: true,
    actionUrl: '/events',
    actionLabel: 'Ajouter au calendrier'
  },
  {
    id: '5',
    type: 'payment',
    title: 'Paiement confirmé',
    message: 'Votre abonnement mensuel a été renouvelé avec succès pour le mois prochain.',
    time: new Date(Date.now() - 1000 * 60 * 60 * 24 * 2), // 2 days ago
    read: true
  }
];

export const NotificationCenter = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [notifications, setNotifications] = useState<Notification[]>(demoNotifications);
  const [unreadCount, setUnreadCount] = useState(0);
  const [hasNewNotification, setHasNewNotification] = useState(false);
  const { resolvedTheme } = useTheme();

  // Calculate unread count
  useEffect(() => {
    const count = notifications.filter(notification => !notification.read).length;
    setUnreadCount(count);
  }, [notifications]);

  // Simulate receiving a new notification
  useEffect(() => {
    const timer = setTimeout(() => {
      const newNotification: Notification = {
        id: `new-${Date.now()}`,
        type: 'reminder',
        title: 'Automatisation planifiée',
        message: 'Votre automatisation de relance email sera exécutée dans 30 minutes.',
        time: new Date(),
        read: false,
        actionUrl: '/automations',
        actionLabel: 'Voir les détails'
      };
      
      setNotifications(prevNotifications => [newNotification, ...prevNotifications]);
      setHasNewNotification(true);
      
      // Vibrate if available on the device
      if (navigator.vibrate) {
        navigator.vibrate(200);
      }
    }, 15000); // After 15 seconds of loading the component
    
    return () => clearTimeout(timer);
  }, []);

  // Format notification time
  const formatTime = (date: Date) => {
    const now = new Date();
    const diffInSeconds = Math.floor((now.getTime() - date.getTime()) / 1000);
    
    if (diffInSeconds < 60) {
      return 'À l\'instant';
    } else if (diffInSeconds < 3600) {
      const minutes = Math.floor(diffInSeconds / 60);
      return `Il y a ${minutes} ${minutes === 1 ? 'minute' : 'minutes'}`;
    } else if (diffInSeconds < 86400) {
      const hours = Math.floor(diffInSeconds / 3600);
      return `Il y a ${hours} ${hours === 1 ? 'heure' : 'heures'}`;
    } else {
      const days = Math.floor(diffInSeconds / 86400);
      return `Il y a ${days} ${days === 1 ? 'jour' : 'jours'}`;
    }
  };

  // Mark a notification as read
  const markAsRead = (id: string) => {
    setNotifications(prevNotifications =>
      prevNotifications.map(notification =>
        notification.id === id ? { ...notification, read: true } : notification
      )
    );
  };

  // Mark all notifications as read
  const markAllAsRead = () => {
    setNotifications(prevNotifications =>
      prevNotifications.map(notification => ({ ...notification, read: true }))
    );
  };

  // Remove a notification
  const removeNotification = (id: string) => {
    setNotifications(prevNotifications =>
      prevNotifications.filter(notification => notification.id !== id)
    );
  };

  // Toggle notification center
  const toggleNotificationCenter = () => {
    setIsOpen(!isOpen);
    setHasNewNotification(false);
  };

  return (
    <div className="relative">
      {/* Notification Bell */}
      <button
        onClick={toggleNotificationCenter}
        className="relative p-2 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-full focus:outline-none focus:ring-2 focus:ring-primary"
        aria-label="Notifications"
      >
        <Bell className="h-6 w-6" />
        
        {/* Notification Badge */}
        {unreadCount > 0 && (
          <motion.span
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            className="absolute top-0 right-0 inline-flex items-center justify-center px-2 py-1 text-xs font-bold leading-none text-white transform translate-x-1/2 -translate-y-1/2 bg-red-500 rounded-full"
          >
            {unreadCount}
          </motion.span>
        )}
        
        {/* New Notification Indicator */}
        {hasNewNotification && (
          <motion.span
            initial={{ scale: 0 }}
            animate={{ 
              scale: [1, 1.2, 1],
              opacity: [1, 0.8, 1]
            }}
            transition={{
              duration: 2,
              repeat: Infinity,
              repeatType: "reverse"
            }}
            className="absolute bottom-0 right-0 w-3 h-3 bg-blue-500 rounded-full border-2 border-white dark:border-gray-900"
          />
        )}
      </button>
      
      {/* Notification Panel */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 10, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 10, scale: 0.95 }}
            transition={{ duration: 0.2 }}
            className={`absolute right-0 mt-2 w-80 sm:w-96 max-h-[32rem] overflow-hidden rounded-lg shadow-lg z-50 ${
              resolvedTheme === "dark" ? "bg-gray-900 border border-gray-800" : "bg-white border border-gray-100"
            }`}
          >
            {/* Header */}
            <div className="p-4 border-b dark:border-gray-800 flex items-center justify-between">
              <h3 className="text-lg font-medium text-gray-900 dark:text-gray-100">Notifications</h3>
              <div className="flex items-center gap-2">
                {unreadCount > 0 && (
                  <button
                    onClick={markAllAsRead}
                    className="text-xs text-primary hover:text-primary-700 font-medium"
                  >
                    Tout marquer comme lu
                  </button>
                )}
                <button
                  onClick={() => setIsOpen(false)}
                  className="text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200"
                >
                  <X className="h-5 w-5" />
                </button>
              </div>
            </div>
            
            {/* Notification List */}
            <div className="overflow-y-auto max-h-[28rem] custom-scrollbar">
              {notifications.length === 0 ? (
                <div className="py-8 px-4 text-center text-gray-500 dark:text-gray-400">
                  <Bell className="h-12 w-12 mx-auto mb-3 text-gray-300 dark:text-gray-600" />
                  <p>Aucune notification</p>
                </div>
              ) : (
                notifications.map((notification) => (
                  <motion.div
                    key={notification.id}
                    layout
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, height: 0 }}
                    className={`p-4 border-b dark:border-gray-800 hover:bg-gray-50 dark:hover:bg-gray-800/50 relative ${
                      !notification.read ? 'bg-blue-50 dark:bg-blue-900/10' : ''
                    }`}
                  >
                    <div className="flex">
                      <div className="flex-shrink-0 mr-3">
                        {getIconForType(notification.type)}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between mb-1">
                          <p className={`text-sm font-medium ${!notification.read ? 'text-gray-900 dark:text-white' : 'text-gray-700 dark:text-gray-300'}`}>
                            {notification.title}
                          </p>
                          <span className="text-xs text-gray-500 dark:text-gray-400">
                            {formatTime(notification.time)}
                          </span>
                        </div>
                        <p className="text-sm text-gray-600 dark:text-gray-400 mb-2">
                          {notification.message}
                        </p>
                        {notification.actionUrl && (
                          <a
                            href={notification.actionUrl}
                            className="inline-flex items-center text-xs font-medium text-primary hover:text-primary-700"
                          >
                            {notification.actionLabel || 'Voir détails'}
                          </a>
                        )}
                      </div>
                      <div className="ml-2 flex flex-col space-y-2">
                        {!notification.read && (
                          <button
                            onClick={() => markAsRead(notification.id)}
                            className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-200"
                            aria-label="Marquer comme lu"
                          >
                            <CheckCircle className="h-4 w-4" />
                          </button>
                        )}
                        <button
                          onClick={() => removeNotification(notification.id)}
                          className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-200"
                          aria-label="Supprimer la notification"
                        >
                          <X className="h-4 w-4" />
                        </button>
                      </div>
                    </div>
                  </motion.div>
                ))
              )}
            </div>
            
            {/* Footer */}
            {notifications.length > 0 && (
              <div className="p-3 text-center border-t dark:border-gray-800">
                <a
                  href="/notifications"
                  className="text-sm font-medium text-primary hover:text-primary-700"
                >
                  Voir toutes les notifications
                </a>
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default NotificationCenter;