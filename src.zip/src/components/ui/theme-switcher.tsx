import { useTheme } from "@/context/ThemeContext";
import { SunIcon, MoonIcon, LaptopIcon } from "lucide-react";
import { motion } from "framer-motion";

interface ThemeSwitcherProps {
  className?: string;
}

export function ThemeSwitcher({ className = "" }: ThemeSwitcherProps) {
  const { theme, setTheme } = useTheme();

  return (
    <div className={`flex items-center space-x-1 p-1 bg-secondary/50 dark:bg-gray-800/50 rounded-lg ${className}`}>
      {["light", "dark", "system"].map((t) => (
        <button
          key={t}
          onClick={() => setTheme(t as "light" | "dark" | "system")}
          className={`p-2 rounded-md focus-ring transition-all duration-200 ${
            theme === t 
              ? "bg-white dark:bg-gray-700 shadow-sm" 
              : "text-gray-500 hover:text-gray-900 dark:hover:text-gray-100"
          }`}
          aria-label={`Switch to ${t} theme`}
        >
          {t === "light" && (
            <motion.div
              initial={{ rotate: 0 }}
              animate={{ rotate: theme === "light" ? [0, 15, 0] : 0 }}
              transition={{ duration: 0.5, ease: "easeInOut" }}
            >
              <SunIcon className="h-5 w-5" />
            </motion.div>
          )}
          {t === "dark" && (
            <motion.div
              initial={{ scale: 1 }}
              animate={{ scale: theme === "dark" ? [1, 1.1, 1] : 1 }}
              transition={{ duration: 0.5, ease: "easeInOut" }}
            >
              <MoonIcon className="h-5 w-5" />
            </motion.div>
          )}
          {t === "system" && (
            <motion.div
              initial={{ y: 0 }}
              animate={{ y: theme === "system" ? [0, -3, 0] : 0 }}
              transition={{ duration: 0.5, ease: "easeInOut" }}
            >
              <LaptopIcon className="h-5 w-5" />
            </motion.div>
          )}
        </button>
      ))}
    </div>
  );
}

export function ThemeSwitcherMini() {
  const { theme, setTheme } = useTheme();
  
  const toggleTheme = () => {
    if (theme === "dark") setTheme("light");
    else if (theme === "light") setTheme("dark");
    else setTheme(document.documentElement.classList.contains("dark") ? "light" : "dark");
  };

  return (
    <button
      onClick={toggleTheme}
      className="p-2 rounded-full bg-secondary/50 dark:bg-gray-800/50 hover:bg-secondary/70 dark:hover:bg-gray-700/70 focus-ring transition-all duration-200"
      aria-label="Toggle theme"
    >
      <motion.div
        animate={{ rotate: 360 }}
        transition={{ duration: 0.5, ease: "easeInOut" }}
        key={theme} // Change key to trigger animation on theme change
      >
        {theme === "dark" || (theme === "system" && document.documentElement.classList.contains("dark")) ? (
          <SunIcon className="h-5 w-5" />
        ) : (
          <MoonIcon className="h-5 w-5" />
        )}
      </motion.div>
    </button>
  );
}