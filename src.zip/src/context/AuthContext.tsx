import { createContext, useState, useEffect, ReactNode } from "react";

// Définir un type pour les informations de connexion
interface LoginCredentials {
  email: string;
  password: string;
}

// Définir un type pour l'utilisateur (ajouter displayName en optionnel)
interface User {
  id: string;
  email: string;
  name: string;
  displayName?: string; // Propriété optionnelle
}

// Définir le type pour le contexte d'authentification
interface AuthContextType {
  user: User | null;
  isLoading: boolean;
  login: (credentials: LoginCredentials) => Promise<void>; // Fonction de connexion avec email et mot de passe
  logout: () => void; // Fonction de déconnexion
  loginWithGoogle?: () => Promise<void>; // Fonction de connexion avec Google (optionnelle)
}

// Créer le contexte d'authentification
export const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Propriétés du fournisseur du contexte
interface AuthProviderProps {
  children: ReactNode;
}

// Fournisseur du contexte d'authentification
export const AuthProvider = ({ children }: AuthProviderProps) => {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);

  useEffect(() => {
    // Simuler la récupération de l'utilisateur depuis le localStorage ou une API
    const storedUser = localStorage.getItem("user");
    if (storedUser) {
      setUser(JSON.parse(storedUser)); // On suppose que l'utilisateur est stocké dans localStorage
    }
    setIsLoading(false);
  }, []);

  // Fonction pour la connexion par email et mot de passe
  const login = async (credentials: LoginCredentials) => {
    try {
      setIsLoading(true);
      // Simuler une API ou une logique pour la connexion
      const response = await mockLoginApi(credentials); // Ici, tu remplaces par ta propre logique d'API
      setUser(response.user);
      localStorage.setItem("user", JSON.stringify(response.user));
    } catch (error: unknown) {
      // Vérifier que l'erreur est bien une instance de Error
      if (error instanceof Error) {
        throw new Error(error.message || "Erreur de connexion");
      } else {
        throw new Error("Erreur inconnue lors de la connexion");
      }
    } finally {
      setIsLoading(false);
    }
  };

  // Fonction de déconnexion
  const logout = () => {
    setUser(null);
    localStorage.removeItem("user");
  };

  // Fonction pour la connexion avec Google
  const loginWithGoogle = async () => {
    try {
      setIsLoading(true);
      // Simuler la connexion avec Google
      const response = await mockGoogleLoginApi(); // Remplace par ta logique de connexion avec Google
      setUser(response.user);
      localStorage.setItem("user", JSON.stringify(response.user));
    } catch (error: unknown) {
      // Vérifier que l'erreur est bien une instance de Error
      if (error instanceof Error) {
        throw new Error(error.message || "Erreur de connexion avec Google");
      } else {
        throw new Error("Erreur inconnue lors de la connexion avec Google");
      }
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <AuthContext.Provider value={{ user, isLoading, login, logout, loginWithGoogle }}>
      {children}
    </AuthContext.Provider>
  );
};

// Fonctions simulées pour l'API de connexion (à remplacer par ta logique réelle)
const mockLoginApi = async (credentials: LoginCredentials) => {
  return new Promise<{ user: User }>((resolve, reject) => {
    setTimeout(() => {
      if (credentials.email === "test@email.com" && credentials.password === "password") {
        resolve({
          user: { id: "1", email: "test@email.com", name: "John Doe", displayName: "John Doe" }
        });
      } else {
        reject(new Error("Identifiants incorrects"));
      }
    }, 1000);
  });
};

const mockGoogleLoginApi = async () => {
  return new Promise<{ user: User }>((resolve) => {
    setTimeout(() => {
      resolve({
        user: { id: "google-id", email: "google-user@email.com", name: "Google User", displayName: "Google User" }
      });
    }, 1000);
  });
};
