import { initializeApp, getApps, getApp } from "firebase/app";
import { getAuth, GoogleAuthProvider } from "firebase/auth";

// Configuration Firebase avec vérification des variables d'environnement
const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY || "AIzaSyDLiQzSbwTfWphRuyVJX9GBHF1jhtp-yJg",
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN || "aitotech-9c481.firebaseapp.com",
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID || "aitotech-9c481",
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET || "aitotech-9c481.appspot.com",
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID || "215024436807",
  appId: import.meta.env.VITE_FIREBASE_APP_ID || "1:215024436807:web:d4ebc985e72018f609d362",
  measurementId: import.meta.env.VITE_FIREBASE_MEASUREMENT_ID || "G-H5M5L5312D"
};

// Vérifier si Firebase est déjà initialisé
const app = getApps().length ? getApp() : initializeApp(firebaseConfig);

export const auth = getAuth(app);
export const googleProvider = new GoogleAuthProvider();
export default app;
