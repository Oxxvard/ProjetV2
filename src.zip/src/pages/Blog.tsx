import { useState } from "react";
import { Link } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";

interface BlogPost {
  id: number;
  title: string;
  date: string;
  excerpt: string;
  image: string;
  slug: string;
  category: string;
}

const blogPosts: BlogPost[] = [
  {
    id: 1,
    title: "Comment l'IA transforme le service client en 2023",
    date: "18 Juin 2023",
    excerpt:
      "Découvrez comment les chatbots IA révolutionnent la relation client et comment les implémenter dans votre entreprise.",
    image:
      "https://images.unsplash.com/photo-1579389083078-4e7018379f7e?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
    slug: "comment-ia-transforme-service-client-2023",
    category: "Intelligence Artificielle",
  },
  {
    id: 2,
    title: "5 automatisations d'emails qui boostent vos ventes",
    date: "05 Juin 2023",
    excerpt:
      "Apprenez à mettre en place des séquences d'emails automatisées qui convertissent vos prospects en clients fidèles.",
    image:
      "https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
    slug: "5-automatisations-emails-boostent-ventes",
    category: "Marketing Automation",
  },
  {
    id: 3,
    title: "Les meilleurs outils No-Code pour automatiser votre business",
    date: "28 Mai 2023",
    excerpt:
      "Comparatif des plateformes No-Code les plus performantes pour créer des automatisations sans compétences techniques.",
    image:
      "https://images.unsplash.com/photo-1563986768609-322da13575f3?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
    slug: "meilleurs-outils-no-code-automatiser-business",
    category: "No-Code",
  },
  {
    id: 4,
    title: "Automatiser la collecte d'avis clients : guide pratique",
    date: "15 Mai 2023",
    excerpt:
      "Comment mettre en place un système automatisé pour collecter et gérer les avis de vos clients sur Google et autres plateformes.",
    image:
      "https://images.unsplash.com/photo-1560472355-a3b4bcfe790c?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
    slug: "automatiser-collecte-avis-clients-guide-pratique",
    category: "Stratégie Digitale",
  },
  {
    id: 5,
    title: "Créer un tunnel de vente automatisé en 5 étapes",
    date: "03 Mai 2023",
    excerpt:
      "Guide étape par étape pour construire un tunnel de vente qui convertit automatiquement vos prospects en clients.",
    image:
      "https://images.unsplash.com/photo-1553877522-43269d4ea984?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
    slug: "creer-tunnel-vente-automatise-5-etapes",
    category: "Ventes",
  },
  {
    id: 6,
    title: "L'impact de l'automatisation sur la satisfaction client",
    date: "25 Avril 2023",
    excerpt:
      "Études de cas et statistiques sur l'impact positif de l'automatisation sur l'expérience et la satisfaction client.",
    image:
      "https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
    slug: "impact-automatisation-satisfaction-client",
    category: "Expérience Client",
  },
  {
    id: 7,
    title: "Intégrer WhatsApp Business API à votre stratégie d'automatisation",
    date: "18 Avril 2023",
    excerpt:
      "Comment utiliser l'API WhatsApp Business pour automatiser vos communications client et augmenter vos conversions.",
    image:
      "https://images.unsplash.com/photo-1529400971008-f566de0e6dfc?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
    slug: "integrer-whatsapp-business-api-strategie-automatisation",
    category: "Communication Client",
  },
  {
    id: 8,
    title: "Automatiser votre processus de recrutement avec l'IA",
    date: "10 Avril 2023",
    excerpt:
      "Comment l'intelligence artificielle peut transformer votre processus de recrutement et vous faire gagner du temps.",
    image:
      "https://images.unsplash.com/photo-1471479917193-f00955256257?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
    slug: "automatiser-processus-recrutement-ia",
    category: "Ressources Humaines",
  },
  {
    id: 9,
    title: "Les erreurs à éviter lors de l'automatisation de votre business",
    date: "02 Avril 2023",
    excerpt:
      "Les pièges courants de l'automatisation et comment les éviter pour maximiser votre ROI.",
    image:
      "https://images.unsplash.com/photo-1603202662747-00e33e7d1468?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
    slug: "erreurs-eviter-automatisation-business",
    category: "Stratégie",
  },
];

const categories = [
  "Toutes les catégories",
  "Intelligence Artificielle",
  "Marketing Automation",
  "No-Code",
  "Stratégie Digitale",
  "Ventes",
  "Expérience Client",
  "Communication Client",
  "Ressources Humaines",
  "Stratégie",
];

const Blog = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("Toutes les catégories");

  const filteredPosts = blogPosts.filter((post) => {
    const matchesSearch = post.title
      .toLowerCase()
      .includes(searchTerm.toLowerCase()) ||
      post.excerpt.toLowerCase().includes(searchTerm.toLowerCase());
      
    const matchesCategory = selectedCategory === "Toutes les catégories" || post.category === selectedCategory;
    
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="container mx-auto px-4 py-12">
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold text-neutral-900 mb-4">
          Blog AutomateIA 📚
        </h1>
        <p className="text-xl text-neutral-600 max-w-3xl mx-auto">
          Conseils, astuces et études de cas pour automatiser et développer votre business avec l'IA.
        </p>
      </div>

      <div className="flex flex-col md:flex-row mb-8 gap-4">
        <div className="w-full md:w-2/3">
          <Input
            type="text"
            placeholder="Rechercher un article..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full"
          />
        </div>
        <div className="w-full md:w-1/3">
          <select
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
            className="w-full p-2.5 border border-gray-300 rounded-md focus:ring-primary-500 focus:border-primary-500"
          >
            {categories.map((category) => (
              <option key={category} value={category}>
                {category}
              </option>
            ))}
          </select>
        </div>
      </div>

      {filteredPosts.length === 0 ? (
        <div className="text-center py-16">
          <h3 className="text-2xl font-semibold text-neutral-700 mb-2">
            Aucun article trouvé
          </h3>
          <p className="text-neutral-600">
            Essayez de modifier votre recherche ou de sélectionner une autre catégorie.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredPosts.map((post) => (
            <Card 
              key={post.id}
              className="overflow-hidden hover:shadow-lg transition-shadow duration-300"
            >
              <div className="h-48 overflow-hidden">
                <img
                  src={post.image}
                  alt={post.title}
                  className="w-full h-full object-cover hover:scale-105 transition-transform duration-500"
                />
              </div>
              <CardContent className="p-6">
                <div className="flex justify-between items-center mb-2">
                  <span className="text-sm text-neutral-500">{post.date}</span>
                  <span className="text-xs bg-primary-100 text-primary-800 px-2 py-1 rounded-full">
                    {post.category}
                  </span>
                </div>
                <h3 className="text-xl font-semibold text-neutral-900 mb-3 line-clamp-2">
                  {post.title}
                </h3>
                <p className="text-neutral-600 mb-4 line-clamp-3">
                  {post.excerpt}
                </p>
                <Link href={`/blog/${post.slug}`}>
                  <a className="text-primary-500 font-medium inline-flex items-center hover:text-primary-600">
                    Lire l'article <i className="fas fa-arrow-right ml-2 text-sm"></i>
                  </a>
                </Link>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      <div className="mt-16 bg-primary-50 rounded-2xl p-8 md:p-12">
        <div className="max-w-3xl mx-auto text-center">
          <h2 className="text-2xl md:text-3xl font-bold text-neutral-900 mb-4">
            Recevez nos astuces d'automatisation 📩
          </h2>
          <p className="text-neutral-700 mb-6">
            Inscrivez-vous à notre newsletter pour recevoir en exclusivité nos meilleurs conseils et tutoriels.
          </p>
          <form className="flex flex-col sm:flex-row gap-3 max-w-lg mx-auto">
            <Input
              type="email"
              placeholder="Votre adresse email"
              className="flex-grow"
            />
            <button
              type="submit"
              className="px-6 py-2 bg-primary-500 text-white rounded-lg font-medium hover:bg-primary-600 transition duration-150 ease-in-out"
            >
              S'inscrire
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};

export default Blog;
