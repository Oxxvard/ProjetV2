import { useEffect } from "react";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from "wouter";
import NewsletterSection from "@/components/home/NewsletterSection";

interface BlogPost {
  id: number;
  title: string;
  date: string;
  author: {
    name: string;
    avatar: string;
    role: string;
  };
  content: string[];
  image: string;
  slug: string;
  category: string;
  readTime: string;
}

const blogPosts: Record<string, BlogPost> = {
  "comment-ia-transforme-service-client-2023": {
    id: 1,
    title: "Comment l'IA transforme le service client en 2023",
    date: "18 Juin 2023",
    author: {
      name: "Sophie Martin",
      avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80",
      role: "Experte en IA & Automatisation",
    },
    content: [
      "L'intelligence artificielle transforme radicalement le paysage du service client, offrant des opportunités sans précédent pour les entreprises qui cherchent à améliorer leur expérience client tout en optimisant leurs coûts opérationnels.",
      "Selon une étude récente de Gartner, d'ici 2025, 40% de toutes les interactions du service client seront automatisées grâce à l'IA et aux processus de machine learning. Cette évolution n'est pas seulement une question de réduction des coûts, mais aussi d'amélioration significative de la satisfaction client.",
      "## Les chatbots IA : bien plus que de simples robots",
      "La nouvelle génération de chatbots propulsés par l'IA conversationnelle comme GPT-4 offre des interactions qui se rapprochent de plus en plus d'une conversation humaine naturelle. Ces assistants virtuels peuvent :",
      "- Comprendre le contexte et l'intention derrière les questions des clients",
      "- Apprendre de chaque interaction pour s'améliorer continuellement",
      "- Fournir des réponses personnalisées en fonction de l'historique du client",
      "- Gérer plusieurs demandes simultanément sans temps d'attente",
      "Les entreprises qui ont implémenté ces solutions constatent une réduction de 70% du temps de réponse moyen et une augmentation de 35% de la satisfaction client.",
      "## L'automatisation omnicanale : une nécessité",
      "Les consommateurs d'aujourd'hui s'attendent à pouvoir contacter une entreprise via le canal de leur choix : email, chat, réseaux sociaux, WhatsApp, et bien d'autres. L'IA permet désormais d'unifier ces canaux et d'offrir une expérience cohérente.",
      "Un système d'automatisation omnicanal efficace permet de :",
      "1. Maintenir un historique client unifié à travers tous les canaux",
      "2. Transférer sans friction une conversation d'un canal à un autre",
      "3. Garantir la cohérence des réponses, quel que soit le point de contact",
      "4. Collecter des données précieuses pour optimiser continuellement l'expérience",
      "## Cas d'étude : Restaurant Le Bistrot Parisien",
      "Le Bistrot Parisien, un restaurant traditionnel français, a implémenté un système de chatbot IA sur WhatsApp et son site web. Les résultats après 3 mois :",
      "- 30% d'augmentation des réservations",
      "- 15 heures par semaine économisées sur la gestion des appels",
      "- Note Google passée de 4.2 à 4.8 étoiles grâce à l'automatisation des demandes d'avis",
      "- ROI de 300% sur l'investissement initial",
      "Le gérant Thomas Martin témoigne : 'Au début, j'étais sceptique à l'idée de confier une partie de notre service client à un robot. Mais les résultats parlent d'eux-mêmes. Notre équipe peut désormais se concentrer sur l'accueil en salle plutôt que de répondre au téléphone.'",
      "## Comment implémenter l'IA dans votre stratégie de service client",
      "L'implémentation d'une solution d'IA pour le service client nécessite une approche méthodique :",
      "1. **Identifiez les processus répétitifs** qui peuvent être automatisés",
      "2. **Choisissez une solution adaptée** à la taille de votre entreprise",
      "3. **Formez votre IA** avec vos FAQ et scénarios de conversation les plus courants",
      "4. **Intégrez l'IA à vos systèmes existants** (CRM, outils de gestion, etc.)",
      "5. **Définissez clairement quand l'intervention humaine est nécessaire**",
      "6. **Mesurez les résultats** et optimisez continuellement",
      "## L'importance de l'équilibre humain-IA",
      "Malgré tous les avantages de l'IA, l'élément humain reste essentiel. Les entreprises les plus performantes utilisent l'IA comme un amplificateur de capacités pour leurs équipes, et non comme un remplacement.",
      "Les meilleures pratiques incluent :",
      "- Former les agents pour qu'ils travaillent efficacement avec l'IA",
      "- Utiliser l'IA pour les tâches répétitives et laisser les situations complexes aux humains",
      "- Permettre une transition fluide entre l'IA et un agent humain quand nécessaire",
      "- Utiliser les insights générés par l'IA pour améliorer les compétences des agents",
      "## Conclusion",
      "L'IA ne transforme pas seulement le service client - elle le réinvente complètement. Les entreprises qui adopteront ces technologies dès maintenant ne se contenteront pas de réduire leurs coûts, elles établiront de nouveaux standards d'excellence en matière d'expérience client.",
      "Chez AutomateIA, nous aidons les entreprises de toutes tailles à implémenter des solutions d'IA adaptées à leurs besoins spécifiques. Notre approche sur mesure garantit une intégration harmonieuse de l'IA dans votre stratégie de service client existante.",
      "Prêt à transformer votre service client avec l'IA ? Contactez-nous pour une consultation gratuite ou essayez notre solution pendant 7 jours sans engagement."
    ],
    image: "https://images.unsplash.com/photo-1579389083078-4e7018379f7e?ixlib=rb-1.2.1&auto=format&fit=crop&w=1200&q=80",
    slug: "comment-ia-transforme-service-client-2023",
    category: "Intelligence Artificielle",
    readTime: "8 min",
  },
  "5-automatisations-emails-boostent-ventes": {
    id: 2,
    title: "5 automatisations d'emails qui boostent vos ventes",
    date: "05 Juin 2023",
    author: {
      name: "Julien Dubois",
      avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80",
      role: "Expert en Marketing Automation",
    },
    content: [
      "L'email marketing reste l'un des canaux les plus rentables avec un ROI moyen de 4200% selon la DMA. Mais pour maximiser son efficacité, l'automatisation est devenue indispensable. Dans cet article, nous allons explorer 5 automatisations d'emails qui ont prouvé leur efficacité pour augmenter significativement les ventes.",
      "## 1. Séquence de bienvenue personnalisée",
      "Le premier contact avec votre marque est crucial. Une séquence de bienvenue bien conçue peut transformer un simple abonné en client fidèle.",
      "**Éléments clés :**",
      "- Email 1 : Message de bienvenue + cadeau (24h après l'inscription)",
      "- Email 2 : Présentation de votre histoire et valeurs (3 jours après)",
      "- Email 3 : Démonstration de votre proposition de valeur unique (5 jours après)",
      "- Email 4 : Premier appel à l'action commercial avec offre spéciale (7 jours après)",
      "**Résultats moyens :** Augmentation des ventes de 33% par rapport à une simple confirmation d'inscription.",
      "## 2. Récupération de paniers abandonnés",
      "Environ 70% des paniers sont abandonnés avant l'achat. Cette automatisation permet de récupérer une partie significative de ces ventes perdues.",
      "**Séquence optimale :**",
      "- Email 1 : Rappel simple du panier (1h après l'abandon)",
      "- Email 2 : Témoignages clients + FAQ sur les objections courantes (24h après)",
      "- Email 3 : Offre incitative (réduction ou livraison gratuite) (48h après)",
      "**Conseil d'optimisation :** Personnalisez l'objet avec le nom du produit principal et utilisez des images du produit dans l'email.",
      "**Résultats moyens :** Récupération de 10-15% des paniers abandonnés",
      "## 3. Programme de fidélisation automatisé",
      "Acquérir un nouveau client coûte 5 à 25 fois plus cher que de fidéliser un client existant. Cette automatisation maximise la valeur vie client.",
      "**Composants essentiels :**",
      "- Emails déclenchés après chaque achat avec recommandations personnalisées",
      "- Alertes automatiques pour les produits complémentaires",
      "- Emails d'anniversaire clients avec offres spéciales",
      "- Programme de points et paliers avec emails de notification",
      "**Exemple concret :** Une boutique de cosmétiques a augmenté sa fréquence d'achat de 23% grâce à un programme de fidélisation automatisé qui suggère des produits complémentaires et rappelle le moment optimal de renouvellement.",
      "## 4. Réactivation des clients dormants",
      "En moyenne, 60-70% de votre liste d'emails devient inactive au fil du temps. Cette séquence permet de réveiller ces clients potentiels.",
      "**Stratégie efficace :**",
      "- Identification automatique des clients sans achat depuis 60-90 jours",
      "- Email 1 : \"Vous nous manquez\" avec sélection de nouveautés",
      "- Email 2 : Sondage pour comprendre leur inactivité (avec incentive)",
      "- Email 3 : Offre exceptionnelle à durée limitée",
      "- Email 4 : Dernier appel avant suppression de leur compte VIP/avantages",
      "**Résultats moyens :** Réactivation de 5-15% des clients dormants",
      "## 5. Upsell et cross-sell post-achat",
      "Le moment qui suit immédiatement un achat est idéal pour proposer des offres complémentaires, car la confiance est à son maximum.",
      "**Mise en place :**",
      "- Email de confirmation d'achat enrichi avec des recommandations de produits complémentaires",
      "- Email de suivi 3 jours après avec des produits fréquemment achetés ensemble",
      "- Email proposant la version premium du produit acheté (14 jours après pour les produits à usage régulier)",
      "**Exemple :** Un site de matériel photographique a augmenté son panier moyen de 31% en proposant automatiquement des accessoires complémentaires (filtres, sacs, batteries) après l'achat d'un appareil photo.",
      "## Les clés de réussite pour toutes vos automatisations d'emails",
      "Pour maximiser l'efficacité de ces 5 automatisations, suivez ces bonnes pratiques :",
      "1. **Segmentation précise** : Adaptez vos messages selon le comportement, l'historique d'achat et les préférences",
      "2. **Personnalisation au-delà du prénom** : Utilisez les données comportementales pour personnaliser le contenu",
      "3. **Tests A/B systématiques** : Testez régulièrement les objets, contenus et moments d'envoi",
      "4. **Mobile-first** : Plus de 60% des emails sont consultés sur mobile, optimisez en conséquence",
      "5. **Mesure et optimisation** : Suivez les KPIs clés (taux d'ouverture, clics, conversions) et ajustez continuellement",
      "## Conclusion",
      "Implémenter ces 5 automatisations d'emails peut transformer radicalement vos résultats commerciaux. L'aspect le plus intéressant est qu'une fois configurées, ces séquences fonctionnent en pilote automatique, générant des ventes pendant que vous vous concentrez sur d'autres aspects de votre business.",
      "Chez AutomateIA, nous accompagnons nos clients dans la mise en place de ces automatisations en utilisant des outils no-code qui permettent une implémentation rapide et des résultats immédiats. Contactez-nous pour découvrir comment nous pouvons vous aider à augmenter vos ventes grâce à l'automatisation de vos emails."
    ],
    image: "https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?ixlib=rb-1.2.1&auto=format&fit=crop&w=1200&q=80",
    slug: "5-automatisations-emails-boostent-ventes",
    category: "Marketing Automation",
    readTime: "10 min",
  },
};

const BlogPost = ({ params }: { params: { slug: string } }) => {
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  const post = blogPosts[params.slug];

  useEffect(() => {
    if (!post) {
      toast({
        title: "Article introuvable",
        description: "Cet article n'existe pas ou a été supprimé.",
        variant: "destructive",
      });
      setLocation("/blog");
    }
  }, [post, setLocation, toast]);

  if (!post) {
    return null;
  }

  const formatContent = (content: string) => {
    if (content.startsWith("##")) {
      return (
        <h2 className="text-2xl font-bold text-neutral-900 mt-8 mb-4">
          {content.replace("## ", "")}
        </h2>
      );
    } else if (content.startsWith("-")) {
      return (
        <li className="ml-6 mb-2 text-neutral-700">
          {content.replace("- ", "")}
        </li>
      );
    } else if (content.match(/^\d+\./)) {
      return (
        <li className="ml-6 mb-2 text-neutral-700 list-decimal">
          {content.replace(/^\d+\.\s/, "")}
        </li>
      );
    } else if (content.startsWith("**")) {
      return (
        <p className="mb-4 font-semibold text-neutral-800">
          {content.replace(/\*\*/g, "")}
        </p>
      );
    } else {
      return <p className="mb-4 text-neutral-700">{content}</p>;
    }
  };

  return (
    <div className="container mx-auto px-4 py-12">
      <article className="max-w-4xl mx-auto">
        <div className="mb-8">
          <Link href="/blog">
            <a className="text-primary-500 inline-flex items-center hover:text-primary-600 mb-4">
              <i className="fas fa-arrow-left mr-2"></i> Retour aux articles
            </a>
          </Link>
          <h1 className="text-3xl md:text-4xl font-bold text-neutral-900 mb-4">
            {post.title}
          </h1>
          <div className="flex items-center justify-between flex-wrap gap-4 mb-6">
            <div className="flex items-center">
              <img
                src={post.author.avatar}
                alt={post.author.name}
                className="w-10 h-10 rounded-full mr-3"
              />
              <div>
                <p className="font-medium text-neutral-900">
                  {post.author.name}
                </p>
                <p className="text-sm text-neutral-500">{post.author.role}</p>
              </div>
            </div>
            <div className="flex items-center space-x-4 text-sm text-neutral-500">
              <span>{post.date}</span>
              <span>•</span>
              <span>{post.readTime} de lecture</span>
              <span className="bg-primary-100 text-primary-800 px-2 py-1 rounded-full">
                {post.category}
              </span>
            </div>
          </div>
        </div>

        <div className="rounded-xl overflow-hidden mb-10">
          <img
            src={post.image}
            alt={post.title}
            className="w-full h-auto object-cover"
          />
        </div>

        <div className="prose prose-lg max-w-none">
          {post.content.map((paragraph, index) => {
            if (paragraph.startsWith("-")) {
              return (
                <ul key={index} className="list-disc mb-4">
                  {formatContent(paragraph)}
                </ul>
              );
            } else if (paragraph.match(/^\d+\./)) {
              return (
                <ol key={index} className="list-decimal mb-4">
                  {formatContent(paragraph)}
                </ol>
              );
            } else {
              return <div key={index}>{formatContent(paragraph)}</div>;
            }
          })}
        </div>

        <div className="mt-12 border-t border-gray-200 pt-8">
          <div className="flex flex-col sm:flex-row justify-between items-center gap-4">
            <div className="flex items-center">
              <img
                src={post.author.avatar}
                alt={post.author.name}
                className="w-12 h-12 rounded-full mr-4"
              />
              <div>
                <p className="font-semibold text-neutral-900">
                  Écrit par {post.author.name}
                </p>
                <p className="text-neutral-600">{post.author.role}</p>
              </div>
            </div>
            <div className="flex space-x-2">
              <button className="p-2 bg-blue-100 text-blue-600 rounded-full hover:bg-blue-200 transition-colors">
                <i className="fab fa-facebook-f"></i>
              </button>
              <button className="p-2 bg-blue-100 text-blue-400 rounded-full hover:bg-blue-200 transition-colors">
                <i className="fab fa-twitter"></i>
              </button>
              <button className="p-2 bg-blue-100 text-blue-500 rounded-full hover:bg-blue-200 transition-colors">
                <i className="fab fa-linkedin-in"></i>
              </button>
              <button className="p-2 bg-green-100 text-green-600 rounded-full hover:bg-green-200 transition-colors">
                <i className="far fa-envelope"></i>
              </button>
            </div>
          </div>
        </div>
      </article>

      <div className="mt-16">
        <h3 className="text-2xl font-bold text-neutral-900 mb-8 text-center">
          Articles similaires
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {Object.values(blogPosts)
            .filter((p) => p.id !== post.id)
            .slice(0, 3)
            .map((relatedPost) => (
              <div
                key={relatedPost.id}
                className="bg-white rounded-xl shadow-md overflow-hidden border border-neutral-100 hover:border-primary-200 transition duration-300"
              >
                <div className="h-48 overflow-hidden">
                  <img
                    src={relatedPost.image}
                    alt={relatedPost.title}
                    className="w-full h-full object-cover hover:scale-105 transition-transform duration-500"
                  />
                </div>
                <div className="p-6">
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-sm text-neutral-500">
                      {relatedPost.date}
                    </span>
                    <span className="text-xs bg-primary-100 text-primary-800 px-2 py-1 rounded-full">
                      {relatedPost.category}
                    </span>
                  </div>
                  <h3 className="text-xl font-semibold text-neutral-900 mb-3 line-clamp-2">
                    {relatedPost.title}
                  </h3>
                  <p className="text-neutral-600 mb-4 line-clamp-2">
                    {relatedPost.content[0]}
                  </p>
                  <Link href={`/blog/${relatedPost.slug}`}>
                    <a className="text-primary-500 font-medium inline-flex items-center hover:text-primary-600">
                      Lire l'article{" "}
                      <i className="fas fa-arrow-right ml-2 text-sm"></i>
                    </a>
                  </Link>
                </div>
              </div>
            ))}
        </div>
      </div>

      <div className="mt-20">
        <NewsletterSection />
      </div>
    </div>
  );
};

export default BlogPost;
