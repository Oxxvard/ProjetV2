import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";

const Contact = () => {
  const { toast } = useToast();
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    company: "",
    message: "",
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.name || !formData.email || !formData.message) {
      toast({
        title: "Erreur",
        description: "Veuillez remplir tous les champs obligatoires.",
        variant: "destructive",
      });
      return;
    }

    setIsSubmitting(true);
    
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      toast({
        title: "Message envoyé",
        description: "Nous vous répondrons dans les plus brefs délais.",
      });
      
      // Reset form
      setFormData({
        name: "",
        email: "",
        company: "",
        message: "",
      });
    } catch (error) {
      toast({
        title: "Erreur",
        description: "Une erreur est survenue. Veuillez réessayer.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="container mx-auto px-4 py-12">
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold text-neutral-900 mb-4">
          Contactez-nous 📞
        </h1>
        <p className="text-xl text-neutral-600 max-w-3xl mx-auto">
          Notre équipe d'experts est prête à répondre à toutes vos questions sur
          l'automatisation de votre business.
        </p>
      </div>

      <div className="max-w-5xl mx-auto">
        <div className="flex flex-col md:flex-row bg-white rounded-2xl shadow-lg overflow-hidden">
          <div className="md:w-1/2 bg-primary-600 p-10 text-white">
            <h2 className="text-2xl font-bold mb-6">Nous contacter</h2>
            <p className="mb-8 text-primary-50">
              Si vous avez des questions sur nos services d'automatisation, n'hésitez pas à nous contacter. Notre équipe se fera un plaisir de vous aider.
            </p>

            <div className="space-y-6">
              <div className="flex items-start">
                <div className="flex-shrink-0">
                  <i className="fas fa-map-marker-alt text-primary-200 mt-1"></i>
                </div>
                <div className="ml-4">
                  <p className="text-primary-50">
                    123 Avenue de l'Innovation
                    <br />
                    75008 Paris, France
                  </p>
                </div>
              </div>
              <div className="flex items-start">
                <div className="flex-shrink-0">
                  <i className="fas fa-envelope text-primary-200 mt-1"></i>
                </div>
                <div className="ml-4">
                  <p className="text-primary-50">contact@automateia.fr</p>
                </div>
              </div>
              <div className="flex items-start">
                <div className="flex-shrink-0">
                  <i className="fas fa-phone-alt text-primary-200 mt-1"></i>
                </div>
                <div className="ml-4">
                  <p className="text-primary-50">+33 1 23 45 67 89</p>
                </div>
              </div>
            </div>

            <div className="mt-12">
              <h3 className="text-xl font-semibold mb-4">Suivez-nous</h3>
              <div className="flex space-x-4">
                <a
                  href="https://linkedin.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-primary-50 hover:text-white transition duration-150 ease-in-out"
                >
                  <i className="fab fa-linkedin text-2xl"></i>
                </a>
                <a
                  href="https://twitter.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-primary-50 hover:text-white transition duration-150 ease-in-out"
                >
                  <i className="fab fa-twitter text-2xl"></i>
                </a>
                <a
                  href="https://instagram.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-primary-50 hover:text-white transition duration-150 ease-in-out"
                >
                  <i className="fab fa-instagram text-2xl"></i>
                </a>
                <a
                  href="https://facebook.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-primary-50 hover:text-white transition duration-150 ease-in-out"
                >
                  <i className="fab fa-facebook text-2xl"></i>
                </a>
              </div>
            </div>
          </div>

          <div className="md:w-1/2 p-10">
            <form onSubmit={handleSubmit}>
              <div className="mb-6">
                <Label
                  htmlFor="name"
                  className="block text-sm font-medium text-neutral-700 mb-2"
                >
                  Nom complet <span className="text-red-500">*</span>
                </Label>
                <Input
                  type="text"
                  id="name"
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  className="w-full"
                  placeholder="Votre nom"
                  required
                />
              </div>
              <div className="mb-6">
                <Label
                  htmlFor="email"
                  className="block text-sm font-medium text-neutral-700 mb-2"
                >
                  Email professionnel <span className="text-red-500">*</span>
                </Label>
                <Input
                  type="email"
                  id="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  className="w-full"
                  placeholder="votre.email@entreprise.com"
                  required
                />
              </div>
              <div className="mb-6">
                <Label
                  htmlFor="company"
                  className="block text-sm font-medium text-neutral-700 mb-2"
                >
                  Entreprise
                </Label>
                <Input
                  type="text"
                  id="company"
                  name="company"
                  value={formData.company}
                  onChange={handleChange}
                  className="w-full"
                  placeholder="Nom de votre entreprise"
                />
              </div>
              <div className="mb-6">
                <Label
                  htmlFor="message"
                  className="block text-sm font-medium text-neutral-700 mb-2"
                >
                  Message <span className="text-red-500">*</span>
                </Label>
                <Textarea
                  id="message"
                  name="message"
                  value={formData.message}
                  onChange={handleChange}
                  rows={4}
                  className="w-full"
                  placeholder="Comment pouvons-nous vous aider ?"
                  required
                />
              </div>
              <Button
                type="submit"
                className="w-full py-3 px-4 bg-primary-500 text-white rounded-lg font-medium hover:bg-primary-600 transition duration-150 ease-in-out"
                disabled={isSubmitting}
              >
                {isSubmitting ? "Envoi en cours..." : "Envoyer le message"}
              </Button>
            </form>
          </div>
        </div>
      </div>

      <div className="mt-16">
        <h2 className="text-2xl font-bold text-neutral-900 mb-8 text-center">
          Questions fréquentes
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-4xl mx-auto">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">
                Comment fonctionne la période d'essai ?
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-neutral-600">
                Notre période d'essai de 7 jours vous permet d'explorer toutes
                les fonctionnalités du plan Pro. Une carte bancaire est requise
                pour la vérification, mais vous ne serez pas débité pendant
                l'essai et pouvez annuler à tout moment.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">
                Quel type de support proposez-vous ?
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-neutral-600">
                Le plan Pro inclut un support prioritaire par email et chat, avec
                un temps de réponse garanti de moins de 24h. Le plan Entreprise
                offre un gestionnaire de compte dédié et un support téléphonique.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">
                Puis-je changer de plan à tout moment ?
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-neutral-600">
                Oui, vous pouvez passer à un plan supérieur à tout moment. Si
                vous souhaitez réduire votre plan, le changement sera effectif à
                la fin de votre période de facturation actuelle.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">
                Mes données sont-elles sécurisées ?
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-neutral-600">
                La sécurité est notre priorité. Nous utilisons un chiffrement
                SSL, stockons vos données sur des serveurs sécurisés en Europe et
                sommes conformes au RGPD. Vos données ne seront jamais vendues à
                des tiers.
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default Contact;
