import Hero from "@/components/home/Hero";
import Features from "@/components/home/Features";
import HowItWorks from "@/components/home/HowItWorks";
import Pricing from "@/components/home/Pricing";
import Testimonials from "@/components/home/Testimonials";
import NewsletterSection from "@/components/home/NewsletterSection";
import MainHeader from "@/components/layout/MainHeader";
import { useEffect } from "react";
import { useLocation } from "wouter";
import { motion } from "framer-motion";

const Home = () => {
  const [location] = useLocation();

  // Scroll to section if hash is present in URL
  useEffect(() => {
    if (location.includes('#')) {
      const id = location.split('#')[1];
      const element = document.getElementById(id);
      if (element) {
        element.scrollIntoView({ behavior: 'smooth' });
      }
    } else {
      window.scrollTo(0, 0);
    }
  }, [location]);

  return (
    <>
      <MainHeader />
      <div className="pt-16 md:pt-20"> {/* Espace pour le header fixe */}
        <Hero />
        <Features />
        <HowItWorks />
        <Pricing />
        <Testimonials />
        <BlogSection />
        <DashboardPreview />
        <NewsletterSection />
      </div>
    </>
  );
};

const BlogSection = () => {
  const blogArticles = [
    {
      id: 1,
      title: "Comment l'IA transforme le service client en 2023",
      date: "18 Juin 2023",
      excerpt: "Découvrez comment les chatbots IA révolutionnent la relation client et comment les implémenter dans votre entreprise.",
      image: "https://images.unsplash.com/photo-1579389083078-4e7018379f7e?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
      slug: "comment-ia-transforme-service-client-2023"
    },
    {
      id: 2,
      title: "5 automatisations d'emails qui boostent vos ventes",
      date: "05 Juin 2023",
      excerpt: "Apprenez à mettre en place des séquences d'emails automatisées qui convertissent vos prospects en clients fidèles.",
      image: "https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
      slug: "5-automatisations-emails-boostent-ventes"
    },
    {
      id: 3,
      title: "Les meilleurs outils No-Code pour automatiser votre business",
      date: "28 Mai 2023",
      excerpt: "Comparatif des plateformes No-Code les plus performantes pour créer des automatisations sans compétences techniques.",
      image: "https://images.unsplash.com/photo-1563986768609-322da13575f3?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
      slug: "meilleurs-outils-no-code-automatiser-business"
    }
  ];

  return (
    <section id="blog" className="py-16 bg-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl font-bold text-neutral-900 mb-4">
            Notre blog d'experts 📚
          </h2>
          <p className="max-w-3xl mx-auto text-xl text-neutral-600">
            Conseils, astuces et études de cas pour automatiser et développer votre business.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {blogArticles.map((article) => (
            <div 
              key={article.id}
              className="bg-white rounded-xl shadow-md overflow-hidden border border-neutral-100 hover:border-primary-200 transition duration-300"
            >
              <img 
                src={article.image} 
                alt={article.title} 
                className="w-full h-48 object-cover" 
              />
              <div className="p-6">
                <div className="text-sm text-neutral-500 mb-2">{article.date}</div>
                <h3 className="text-xl font-semibold text-neutral-900 mb-3">
                  {article.title}
                </h3>
                <p className="text-neutral-600 mb-4">
                  {article.excerpt}
                </p>
                <span 
                  onClick={() => window.location.href = `/blog/${article.slug}`}
                  className="text-primary-500 font-medium inline-flex items-center cursor-pointer"
                >
                  Lire l'article <i className="fas fa-arrow-right ml-2 text-sm"></i>
                </span>
              </div>
            </div>
          ))}
        </div>

        <div className="text-center mt-12">
          <button 
            onClick={() => window.location.href = "/blog"}
            className="inline-flex items-center px-6 py-3 border border-neutral-300 text-base font-medium rounded-lg shadow-sm text-neutral-700 bg-white hover:bg-neutral-50 transition duration-150 ease-in-out"
          >
            Voir tous les articles <i className="fas fa-arrow-right ml-2"></i>
          </button>
        </div>
      </div>
    </section>
  );
};

const DashboardPreview = () => {
  return (
    <section id="dashboard-preview" className="py-16 bg-neutral-50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl font-bold text-neutral-900 mb-4">
            Votre tableau de bord personnel 📊
          </h2>
          <p className="max-w-3xl mx-auto text-xl text-neutral-600">
            Suivez vos automatisations et optimisez vos performances en temps réel.
          </p>
        </div>

        <div className="bg-white rounded-2xl shadow-lg overflow-hidden border border-neutral-200">
          <div className="p-6 border-b border-neutral-200 bg-neutral-50">
            <div className="flex flex-col sm:flex-row justify-between items-center">
              <h3 className="text-xl font-semibold text-neutral-900 mb-4 sm:mb-0">
                Tableau de bord d'automatisation
              </h3>
              <div className="flex space-x-4">
                <button className="px-4 py-2 bg-white text-neutral-700 border border-neutral-300 rounded-lg hover:bg-neutral-50">
                  <i className="fas fa-filter mr-2"></i> Filtrer
                </button>
                <button className="px-4 py-2 bg-primary-500 text-white rounded-lg hover:bg-primary-600">
                  <i className="fas fa-download mr-2"></i> Exporter
                </button>
              </div>
            </div>
          </div>
          <div className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
              <StatCard 
                title="Conversations automatisées"
                value="1,248"
                change="+24%"
                icon="fas fa-comments"
              />
              <StatCard 
                title="Avis générés"
                value="84"
                change="+12%"
                icon="fas fa-star"
              />
              <StatCard 
                title="Temps économisé"
                value="47h"
                change="+8%"
                icon="fas fa-clock"
              />
            </div>
            
            <div className="mb-8">
              <h4 className="text-lg font-semibold text-neutral-900 mb-4">
                Performances des chatbots
              </h4>
              <div className="bg-white rounded-xl shadow-sm border border-neutral-100 overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="min-w-full divide-y divide-neutral-200">
                    <thead className="bg-neutral-50">
                      <tr>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                          Chatbot
                        </th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                          Canal
                        </th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                          Messages
                        </th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                          Taux de satisfaction
                        </th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                          Statut
                        </th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-neutral-200">
                      <ChatbotRow 
                        name="Support Client"
                        channel="Site Web"
                        messages={856}
                        satisfaction={92}
                        status="Actif"
                      />
                      <ChatbotRow 
                        name="Ventes"
                        channel="WhatsApp"
                        messages={327}
                        satisfaction={87}
                        status="Actif"
                      />
                      <ChatbotRow 
                        name="Réservations"
                        channel="Instagram"
                        messages={65}
                        satisfaction={95}
                        status="Actif"
                      />
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
            
            <div className="text-center">
              <p className="text-neutral-500 mb-4">
                Connectez-vous pour accéder à votre tableau de bord personnalisé
              </p>
              <button 
                onClick={() => window.location.href = "/dashboard"}
                className="inline-flex items-center px-6 py-3 border border-transparent font-medium rounded-lg shadow-sm text-white bg-primary-500 hover:bg-primary-600 transition duration-150 ease-in-out"
              >
                Accéder au tableau de bord complet
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

interface StatCardProps {
  title: string;
  value: string;
  change: string;
  icon: string;
}

const StatCard = ({ title, value, change, icon }: StatCardProps) => {
  return (
    <div className="bg-white rounded-xl shadow-sm p-6 border border-neutral-100">
      <div className="flex justify-between items-start">
        <div>
          <p className="text-neutral-500 text-sm">{title}</p>
          <h4 className="text-2xl font-bold text-neutral-900 mt-1">{value}</h4>
          <p className="text-green-500 text-sm mt-2">
            <i className="fas fa-arrow-up mr-1"></i> {change} ce mois
          </p>
        </div>
        <div className="w-12 h-12 bg-primary-100 rounded-lg flex items-center justify-center">
          <i className={`${icon} text-xl text-primary-500`}></i>
        </div>
      </div>
    </div>
  );
};

interface ChatbotRowProps {
  name: string;
  channel: string;
  messages: number;
  satisfaction: number;
  status: string;
}

const ChatbotRow = ({ name, channel, messages, satisfaction, status }: ChatbotRowProps) => {
  return (
    <tr>
      <td className="px-6 py-4 whitespace-nowrap">
        <div className="flex items-center">
          <div className="flex-shrink-0 h-10 w-10 bg-primary-100 rounded-full flex items-center justify-center">
            <i className="fas fa-robot text-primary-500"></i>
          </div>
          <div className="ml-4">
            <div className="text-sm font-medium text-neutral-900">{name}</div>
          </div>
        </div>
      </td>
      <td className="px-6 py-4 whitespace-nowrap">
        <div className="text-sm text-neutral-900">{channel}</div>
      </td>
      <td className="px-6 py-4 whitespace-nowrap">
        <div className="text-sm text-neutral-900">{messages}</div>
      </td>
      <td className="px-6 py-4 whitespace-nowrap">
        <div className="text-sm text-green-600">{satisfaction}%</div>
      </td>
      <td className="px-6 py-4 whitespace-nowrap">
        <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
          {status}
        </span>
      </td>
    </tr>
  );
};

export default Home;
