import { useStripe, Elements, PaymentElement, useElements } from '@stripe/react-stripe-js';
import { loadStripe } from '@stripe/stripe-js';
import { useEffect, useState } from 'react';
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { useLocation } from "wouter";

// Make sure to call `loadStripe` outside of a component's render to avoid
// recreating the `Stripe` object on every render.
const stripePromise = loadStripe(import.meta.env.VITE_STRIPE_PUBLIC_KEY || "pk_test_placeholder");

const SubscribeForm = () => {
  const stripe = useStripe();
  const elements = useElements();
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);
  const [, setLocation] = useLocation();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!stripe || !elements) {
      return;
    }

    setIsLoading(true);

    try {
      const { error } = await stripe.confirmPayment({
        elements,
        confirmParams: {
          return_url: `${window.location.origin}/dashboard`,
        },
      });

      if (error) {
        throw error;
      }
    } catch (error: any) {
      toast({
        title: "Erreur de paiement",
        description: error.message || "Une erreur est survenue lors du paiement.",
        variant: "destructive",
      });
      setIsLoading(false);
    }
  };

  return (
    <div className="bg-white p-8 rounded-xl shadow-md w-full max-w-2xl mx-auto">
      <h3 className="text-2xl font-bold mb-6 text-center">Abonnement Plan Pro</h3>
      <div className="bg-primary-50 p-4 rounded-lg mb-6">
        <div className="flex justify-between items-center">
          <div>
            <p className="font-medium text-lg text-primary-900">Plan Pro</p>
            <p className="text-primary-700">Essai gratuit de 7 jours</p>
          </div>
          <div className="text-right">
            <p className="text-2xl font-bold text-primary-900">499€<span className="text-sm font-normal">/mois</span></p>
            <p className="text-sm text-primary-700">Après la période d'essai</p>
          </div>
        </div>
      </div>
      
      <div className="space-y-4 mb-8">
        <div className="flex items-center">
          <i className="fas fa-check text-green-500 mr-3"></i>
          <span>3 chatbots IA avancés</span>
        </div>
        <div className="flex items-center">
          <i className="fas fa-check text-green-500 mr-3"></i>
          <span>Messages illimités par mois</span>
        </div>
        <div className="flex items-center">
          <i className="fas fa-check text-green-500 mr-3"></i>
          <span>Multi-canaux (Site web, WhatsApp, Instagram)</span>
        </div>
        <div className="flex items-center">
          <i className="fas fa-check text-green-500 mr-3"></i>
          <span>Automatisation des avis Google</span>
        </div>
        <div className="flex items-center">
          <i className="fas fa-check text-green-500 mr-3"></i>
          <span>1 tunnel de vente personnalisé</span>
        </div>
      </div>
      
      <form onSubmit={handleSubmit} className="space-y-6">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Informations de paiement
          </label>
          <PaymentElement />
        </div>
        
        <div className="flex items-center">
          <input
            id="terms"
            name="terms"
            type="checkbox"
            className="h-4 w-4 text-primary-500 focus:ring-primary-500 border-gray-300 rounded"
            required
          />
          <label htmlFor="terms" className="ml-2 block text-sm text-gray-700">
            J'accepte que mon abonnement de 499€/mois débute automatiquement après ma période d'essai de 7 jours, sauf si j'annule avant.
          </label>
        </div>
        
        <button
          type="submit"
          disabled={!stripe || isLoading}
          className="w-full py-3 px-4 bg-primary-500 text-white rounded-lg font-medium hover:bg-primary-600 transition duration-150 ease-in-out disabled:opacity-70"
        >
          {isLoading ? "Traitement en cours..." : "Commencer mon essai gratuit"}
        </button>
        
        <p className="text-sm text-center text-gray-500 mt-4">
          Vous pouvez annuler à tout moment durant votre période d'essai.
          Aucun frais ne sera appliqué si vous annulez avant la fin des 7 jours.
        </p>
      </form>
    </div>
  );
};

const Subscribe = () => {
  const [clientSecret, setClientSecret] = useState("");
  const { user, isLoading: authLoading } = useAuth();
  const { toast } = useToast();
  const [, setLocation] = useLocation();

  useEffect(() => {
    if (!authLoading && !user) {
      toast({
        title: "Accès refusé",
        description: "Vous devez être connecté pour souscrire à un abonnement.",
        variant: "destructive",
      });
      setLocation("/");
      return;
    }

    if (user) {
      // Create PaymentIntent as soon as the page loads
      apiRequest("POST", "/api/get-or-create-subscription")
        .then((res) => res.json())
        .then((data) => {
          setClientSecret(data.clientSecret);
        })
        .catch(error => {
          toast({
            title: "Erreur",
            description: "Impossible de créer l'abonnement. Veuillez réessayer.",
            variant: "destructive",
          });
        });
    }
  }, [user, authLoading, toast, setLocation]);

  if (authLoading || !user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin h-12 w-12 border-4 border-primary-500 border-t-transparent rounded-full"></div>
      </div>
    );
  }

  if (!clientSecret) {
    return (
      <div className="container mx-auto px-4 py-16">
        <div className="flex flex-col items-center justify-center">
          <div className="animate-spin h-12 w-12 border-4 border-primary-500 border-t-transparent rounded-full mb-4"></div>
          <p className="text-neutral-700">Préparation de votre abonnement...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-16">
      <div className="text-center mb-12">
        <h1 className="text-3xl font-bold mb-4">Commencer votre essai gratuit</h1>
        <p className="text-neutral-600 max-w-2xl mx-auto">
          Profitez de 7 jours d'essai gratuit du Plan Pro. Une vérification par carte bancaire est requise, mais vous ne serez pas débité pendant la période d'essai.
        </p>
      </div>
      
      <Elements stripe={stripePromise} options={{ clientSecret, appearance: { theme: 'stripe' } }}>
        <SubscribeForm />
      </Elements>
      
      <div className="mt-12 max-w-2xl mx-auto bg-blue-50 p-6 rounded-lg">
        <h3 className="text-lg font-medium text-blue-800 mb-2">🔒 Paiement sécurisé</h3>
        <p className="text-blue-700">
          Toutes les transactions sont sécurisées et chiffrées. Les informations de votre carte ne sont jamais stockées sur nos serveurs.
        </p>
      </div>
    </div>
  );
};

export default Subscribe;
