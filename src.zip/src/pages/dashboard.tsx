import { useState, useEffect } from "react";
import { Link } from "wouter";
import { motion, AnimatePresence } from "framer-motion";
import { 
  Plus, Grid, LayoutDashboard, Settings, KeyRound, 
  Activity, Bot, FileText, BarChart2, Calendar, 
  Code, ChevronDown, ChevronRight, X, Info, Zap, Wand2, 
  AlertCircle, User
} from "lucide-react";
import { useTheme } from "@/context/ThemeContext";
import NotificationCenter from "@/components/ui/notification-center";
import { ThemeSwitcherMini } from "@/components/ui/theme-switcher";
import AIAnalytics from "@/components/dashboard/AIAnalytics";
import ApiKeyManager from "@/components/dashboard/ApiKeyManager";
import AIWorkflowGenerator from "@/components/ui/ai-workflow-generator";
import { useAuth } from "@/hooks/useAuth";
import { useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";

const TABS = [
  { id: "overview", label: "Vue d'ensemble", icon: <Grid className="h-5 w-5" /> },
  { id: "analytics", label: "Analyses", icon: <BarChart2 className="h-5 w-5" /> },
  { id: "automations", label: "Automatisations", icon: <Zap className="h-5 w-5" /> },
  { id: "chatbots", label: "Chatbots", icon: <Bot className="h-5 w-5" /> },
  { id: "api-keys", label: "Clés API", icon: <KeyRound className="h-5 w-5" /> },
  { id: "settings", label: "Paramètres", icon: <Settings className="h-5 w-5" /> }
];

export default function Dashboard() {
  const { user, isLoading: authLoading, logout } = useAuth();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [currentTab, setCurrentTab] = useState("overview");
  const [isLoading, setIsLoading] = useState(true);
  const { resolvedTheme } = useTheme();
  
  const isDark = resolvedTheme === "dark";

  useEffect(() => {
    if (!authLoading && !user) {
      toast({
        title: "Accès refusé",
        description: "Vous devez être connecté pour accéder à cette page.",
        variant: "destructive",
      });
      setLocation("/");
    }
  }, [user, authLoading, setLocation, toast]);

  const { data: subscriptionData, isLoading: subscriptionLoading } = useQuery({
    queryKey: ["/api/user/subscription"],
    enabled: !!user,
  });

  useEffect(() => {
    if (!authLoading && user) {
      const timer = setTimeout(() => {
        setIsLoading(false);
      }, 1200);
      return () => clearTimeout(timer);
    }
  }, [authLoading, user]);

  if (authLoading || (user && subscriptionLoading)) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin h-12 w-12 border-4 border-primary rounded-full border-t-transparent"></div>
      </div>
    );
  }

  if (!user) {
    return null;
  }

  return (
    <div className={`min-h-screen ${isDark ? "bg-gray-900" : "bg-gray-50"}`}>
      <header className={`border-b sticky top-0 z-10 ${isDark ? "bg-gray-900 border-gray-800" : "bg-white border-gray-200"}`}>
        <div className="container mx-auto px-4 sm:px-6 py-4">
          <h1 className="text-xl font-bold text-gray-900 dark:text-white hidden sm:block">Dashboard</h1>
        </div>
      </header>

      <div className="container mx-auto px-4 sm:px-6 py-6">
        <h2 className="text-xl font-bold text-gray-900 dark:text-white">
          En construction
        </h2>
      </div>
    </div>
  );
}
