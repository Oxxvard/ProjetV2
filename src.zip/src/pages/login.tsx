import { useState } from "react";
import LoginModal from "@/components/auth/LoginModal"; // Assurez-vous que le chemin est correct

const LoginPage = () => {
  const [isOpen, setIsOpen] = useState(true); // Modal est ouvert par défaut

  const handleClose = () => {
    setIsOpen(false);
  };

  const handleSignupClick = () => {
    // Utilisation de Link pour rediriger vers la page d'inscription
    window.location.href = "/signup"; // Ou utilisez Link dans le LoginModal
  };

  return (
    <div>
      <h1 className="text-center text-2xl">Connexion / Inscription</h1>
      <LoginModal
        isOpen={isOpen}
        onClose={handleClose}
        onSignupClick={handleSignupClick}
      />
    </div>
  );
};

export default LoginPage;
