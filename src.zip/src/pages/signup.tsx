import { useState } from "react";
import SignupModal from "@/components/auth/SignupModal"; // Assurez-vous que le chemin est correct

const SignupPage = () => {
  const [isSignupModalOpen, setIsSignupModalOpen] = useState(true);

  // Fonction pour fermer le modal
  const closeSignupModal = () => setIsSignupModalOpen(false);

  // Fonction pour afficher la page de connexion quand l'utilisateur clique sur "Se connecter"
  const handleLoginClick = () => {
    // Redirection vers la page de connexion, ou autre logique selon votre projet
    window.location.href = "/login";
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 dark:bg-gray-900">
      {/* Modal d'inscription */}
      <SignupModal
        isOpen={isSignupModalOpen}
        onClose={closeSignupModal}
        onLoginClick={handleLoginClick}
      />
    </div>
  );
};

export default SignupPage;
